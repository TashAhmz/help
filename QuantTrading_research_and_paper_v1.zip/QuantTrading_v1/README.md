# QuantTrading v0.2: local research and IBKR paper trading

A modular, long-only, daily-data research application with an explicitly gated Interactive Brokers paper adapter. Built for learning, reproducible evaluation and supervised forward testing, not unattended production or real-money trading.

**Start with [START_HERE.md](START_HERE.md).** Detailed broker/mobile setup is in [docs/IBKR_SETUP.md](docs/IBKR_SETUP.md). Exact verification status is in [docs/verification.json](docs/verification.json).

## What is included

| Component | Implemented purpose |
|---|---|
| Market data | Yahoo daily bars, immutable provider snapshots, metadata, checksums, trading-session and numerical checks. |
| Fundamental data | SEC annual filing-specific ratios, availability-dated events, archived source JSON and parsing audit. |
| Strategies | Momentum-only, fundamentals-only and combined; common equity universe, portfolio rules and costs. |
| Research | Next-session simulation, FIFO cost accounting, buy-and-hold references, holdout, annual frozen-rule evaluations, cost stress and optional single-feature experiments. |
| Paper execution | Read-only connection checks, verified-account allowlist, expiring plans, limit orders, broker what-if checks, execution receipts and no automatic unknown-order retries. |
| Risk and operations | Position/gross/sector/correlation limits, virtual risk budget, daily-loss/drawdown halt, close-based stops, persistent STOP and account/ledger reconciliation. |
| Monitoring | Browser-readable HTML research reports, CSV/JSON evidence, SQLite paper journal and localhost status page. IBKR Mobile separately monitors broker holdings/P&L. |
| Tests | Offline tests for data validation, timing, accounting, research, risk and simulated broker failure paths. |

The package does not contain live-trading code, login automation, account credentials, a cloud deployment or a guarantee that the installed TWS version is compatible. No real Yahoo/SEC download or authenticated IBKR connection was completed in the build environment. Optional provider libraries must be installed and tested locally. Read `docs/ACCEPTANCE_CHECKLIST.md` before enabling paper submission.

## Project structure

```text
QuantTrading_v1/
  START_HERE.md
  README.md
  pyproject.toml
  config/default.json           Research defaults; paper orders disabled
  config/paper.example.json     Copy to your ignored local paper.json
  scripts/                      Local setup helpers; no orders
  src/quanttrading/
    cli.py, settings.py         Commands and validated configuration
    market_data.py             Yahoo adapter
    validation.py, pipeline.py  Data checks and reproducible snapshots
    research_data.py           Verified common-session price matrices
    fundamentals.py            SEC events and backward-only availability joins
    strategies.py              Features, eligible names and portfolio targets
    risk.py                    Position, sector and correlation budgets
    backtest.py                Historical portfolio simulation and FIFO accounting
    performance.py             Metrics and paired block-resampling intervals
    research.py, reporting.py  Comparative study and local HTML/CSV output
    broker.py                  Local IBKR paper-only adapter
    paper_safety.py, paper.py   Plans, preflight, supervised sends and monitoring loop
    state.py                   Durable journal, reconciliation and stop latch
    monitoring.py              Read-only localhost snapshot page
    calendar_utils.py          Exchange sessions, holidays and safe order window
    demo.py                    Explicitly synthetic integration fixtures
  tests/
  docs/
  examples/synthetic_report/   Software demonstration, not market evidence
```

Generated `data/`, `reports/`, `demo_output/` and `runtime/` directories are ignored by Git. Keep private data and the SQLite ledger backed up locally. Do not delete state to bypass a failed order or a risk shutdown.

## Installation

Use Python 3.13 and a fresh virtual environment. The short form, after creating/activating `.venv`, is:

```bash
python -m pip install -e ".[all]"
python -m pytest -q
python -m quanttrading doctor
python -m quanttrading demo
```

`doctor` does not access the network or your broker. The broker extra pins community library `ib_async==2.1.0`; this is not an IBKR-maintained library. Confirm transport compatibility with your installed TWS build using read-only checks before changing any order permissions. All package extras are in `pyproject.toml`.

After a successful local install and test run, record the resolved environment:

```bash
python -m pip freeze --exclude-editable > requirements-lock.txt
```

The delivered `docs/tested-core-environment.txt` records the build's core versions; it is NOT a complete, network-tested dependency lock for optional broker/market packages. The CI workflow is provided but has not run in your GitHub account.

## Research with real observations

The default engineering universe is AAPL, MSFT, AMZN, GOOGL, META and NVDA, with SPY and QQQ as reference benchmarks. This is a small, concentrated, selected-survivor universe, not a historical point-in-time stock selection universe. It is not a buy recommendation.

Fetch 2018-2025 to provide indicator warmup for a 2020-2025 evaluation and a separately restarted 2024-2025 holdout. End dates are exclusive.

```bash
python -m quanttrading fetch --start 2018-01-01 --end 2026-01-01
```

The command prints a new data-run directory. `structural_pass: true` means schema, session, identity and numerical checks passed; it does not mean prices were independently verified. Inspect each instrument's `quality.json`, `metadata.json`, `provider_output.csv` and `validated.csv`. Choose several ordinary sessions and corporate-action periods for cross-source checks using consistent adjustment conventions.

For SEC access, set a descriptive User-Agent and contact email **locally**:

```powershell
# Windows PowerShell
$env:SEC_USER_AGENT = "QuantTradingResearch YourName your.email@example.com"
```

```bash
# macOS / Linux
export SEC_USER_AGENT="QuantTradingResearch YourName your.email@example.com"
```

Replace the name/email with your own local values. Do not send them in chat. Then:

```bash
python -m quanttrading fundamentals --output data/fundamentals_20261114.csv
python -m quanttrading research --data data/runs/YOUR_PRINTED_RUN_DIRECTORY --fundamentals data/fundamentals_20261114.csv
```

Replace `YOUR_PRINTED_RUN_DIRECTORY` with the actual folder printed by `fetch`; it is not a literal filename. Source downloads are archived, checksummed and audited. The fundamentals command refuses to overwrite previous evidence. Use a new filename for a new snapshot.

A price-only baseline is also supported:

```bash
python -m quanttrading research --data data/runs/YOUR_PRINTED_RUN_DIRECTORY
```

It explicitly omits fundamental-only and combined tests rather than fabricating inputs.

Optional, **exploratory** individual-feature tests:

```bash
python -m quanttrading research --data data/runs/YOUR_PRINTED_RUN_DIRECTORY --fundamentals data/fundamentals_20261114.csv --ablations
```

These add each fundamental feature separately to momentum while keeping the complete-data sample fixed. Reusing the holdout to choose a winning feature consumes that holdout; it is not independent confirmation. This command does more work than the baseline study because it rebuilds and evaluates each variant.

The research command never connects to IBKR. Provider rate limits, incomplete prices or ambiguous filings cause errors; it does not switch to synthetic data on failure.

## Read the report, not just the final balance

Each report directory contains `report.html`, `summary.json`, equity/drawdown images, `walk_forward.csv`, `signals.csv`, target weights and per-strategy accounting files. Open the HTML locally; keep it beside its images and CSV files. Holdout portfolios are stored under `holdout/`. All headline metrics and limitations are retained in `summary.json`.

Evaluate whether combined rules improve on momentum-only and fundamentals-only under the same exposure rules. Inspect the full-investment SPY/QQQ references and the same-equity passive budget separately; these are not perfectly risk-matched benchmarks. A low-exposure strategy can look less volatile simply because it holds more cash.

Key fields include total and annualised return, annualised volatility, Sharpe with zero assumed cash interest, maximum drawdown, mean gross exposure, filled orders, closed FIFO lots, win rate, average gain/loss, profit factor, fees and modelled execution friction. Empty trade sets and no-loss profit factors are undefined, not proof of perfection. Detailed metrics are in JSON even where the HTML table is condensed.

Prioritise the held-out interval, annual consistency, doubled costs, turnover, fundamental coverage, drawdowns and the number of meaningful independent observations. Bootstrap intervals do not fix survivorship bias, repeated hypothesis testing, inaccurate data or changing market regimes. Never claim profitability from the bundled synthetic example.

## Default hypothesis and risk budget

The defaults are deliberately transparent and have NOT been optimised:

- Momentum uses a positive 20/50/200-day moving-average structure, positive 63/126-session returns, strength relative to SPY, liquidity and volatility screens.
- Fundamentals require positive annual revenue and net-income growth, net margin above 5%, and operating-cash-flow/revenue above 5%. These are annual company fundamentals, not ETF scores, analyst revisions, EPS forecasts or a macro model.
- Combined rules require both sets of conditions. Up to four names are selected, inverse-volatility weighted and scaled to explicit position, gross, sector and correlation limits. Eligible cash is not forced into a stock.
- The hypothetical research/paper risk budget is USD 10,000, with 15% per name, 60% gross, 30% sector and 30% highly correlated group caps. These are test parameters, NOT a recommendation to invest or fund that amount.

Research targets a 10% annualised portfolio volatility estimate. Realised volatility can differ. Daily loss (2%) and drawdown (10%) triggers are checks, not guaranteed loss ceilings. See [docs/STRATEGY_AND_LIMITATIONS.md](docs/STRATEGY_AND_LIMITATIONS.md) for mathematics, cost accounting and differences between research and paper execution.

## Paper workflow

Follow [docs/IBKR_SETUP.md](docs/IBKR_SETUP.md) completely. Keep a dedicated, initially flat **USD-reporting paper account**. The code rejects other account currencies, unrelated holdings, manual inventory changes, stale/delayed quotes and unknown open orders. It does not silently convert GBP or other currencies to USD.

Global options precede the subcommand:

```bash
python -m quanttrading --config config/paper.json paper-check
python -m quanttrading --config config/paper.json paper-init --confirm-paper DU1234567
python -m quanttrading --config config/paper.json paper-cycle
```

Replace the account example with your locally verified PAPER account; do not paste it into chat. `paper-check` reads account state. `paper-init` records a baseline and sends no orders. `paper-cycle` without `--execute` downloads fresh inputs and creates a plan only. It returns `outside_market_window` on weekends, holidays and outside the permitted exchange-session window.

Orders require all explicit authorisations: the account environment variable, a verified paper account, two local configuration switches, the correct account confirmation argument, a fresh plan and passing runtime risk checks. There is no live-mode flag. Ports and an account prefix are defensive checks, not cryptographic proof of simulation: verify PAPER in TWS yourself.

After supervised acceptance, a foreground plan-only loop is:

```bash
python -m quanttrading --config config/paper.json paper-run
```

The explicitly enabled order-sending variant is described only after the checklist in the broker guide. It must stay open on your computer; it is not a hidden service. Keep TWS logged in, the computer awake and its clock synchronized. No unattended restart or cloud recovery is implemented.

In another terminal, using the same virtual environment and config:

```bash
python -m quanttrading --config config/paper.json dashboard
```

Open `http://127.0.0.1:8765` on that computer. This is a saved-snapshot monitor, not a broker connection. It flags stale snapshots; it cannot submit orders and must not be exposed to the internet. IBKR Mobile tracks the broker account, not Python-process health. Mobile login can conflict with TWS's session; follow the guide.

Emergency stop:

```bash
python -m quanttrading --config config/paper.json paper-stop --cancel
```

This latches STOP and attempts to cancel only this application's orders. It does not sell existing positions. If disconnected, verify and manage pending orders in TWS. Never remove `runtime/STOP`, delete the SQLite file or reset the paper account merely to force a run through a safety failure.

## Troubleshooting

| Symptom | Response |
|---|---|
| Package/module missing | Use the `.venv` interpreter and reinstall the correct extra from the project root. |
| Cannot install broker package | Inspect pip's error and verify Python/version/network. Offline research still works; do not claim broker connectivity. |
| SEC 403/rate limit | Check the local User-Agent, network and SEC access guidance. Do not use rapid retry loops or fabricated substitutes. |
| No annual facts for a company | Inspect the archived parsing audit and original filings; unsupported tags/ambiguous durations are deliberately rejected. |
| No strategy trades | Inspect `signals.csv`, fundamental coverage and risk-trigger logs. Strict filters can legitimately leave cash uninvested. |
| Cannot connect to TWS | Verify PAPER login, socket permission, local port, trusted localhost and no competing client ID. |
| No live quotes/P&L | Check API data entitlements and session state. Delayed/frozen quotes are blocked; initialise baseline when valid P&L is available. |
| Account currency not USD | This implementation does not support multi-currency accounting. Do not change a live account just to bypass the check. |
| Unknown order / position mismatch | Stop, inspect TWS and the local journal, reconcile actual fills before any restart. |
| STOP latch / loss trigger | Investigate the cause and remaining positions; there is no automatic restart or guaranteed flattening. |

## Learning path

Read `settings.py`, `fundamentals.py`, `strategies.py`, `risk.py`, `backtest.py` and `performance.py` first. Then inspect paper safety, state and the broker adapter. Tests are executable examples of expected behaviour. The source modules retain function docstrings and comments around timing, financial accounting and failure cases.

The design separates interfaces for future providers and asset classes, but the current valuation, calendars, orders and risk logic are specifically for long-only USD US stocks. Futures, FX and short selling need new instrument/accounting tests; changing a ticker alone is not enough.

Primary references and retrieval date are in [docs/SOURCES.md](docs/SOURCES.md). Operating and restart rules are in [docs/OPERATIONS.md](docs/OPERATIONS.md).
