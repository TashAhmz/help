#!/usr/bin/env sh
set -eu
cd "$(dirname "$0")/.."
python3.13 -m venv .venv
.venv/bin/python -m pip install --upgrade pip
.venv/bin/python -m pip install -e '.[all]'
.venv/bin/python -m pytest -q
.venv/bin/python -m quanttrading doctor
printf '\nSetup complete. No broker connection or orders were attempted. Run the synthetic demo next.\n'
