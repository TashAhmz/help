$ErrorActionPreference = "Stop"
Set-Location (Join-Path $PSScriptRoot "..")
py -3.13 -m venv .venv
if ($LASTEXITCODE -ne 0) { throw "Install Python 3.13 and retry." }
& .\.venv\Scripts\python.exe -m pip install --upgrade pip
if ($LASTEXITCODE -ne 0) { throw "pip upgrade failed." }
& .\.venv\Scripts\python.exe -m pip install -e ".[all]"
if ($LASTEXITCODE -ne 0) { throw "Dependency installation failed. Check network/Python version." }
& .\.venv\Scripts\python.exe -m pytest -q
if ($LASTEXITCODE -ne 0) { throw "Tests failed. Do not enable broker submission." }
& .\.venv\Scripts\python.exe -m quanttrading doctor
Write-Host "Setup complete. No broker connection or orders were attempted. Run the synthetic demo next."
