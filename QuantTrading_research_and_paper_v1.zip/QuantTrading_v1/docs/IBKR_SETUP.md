# Interactive Brokers paper setup and phone monitoring

Checked against official IBKR documentation on 14 November 2026. See `SOURCES.md` for the actual primary references. Menus can vary by device/build. This guide is not confirmation that your account, subscriptions or devices have been configured.

## Boundary: your account and devices remain under your control

You must install TWS/IBKR Mobile, complete any account application, login and two-factor authentication yourself. Do not share passwords, 2FA codes or private account files. The Python program uses only a local authenticated TWS/Gateway socket; it never collects a broker password.

Only paper trading is implemented. Account identifiers, port numbers and mode settings must all be checked. A port number or DU prefix alone is not infallible proof of a simulated account. Close any live TWS/Gateway session while setting this up.

## 1. Obtain or locate the paper account

For an existing client, official IBKR guidance uses Client Portal -> User menu -> Settings -> Account Configuration -> Paper Trading Account. Locate/create the paper credentials there and record the paper account number locally. Official documentation currently says full client paper-account access is available once the associated live account is funded; a non-client free trial is a separate option. Entitlements and eligibility can differ.

You do NOT need to deposit money, make a live trade or open a broker account to run this project's historical research or synthetic demo. Do not fund an account simply because a software setup guide exists. Check your own IBKR entity's terms, subscriptions and suitability first. Free trials may provide delayed quotes; this adapter rejects delayed/frozen data for order generation.

Use a dedicated paper account with no manual holdings, unrelated algorithms or pending orders. This V1 requires USD account reporting and USD equities. A GBP-base account will fail safely; multi-currency account reconciliation is not implemented. Do not alter a real account's currency merely to bypass this limitation.

## 2. Install Trader Workstation on the computer

Download **Trader Workstation (TWS)** from IBKR's official download page, not an unofficial installer. IBKR Desktop is a different product; this package uses the TWS API. Start with the visible TWS interface so you can inspect orders and positions. IB Gateway is the later, lighter alternative; configure only one endpoint for this application.

Choose **Paper Trading before logging in**. Use the paper credentials appropriate to the account shown in Client Portal. Complete any 2FA prompt. Check the simulated/PAPER banner and the exact account number in TWS before doing anything with Python.

In TWS, open Global Configuration -> API -> Settings. For initial checks:

| Setting | Initial value |
|---|---|
| Enable ActiveX and Socket Clients | Enabled |
| Read-Only API | Enabled initially |
| Socket port | 7497 for this TWS paper configuration |
| Allow connections from localhost only | Enabled |
| Trusted address, where required | 127.0.0.1 only |

IB Gateway's usual paper port is 4002. The program permits only 7497 or 4002 on localhost. It rejects default live ports 7496/4001 and remote hosts. Do not reassign a live session to a paper port.

**2026 upgrade caveat:** IBKR's release notes state that TWS/Gateway 10.45 clears the socket-client and localhost-only settings once. Verify these settings after updates. The delivered community `ib_async` adapter was not tested against an authenticated TWS build here. Record the installed TWS build, run read-only checks and review protocol warnings after any update; do not assume version compatibility.

No router port-forwarding, public IP binding or passwordless unattended login is needed. Never expose the TWS socket or local dashboard publicly.

## 3. Confirm market data and permissions

IBKR's official documentation distinguishes paper simulation from real-time data entitlements. Full real-time quotes may require subscriptions and API permissions; a free demo can supply delayed data. Where applicable, Client Portal's Paper Trading Account settings let you share an eligible live account's subscribed data with the paper username.

Do not purchase an assumed bundle based on a generic guide. Confirm coverage for your exact US stocks, API use, account and professional/non-professional status with IBKR. Read-only account checks can work even when live quotes needed for trading do not.

The application demands streaming live data type 1, recent two-sided quotes with valid sizes, supported contracts and an acceptable spread. It refuses delayed/frozen data. P&L unavailable, NaN or stale state must be investigated, not replaced with zero. Initialise the risk baseline during a session when valid P&L is being delivered.

## 4. Configure only your local paper settings

Copy `config/paper.example.json` to `config/paper.json`. The latter is ignored by Git. Leave `paper.submit_enabled` and `paper.data_reviewed` false. Use port 7497 for TWS or 4002 for Gateway. Do not change the localhost host or remove the defensive checks.

Set your exact paper account number in the current terminal:

```powershell
$env:IBKR_PAPER_ACCOUNT = "DU1234567"
$env:SEC_USER_AGENT = "QuantTradingResearch YourName your.email@example.com"
```

```bash
export IBKR_PAPER_ACCOUNT="DU1234567"
export SEC_USER_AGENT="QuantTradingResearch YourName your.email@example.com"
```

Replace the example with your own values locally. `DU1234567` is not a usable supplied account. The application permits only its allowlisted paper-format account and rejects sessions exposing other managed accounts. Multi-account advisers need a separately reviewed adapter, not a weakened check.

The default paper `capital_usd` is a hypothetical USD 10,000 risk budget, not the broker's entire simulated balance. You need not reset the broker's default paper balance. The immutable baseline records the actual broker balance and tracks changes against the smaller virtual budget. No deposits, withdrawals, resets or unrelated trades may occur during that experiment.

## 5. Run a read-only connection check and baseline

```bash
python -m quanttrading --config config/paper.json paper-check
```

Expected: account snapshot, positions/open orders and an uninitialised baseline indication. No order is submitted. Confirm the returned account against TWS. Do not publish unredacted output because account identifiers can appear in logs.

Once the dedicated account is flat, has no open orders and valid daily P&L is available:

```bash
python -m quanttrading --config config/paper.json paper-init --confirm-paper DU1234567
```

This records the baseline only. It does not buy anything. The baseline cannot be silently overwritten. If initialization/risk checks fail, inspect the explanation and `runtime/STOP`; do not proceed by deleting state.

## 6. Generate a plan without trading

On a US exchange session, after the first ten minutes and before the final fifteen minutes:

```bash
python -m quanttrading --config config/paper.json paper-cycle
```

The program retrieves fresh daily history through the previous completed session, retrieves annual SEC data for fundamental/combined modes, applies the strategy and creates an expiring plan. It does not submit orders. On 14 November 2026, a Saturday, it correctly returns `outside_market_window` rather than trading. The calendar handles US holidays, early closes and daylight-saving changes; do not schedule by a fixed UK/US offset.

Review the plan's symbols, side, integer quantities, fixed limit prices, existing positions, target weights and hypothetical risk budget. A zero-order plan can be correct: no eligible companies, a non-rebalance session or already-matching holdings. Weekly rebalancing targets the first trading session of the next ISO week. Close-based stops can reduce holdings on other sessions.

The default plan expires after 120 seconds. This is intentional; a plan is not permanent authorisation. Regenerate it after changes or expiry, and never hand-edit prices/quantities to evade checks.

## 7. First explicit PAPER order batch

Complete `ACCEPTANCE_CHECKLIST.md` first. Independently inspect market data, filings, expected signals and cost assumptions. Confirm the experiment is PAPER in TWS. This is a supervised integration test, not a profitability endorsement.

Only for the verified PAPER session, disable TWS's **Read-Only API** so that paper orders can be accepted. Keep localhost restriction and socket permissions intact. In `config/paper.json`, deliberately change:

```json
"submit_enabled": true,
"data_reviewed": true
```

These are fields inside the existing `paper` object; do not replace the whole configuration with this two-line fragment. `data_reviewed` is your attestation, not an automatic independent data-certification service.

After changing settings, generate a NEW plan (old plans carry the previous configuration fingerprint). Review the newly printed path and submit within its short lifetime:

```bash
python -m quanttrading --config config/paper.json paper-cycle
python -m quanttrading --config config/paper.json paper-submit --plan runtime/cycles/YOUR_CYCLE_DIRECTORY/plan.json --confirm-paper DU1234567
```

Use the exact plan path printed by `paper-cycle`. If it has expired, regenerate and review rather than widening freshness limits. Do not run two execution processes. Observe the batch in TWS and inspect `runtime/last_submission.json` and the SQLite events before attempting further operation.

Orders are regular-hours DAY limit orders, not market orders. Broker what-if checks occur first. Sells are processed before buys; there is no leverage or deliberate short selling. A price move, partial fill, failed cancellation, disconnect, changed holdings or risk failure stops the batch. An uncertain send is never automatically retried. The daily batch reservation is persisted before the first send to reduce duplicate-order risk across restarts.

There may be no executable order on the first test day. Do not weaken the strategy, inject a trade or switch to live mode simply to see activity.

## 8. Foreground operation after successful supervised tests

Plan-only monitoring (safe default):

```bash
python -m quanttrading --config config/paper.json paper-run
```

Explicit paper execution, only after the prior checks:

```bash
python -m quanttrading --config config/paper.json paper-run --execute --confirm-paper DU1234567
```

The process checks state every 120 seconds and attempts at most one daily cycle, with durable reservations for actual submitted batches. It is a foreground process, not a service. Keep the computer on and awake, TWS authenticated, networking working and the clock synchronized. Restart behavior is deliberately conservative, not unattended recovery. Broker maintenance or session replacement can halt it.

Start a second terminal with the same Python environment and run:

```bash
python -m quanttrading --config config/paper.json dashboard
```

Browse `http://127.0.0.1:8765`. It shows saved account snapshots, experiment P&L, positions, orders and stale/halt warnings. The server has no trading controls and is accessible only on the same computer. Do not open firewall/router access to it.

## 9. Install and use IBKR Mobile

On iPhone/iPad use Apple's App Store; on Android use Google Play. Search **IBKR Mobile** and verify the official Interactive Brokers publisher, or follow the store links on IBKR's official Mobile page. No device installation was performed here.

From the login screen, select **Log in to Paper Trading** (often under the three-dot menu), then authenticate with the appropriate account credentials. Confirm PAPER and the account number, and inspect Portfolio, Orders/Trades and Account/P&L. Menu labels can vary. Do not place manual trades in the strategy's dedicated paper account; the inventory reconciliation will correctly block the algorithm if it detects changes.

**Session-conflict warning:** official IBKR guidance says Mobile's read-only access can still request the real-time market-data session and disconnect desktop TWS. Read-only Mobile is NOT a guarantee of simultaneous access. If a prompt would replace/disconnect TWS, cancel it while the algorithm is running. Prefer inspecting Mobile between supervised runs until your exact session/data entitlements are verified. Use the localhost dashboard during an active desktop run. Do not assume an additional live username automatically resolves paper-account session limits.

Phone P&L describes the broker's simulated account. It does not certify the Python process is running, provide historical strategy comparisons, or keep the computer awake. A phone login that disrupts TWS can stop new orders; inspect the desktop before restarting.

## 10. Stop, reconcile and restart

```bash
python -m quanttrading --config config/paper.json paper-stop --cancel
```

This creates a persistent STOP and attempts cancellation only for this application's account/client/order references. It does NOT liquidate holdings, issue a global cancel or cancel manual orders. It works as a local halt even if the broker cannot be reached, but remote cancellation may then fail. Inspect TWS directly.

A daily-loss or drawdown breach similarly blocks new orders; it does not guarantee losses stop at the configured threshold. Existing positions remain exposed until you deliberately manage them in the simulator. This differs from the research engine's assumed next-open risk exit and must be considered when comparing results.

Restart only after checking actual positions, executions, pending orders, network/data session, ledger and risk limits. Uncertain fills, manual inventory changes or stock splits need deliberate reconciliation; no automatic adoption/reset tool is provided. Preserve evidence. Do not remove STOP or reset/delete the database merely to resume trading.

Never expose local ports, store broker passwords in config, bypass 2FA or convert this package into real-money execution by renaming accounts/ports. Live deployment needs a separate engineering and risk review.
