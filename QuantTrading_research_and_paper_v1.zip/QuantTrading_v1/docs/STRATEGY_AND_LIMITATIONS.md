# Strategy mathematics, accounting and research limits

These are implementation definitions and research hypotheses, not financial forecasts. Read source functions and tests alongside this document. No parameter has been selected based on demonstrated market profitability in this build.

## 1. Prices and information time

Daily adjusted close is the signal series. Define P[i,t] as the vendor-adjusted close for instrument i on exchange session t. Adjusted open is raw open multiplied by adjusted-close/raw-close. This is a synthetic total-return-unit approximation, not a reconstruction of historical tradable share counts.

Returns are r[i,t] = P[i,t]/P[i,t-1] - 1. Signal calculations use only rows through t. A decision at close t can execute no earlier than the next trading session. Exchange calendars determine sessions and close timestamps, including early closes. Missing sessions are errors, not forward-filled flat prices.

The historical simulator uses fractional synthetic units so that vendor adjustments are coherent. It does not also credit dividends, cash distributions or split shares, which would double-count adjustments. Paper execution instead holds actual integer shares; IBKR handles actual corporate actions. A split that breaks the local expected-quantity ledger deliberately halts operation pending review.

Adjusted Yahoo observations are not independently verified here. Their licensing, availability and revisions are outside the program's control. Check selected prices and corporate-action periods against an independent, convention-matched source.

## 2. Momentum

SMA[n,t] is the arithmetic average of the last n adjusted closes. The default eligible trend is:

```text
P[t] > SMA20[t] > SMA50[t] > SMA200[t]
ROC63[t]  = P[t]/P[t-63]  - 1 > 0
ROC126[t] = P[t]/P[t-126] - 1 > 0
Relative strength = ROC126[stock,t] - ROC126[SPY,t] > 0
```

Annualised volatility is the rolling sample standard deviation of daily returns multiplied by sqrt(252), using 63 sessions by default. An instrument is ineligible above 60% annualised volatility or below average daily dollar volume of USD 20 million. A volume-confirmation ratio is configurable; its default threshold is zero, so that extra filter is off rather than assumed useful.

Momentum rank score = 0.5 * ROC63 + 0.5 * ROC126 + relative strength. Moving-average windows express short/medium/long trend hypotheses. Relative strength tries to distinguish a stock's trend from a broad-market move. These choices may be redundant and are not empirically validated here.

## 3. Annual fundamentals and publication timing

The SEC companyfacts adapter extracts annual US-GAAP revenue, net income and operating cash flow. Growth compares current/prior-year values in the SAME accession, not the latest restatement applied retroactively:

```text
Revenue growth = revenue_current/revenue_prior - 1
Earnings growth = net_income_current/net_income_prior - 1
Net margin = net_income_current/revenue_current
Cash-flow margin = operating_cash_flow_current/revenue_current
```

The default filters require both growth rates above zero and both margins above 5%. Prior earnings/revenue must be positive for comparable growth; turnaround firms with negative prior net income are excluded rather than given an unstable percentage growth score.

Each event carries period_end, available_at, accession and source. The SEC endpoint supplies a filing date; this adapter makes it usable at midnight New York on the following calendar day, then uses a backward-only join at actual session closes. This is a conservative **filing-date proxy**, not an exact earnings-release or filing-acceptance timestamp. It can omit information that the market knew earlier. The current SEC collection is not a certified vintage database; review original filings and retain raw snapshots before treating it as point-in-time research evidence.

Ambiguous facts, durations, same-day filing collisions and unsupported mappings are skipped or fail the download with an audit. Late amendments to older periods do not displace a more recent fiscal period. A missing or older-than-400-day event makes a name ineligible. Company ratios are never assigned to ETFs.

The bounded fundamental rank score sums included ratios clipped to [-1,1] to reduce near-zero-denominator dominance. Combined ranking adds eligible momentum and fundamental percentile ranks after both filters pass. Fundamental-only uses the fundamental gate and score, with the same common liquidity/volatility and portfolio risk rules. Feature ablations replace the fundamental feature set with one variable; they deliberately preserve the complete-data availability sample.

Not implemented: analyst estimate revisions, EPS forecasts, quarterly/TTM fundamentals, macroeconomic vintage series or a delisted/point-in-time historical stock universe. Revenue/net-income mapping is not universal across issuers. Sector buckets are manual static risk groups, not historically reconstructed sector memberships.

## 4. Portfolio construction

The strongest eligible names, at most four, receive inverse-volatility base weights: weight proportional to 1/volatility. The implementation scales/caps these to a 60% maximum gross budget, 15% per name, 30% per manual sector group and 30% for each highly correlated neighbourhood (correlation >= 0.85 on a 126-session window).

Estimated annual portfolio volatility is computed from past return covariance and the candidate weights. The weights are scaled down, never levered up beyond existing budgets, toward a 10% annualised target. Residual cash stays cash. Estimated correlation is unstable; this is a transparent heuristic, not a full factor/correlation-risk model.

Targets refresh weekly by default for execution on the next week's first trading session. Price drift and gaps can violate a limit between observations. Research stops are checked on daily closes. Paper hard limits are checked on snapshots and before each order; missing information blocks new orders.

## 5. Historical accounting and costs

At close t, record equity and target weights. Desired units for t+1 are calculated from close-t equity and prices, not t+1 open information. At the next adjusted open, process sells first, then buys, reducing buys if actual cash cannot fund them. No negative cash, leverage or shorting is allowed.

Default model per side:

```text
Commission = max(USD 1, notional * 0.0001)
Buy fill = adjusted_open * (1 + (2.5 + 2.5)/10,000)
Sell fill = adjusted_open * (1 - (2.5 + 2.5)/10,000)
```

The 2.5 basis points represent half-spread and another 2.5 represent slippage. These are hypothetical parameters, not a verified IBKR fee quote. Market impact, taxes, settlement constraints, FX, cash interest and detailed order-book execution are not simulated. Small rebalance trades below USD 25 are omitted; full exits are still attempted. Cost-stress results double commission, its minimum, half-spread and slippage.

FIFO matched lots allocate entry and exit costs. Closed-lot win rate and profit factor do not count still-open positions. Multiple partial matches can create more closed lots than economic trading ideas. Portfolio equity includes all open positions marked to market. There is no forced terminal liquidation or artificially credited final exit.

A 10% close-based position stop, 2% portfolio daily loss or 10% portfolio drawdown causes a modeled next-open risk exit. Drawdown shutdown stays latched for the rest of that run. A market gap can produce a much larger loss. Each annual fold restarts capital/risk state, so annual results are not automatically a continuous tradable equity curve.

## 6. Validation and metrics

The report compares momentum, fundamental and combined strategies on the same six equity names. SPY/QQQ buy-and-hold are full-investment references, not risk-matched competitors. A same-equity passive portfolio uses a conservative initial budget but has no ongoing active stop/correlation overlay. Read exposure before attributing risk reduction to a signal.

Research begins in 2020 after 2018-2019 warmup. The default holdout begins in 2024 and is independently restarted, with fixed parameters. Annual 2021+ rolling-origin evaluations reuse earlier observations for indicators while restarting the portfolio each year. There is no fitted model and no optimisation disguised as walk-forward training.

Annualised return uses 252 trading sessions. Annualised volatility uses daily-return standard deviation * sqrt(252). Sharpe uses mean daily return / standard deviation * sqrt(252), with zero risk-free/cash yield assumed. Maximum drawdown measures decline from the running peak. Cost and exposure metrics qualify any comparison.

Paired circular 10-session block resampling, 1,000 deterministic-seed samples, estimates uncertainty for the arithmetic annualised mean daily return difference (combined minus baseline). This is NOT a probability that the strategy will be profitable, a CAGR confidence interval, or a multiple-testing-adjusted significance test. Limited regimes, selection bias and data errors remain.

Repeatedly inspecting 2024-2025 results and changing thresholds destroys its status as untouched holdout evidence. Optional feature comparisons are exploratory. Freeze rules and retain genuinely later data/forward paper observations before claiming generalisation. No numeric pass/fail profitability threshold is hardcoded.

## 7. Paper execution is a different model

Paper uses integer shares and actual currently received bid/ask quotes after the open, not historical adjusted units at the opening print. Plans size from the last completed close, apply current-price caps and reserve cash. It is therefore normal for paper and historical results to diverge even before simulator effects.

Order constraints: local verified paper account, USD reporting, exact approved contracts, no manual holdings, live two-sided quotes, maximum spread, fresh plan, what-if preflight, integer quantities, fixed DAY limit prices and regular hours. Partial fills, changed inventory, lost connectivity, unknown status or expired plans halt instead of guessing.

The virtual USD 10,000 experiment budget equals initial budget plus broker net-liquidation change since baseline. It is valid only in the dedicated account with no resets/deposits/manual activity. Broker account-level daily P&L is measured against that budget for the loss limit. Account values and marks are snapshots, not guaranteed executable liquidation prices.

Crucial difference: a paper daily-loss/drawdown failure **blocks new orders and latches STOP; it does not automatically liquidate positions**. The backtest assumes next-open portfolio risk exits. A genuine paper comparison must log that operating difference and any manual intervention rather than silently merging the results.

The paper simulator itself is not a real exchange; simulated fill quality, queue priority and costs can differ from live trading. No live-money execution path is included or authorised by this build.
