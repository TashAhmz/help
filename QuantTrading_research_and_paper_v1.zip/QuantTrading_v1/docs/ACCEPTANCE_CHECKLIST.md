# Acceptance checklist

## Delivered evidence

- [x] Core project builds as a Python package (see final build/verification receipt).
- [x] Offline unit/integration suite passes (exact count and versions in verification.json).
- [x] Synthetic end-to-end data, strategy, simulation and report workflow is exercised.
- [x] Simulated broker success, duplicate reservation, unknown send and partial-fill failure paths are tested.
- [ ] Real Yahoo download and independent price checks completed locally.
- [ ] SEC network downloads, tag coverage and selected original filings checked locally.
- [ ] Optional provider/broker dependencies installed successfully on the user's OS.
- [ ] An authenticated read-only TWS connection, live quotes and daily P&L verified.
- [ ] Any actual IBKR paper order or fill executed and reconciled.
- [ ] Strategy profitability established. No such claim is made.

## Before enabling paper submission

- [ ] Run the unmodified offline tests with the selected virtual environment.
- [ ] Review real data manifests, missing sessions, corporate actions and coverage.
- [ ] Independently compare selected prices and selected filing-derived ratios/timestamps.
- [ ] Freeze a configuration and inspect holdout, annual, exposure and cost-stress outputs.
- [ ] Confirm TWS says PAPER and the allowlisted account is exactly correct.
- [ ] Verify USD reporting, dedicated flat account, zero open orders and valid P&L.
- [ ] Verify live two-sided API quotes for the selected universe; delayed data is not sufficient.
- [ ] Initialise and preserve the experiment baseline; do not reset account cash afterwards.
- [ ] Check localhost-only socket settings after any TWS update.
- [ ] Generate a plan with orders disabled; review quantities, prices, limits and source dates.
- [ ] Understand stop behavior: blocked orders do not automatically liquidate existing holdings.
- [ ] Verify how to stop/cancel in TWS and through the local command.
- [ ] Keep the first explicit paper batch supervised and inspect all fills/fees.
- [ ] Reconcile actual quantities with the local ledger before foreground execution.
- [ ] Confirm phone login will not disrupt the session, or use phone between runs.

Unticking a safety setting or editing a plan to bypass a failure does not satisfy a check. Remain in research/plan-only mode when any material check is unresolved.
