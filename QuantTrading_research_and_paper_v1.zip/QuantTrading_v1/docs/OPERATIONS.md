# Operations, logs and failure handling

## Evidence locations

- `data/runs/<id>/manifest.json`: completed/failed state, source metadata and file hashes.
- Per instrument: preserved provider output, normalized data, `quality.json`, metadata.
- Fundamentals: chosen CSV, `.metadata.json`, `<stem>_source/` raw filings and parsing audit.
- `reports/<id>/`: exact configuration, data lineage, HTML, metrics, equity, fills, closed lots and targets.
- `runtime/paper.sqlite`: baseline, snapshots, ledger, reserved daily batches and event journal. Treat this as private financial metadata.
- `runtime/STOP`: persistent shutdown reason. Preserve it while investigating.
- `runtime/status.json`: last broker snapshot; dashboard labels snapshots older than 180 seconds stale.
- `runtime/last_submission.json`: last attempted paper batch and returned execution details.
- `runtime/cycles/<date_time>/`: fresh inputs and the exact reviewed plan for a cycle.

Use the same config/state directory throughout one experiment. Review `state.py` for the actual SQLite filename and schema before building external tooling. Do not run two execution processes, change client IDs to evade open-order checks, or mix manual orders into the dedicated account.

## Before each supervised session

Check the correct PAPER TWS login, account number, USD reporting, data subscriptions and local socket settings. Confirm computer clock, network, no sleep, no unrelated positions/open orders and no STOP. Inspect the latest real-data quality reports and fundamental coverage. Do not treat an empty dataset or zero eligible names as an instruction to relax filters.

The first session cycle consumes previous completed daily prices. Weekly rebalance normally acts on the first session of the week; stops can act on other days. Exchange-calendar logic, not a fixed London clock time, controls the order window. Missing the scheduled rebalance day can mean waiting for the next scheduled rebalance; this version does not silently replay missed days.

## During and after execution

Observe TWS during first paper batches. The program persists reservations before sending, logs broker what-if results and records execution identifiers/known commissions. A commission can be unavailable at the time of a fill receipt; use broker statements for authoritative final commissions. Snapshot P&L is not a complete fill-level performance attribution system.

The full foreground loop obtains snapshots at 120-second intervals. It is not tick-by-tick risk monitoring, a 24/7 managed service or a guarantee against gap losses. Mobile login and broker maintenance can interrupt the session. On errors the loop stops; it does not automatically authenticate, reconnect and resume placing orders.

Archive configurations, report summaries and downloaded snapshots after each research decision. Do not overwrite data or reset virtual capital to improve reported performance. Record every manual intervention and why it occurred.

## Unknown fill or interrupted process

1. Stop the local loop. Run `paper-stop --cancel` using the same config if possible.
2. Inspect the PAPER account in TWS for all open orders, actual fills, quantities and cash.
3. Preserve runtime SQLite, STOP, plan, last submission and TWS execution evidence.
4. Reconcile the pending batch and expected positions before any restart. Unknown sends are not retried automatically.
5. After an operator has resolved discrepancies, conduct a fresh read-only check and deliberate state recovery. No automated reset/reconciliation bypass is shipped.

If an order filled after the process died, the local ledger may not include it. If an order had an unknown cancellation, it may still be active. The correct response is reconciliation, not sending the same order again. Database batch reservations are a duplicate-reduction mechanism, not a mathematical guarantee against all distributed-system failures.

## Hard stop

```bash
python -m quanttrading --config config/paper.json paper-stop --cancel
```

Creates a local STOP even if broker cancellation fails. Attempts only this application's orders; never a global account cancellation. Existing positions stay open. Close positions manually in the simulator only as a deliberate intervention and then reconcile; the program will not pretend those manual changes are its own fills.

A local STOP is checked before sends, between orders and by the foreground monitor. It cannot revoke an already executed trade or guarantee instant broker cancellation. During disconnection, inspect TWS or the broker directly. Never remove the latch solely to make an error disappear.

## Backups and privacy

Back up run directories and the runtime ledger while no writer is active, or use SQLite's backup API. SQLite may use WAL files; copying only the main file during a write can miss recent state. Avoid exposing reports/account numbers on a public website or GitHub. Inspect `git status` before committing.

The local dashboard serves only a fixed page and saved status JSON on 127.0.0.1. It is not designed for internet exposure, authentication or phone remote access. Mobile uses IBKR's app and can conflict with the desktop market-data session. No notification service, task scheduler, VPS or secret manager has been configured for you.

## Unimplemented production work

External broker integration tests, robust corporate-action reconciliation, exact as-traded event accounting, multicurrency support, point-in-time universe construction, independent price reconciliation, richer fundamental vendors, professional execution analytics, continuous health alerts, supervised restart tooling and any live-trading approval remain separate work. Do not describe this as production-ready because unit tests pass.
