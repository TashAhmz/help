# Primary references

Reviewed 14 November 2026. These external references support provider/setup behavior, not the profitability of this implementation. Official IBKR pages sometimes describe different account products or login flows; verify the paper credentials and permissions actually shown for your account. Store menu labels and product terms can change.

## IBKR

- TWS API setup, read-only mode and usual port defaults: https://www.interactivebrokers.com/campus/trading-lessons/installing-configuring-tws-for-the-api/
- TWS official download: https://www.interactivebrokers.com/en/trading/download-tws.php
- Paper account creation/eligibility: https://www.interactivebrokers.com/support/faq/content/open-paper-trading-account-37128282
- Paper account settings: https://www.ibkrguides.com/clientportal/papertradingaccount.htm
- Paper real-time data sharing and trial limitations: https://www.interactivebrokers.com/support/faq/content/live-data-provided-paper-trading-26561453
- Official Mobile download links: https://www.interactivebrokers.com/support/faq/content/download-ibkr-mobile-97981509
- Choose paper mode before login: https://www.interactivebrokers.com/support/faq/content/switch-between-live-trading-paper-32669446
- Mobile paper login: https://www.interactivebrokers.com/support/faq/content/73506651
- Mobile read-only session conflict: https://www.interactivebrokers.com/support/faq/content/use-ibkr-mobile-read-only-107133840
- Paper simulation limitations: https://www.interactivebrokers.com/support/faq/content/limitations-paper-trading-account-35807733
- 2026 TWS API release notes, including 10.45 one-time settings change: https://www.ibkrguides.com/releasenotes/prod-2026.htm

## Data providers and library interfaces

- SEC EDGAR APIs: https://www.sec.gov/search-filings/edgar-application-programming-interfaces
- SEC developer access policy/User-Agent guidance: https://www.sec.gov/about/developer-resources
- SEC access guidance: https://www.sec.gov/search-filings/edgar-search-assistance/accessing-edgar-data
- yfinance project documentation and use restrictions: https://ranaroussi.github.io/yfinance/
- yfinance PriceHistory options: https://ranaroussi.github.io/yfinance/reference/yfinance.price_history.html
- Community ib_async 2.1.0 documentation: https://ib-api-reloaded.github.io/ib_async/
- ib_async method reference: https://ib-api-reloaded.github.io/ib_async/api.html
- ib_async source/version: https://github.com/ib-api-reloaded/ib_async
- Exchange calendars: https://github.com/gerrymanoim/exchange_calendars
- Python virtual environments: https://docs.python.org/3.13/library/venv.html
- VS Code environments: https://code.visualstudio.com/docs/python/environments

The Yahoo/SEC adapters and IBKR socket integration must still be exercised against genuine services on the target computer. No downloaded code or third-party font assets are bundled. Installed packages carry their own licenses; review provider data terms before redistributing observations or reports.
