from copy import deepcopy
from types import SimpleNamespace
import json
import numpy as np
import pandas as pd
import pytest
from quanttrading.settings import Settings
from quanttrading.calendar_utils import sessions
from quanttrading.research_data import MarketData
from quanttrading.paper import make_plan, submit_plan
from quanttrading.state import StateStore
import quanttrading.paper as paper

NOW=pd.Timestamp('2026-11-16T16:00:00Z')
ACCOUNT='DU123456'

class FakeBroker:
    def __init__(self, settings):
        self.settings=settings;self.account=ACCOUNT;self.readonly=True;self.sent=[];self.cancelled=0
        self.partial=False;self.fail=False;self.open_orders=[];self.inventory={}
    def __enter__(self):return self
    def __exit__(self,*args):pass
    def assert_connected(self):pass
    def snapshot(self):
        return dict(currency='USD',net_liquidation=1_000_000.,cash=1_000_000.,available_funds=1_000_000.,daily_pnl=0.,
                    positions=deepcopy(self.inventory),open_orders=deepcopy(self.open_orders),timestamp=NOW.isoformat())
    def quotes(self,symbols):
        return {s:dict(bid=100.,ask=100.02,bid_size=100,ask_size=100,timestamp=NOW.isoformat(),market_data_type=1,min_tick=.01,con_id=100+i)
                for i,s in enumerate(self.settings.universe) if s in symbols}
    def preflight(self,*args):return {'initial_margin_change':0.,'status':'PreSubmitted'}
    def place_and_wait(self,order,reference,store,check_continue):
        check_continue();assert self.readonly is False
        self.sent.append(order)
        if self.fail:raise ConnectionError('Injected disconnect/unknown submission')
        q=1 if self.partial else order['quantity'];s=order['symbol']
        old=self.inventory.get(s,{}).get('quantity',0)
        new=old+q*(1 if order['side']=='BUY' else -1)
        if new:self.inventory[s]={'quantity':new,'average_cost':order['limit_price'],'con_id':order['con_id']}
        else:self.inventory.pop(s,None)
        return {'status':'Cancelled' if self.partial else 'Filled','filled':q,'remaining':order['quantity']-q,'executions':[]}
    def cancel_owned(self):self.cancelled+=1;return []

@pytest.fixture
def scenario(tmp_path,monkeypatch):
    c=Settings();c.paper.strategy='momentum';c.paper.submit_enabled=True;c.paper.data_reviewed=True;c.paper.state_dir=str(tmp_path/'runtime')
    monkeypatch.setenv(c.paper.account_env,ACCOUNT)
    idx=sessions('2025-01-02','2026-11-13');rng=np.random.default_rng(1)
    close=pd.DataFrame(100+np.cumsum(rng.normal(0,.05,(len(idx),len(c.symbols))),axis=0),index=idx,columns=c.symbols)
    vol=close*0+1_000_000
    data=MarketData(close,close.copy(),close.copy(),vol*close,vol,{'source':'OFFLINE CONTROL FIXTURE', 'synthetic':False, 'verified_hashes':{'fixture':'hash'}})
    targets=pd.DataFrame(0.,index=idx,columns=c.universe);targets['AAPL']=.05;targets['MSFT']=.05
    monkeypatch.setattr(paper,'load_market_run',lambda *_:data)
    monkeypatch.setattr(paper,'build_signals',lambda *a,**k:SimpleNamespace(targets={'momentum':targets}))
    broker=FakeBroker(c)
    def factory(config,readonly=True):broker.readonly=readonly;return broker
    store=StateStore(tmp_path/'runtime');store.init_anchor(ACCOUNT,broker.snapshot(),c.paper.capital_usd)
    path=tmp_path/'plan.json'
    return c,data,broker,factory,store,path

def test_plan_never_submits(scenario):
    c,d,b,f,s,p=scenario
    make_plan(p.parent,None,c,p,broker_factory=f,now=NOW)
    assert not b.sent
    data=json.loads(p.read_text());assert len(data['orders'])==2 and data['paper_only'] is True

def test_synthetic_can_never_plan(scenario):
    c,d,b,f,s,p=scenario;d.source['synthetic']=True
    with pytest.raises(ValueError):make_plan(p.parent,None,c,p,broker_factory=f,now=NOW)
    assert not b.sent

def test_stale_market_data_blocks_plan(scenario):
    c,d,b,f,s,p=scenario
    for name in ['close','open','raw_close','dollar_volume','volume']:setattr(d,name,getattr(d,name).iloc[:-1])
    with pytest.raises(ValueError):make_plan(p.parent,None,c,p,broker_factory=f,now=NOW)
    assert not b.sent

def test_successful_simulated_submission_and_ledger(scenario):
    c,d,b,f,s,p=scenario
    make_plan(p.parent,None,c,p,broker_factory=f,now=NOW)
    result=submit_plan(p,c,ACCOUNT,broker_factory=f,now=NOW)
    assert result['status']=='completed' and len(b.sent)==2
    s.reconcile(ACCOUNT,b.inventory)
    assert not (s.folder/'STOP').exists()

def test_changed_inventory_cannot_submit(scenario):
    c,d,b,f,s,p=scenario
    make_plan(p.parent,None,c,p,broker_factory=f,now=NOW)
    b.inventory={'AAPL':{'quantity':1,'average_cost':100.,'con_id':100}}
    with pytest.raises(ValueError):submit_plan(p,c,ACCOUNT,broker_factory=f,now=NOW)
    assert not b.sent

def test_open_orders_block_batch(scenario):
    c,d,b,f,s,p=scenario
    make_plan(p.parent,None,c,p,broker_factory=f,now=NOW);b.open_orders=[{'order_id':1}]
    with pytest.raises(ValueError):submit_plan(p,c,ACCOUNT,broker_factory=f,now=NOW)
    assert not b.sent

def test_unknown_submission_stops_cancels_and_never_retries(scenario):
    c,d,b,f,s,p=scenario
    make_plan(p.parent,None,c,p,broker_factory=f,now=NOW);b.fail=True
    with pytest.raises(ConnectionError):submit_plan(p,c,ACCOUNT,broker_factory=f,now=NOW)
    assert len(b.sent)==1 and b.cancelled==1 and (s.folder/'STOP').exists()
    with pytest.raises(ValueError):submit_plan(p,c,ACCOUNT,broker_factory=f,now=NOW)
    assert len(b.sent)==1

def test_partial_fill_recorded_and_later_orders_not_sent(scenario):
    c,d,b,f,s,p=scenario
    make_plan(p.parent,None,c,p,broker_factory=f,now=NOW);b.partial=True
    result=submit_plan(p,c,ACCOUNT,broker_factory=f,now=NOW)
    assert result['status']=='review_required' and len(b.sent)==1 and (s.folder/'STOP').exists()
    s.reconcile(ACCOUNT,b.inventory)

def test_wrong_confirmation_no_orders(scenario):
    c,d,b,f,s,p=scenario
    make_plan(p.parent,None,c,p,broker_factory=f,now=NOW)
    with pytest.raises(ValueError):submit_plan(p,c,'U123456',broker_factory=f,now=NOW)
    assert not b.sent

def test_stop_added_after_plan_blocks_submission(scenario):
    c,d,b,f,s,p=scenario
    make_plan(p.parent,None,c,p,broker_factory=f,now=NOW);s.stop('operator stop')
    with pytest.raises(ValueError):submit_plan(p,c,ACCOUNT,broker_factory=f,now=NOW)
    assert not b.sent
