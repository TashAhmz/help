"""All fixture prices are invented for software tests, never market observations."""

import pandas as pd
import pytest

from quanttrading.config import INSTRUMENTS
from quanttrading.market_data import normalize_bars
from quanttrading.validation import expected_sessions

START, END = "2024-01-01", "2024-01-11"


def synthetic_response(instrument, start=START, end=END):
    dates = expected_sessions(instrument, start, end)
    raw = pd.DataFrame({
        "Open": 100.0, "High": 103.0, "Low": 98.0, "Close": 101.0,
        "Adj Close": 100.5, "Volume": 1000, "Dividends": 0.0,
        "Stock Splits": 0.0,
    }, index=dates.tz_localize(instrument.timezone))
    raw.index.name = "Date"
    metadata = {
        "symbol": instrument.symbol, "currency": instrument.currency,
        "exchangeTimezoneName": instrument.timezone,
        "instrumentType": instrument.instrument_type,
        "exchangeName": "SYNTHETIC_TEST_ONLY", "dataGranularity": "1d",
    }
    return raw, metadata


@pytest.fixture
def instrument():
    return INSTRUMENTS["SPY"]


@pytest.fixture
def response(instrument):
    return synthetic_response(instrument)


@pytest.fixture
def bars(response, instrument):
    return normalize_bars(response[0], instrument)
