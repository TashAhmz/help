from copy import deepcopy
from pathlib import Path
import json
import numpy as np
import pandas as pd
import pytest
from quanttrading.settings import Settings
from quanttrading.paper_safety import verify_account, validate_quote, validate_plan, limit_price, plan_digest, risk_capital, projected_weights
from quanttrading.state import StateStore

NOW=pd.Timestamp('2026-11-16T16:00:00Z')
ACCOUNT='DU123456'

def quote(**changes):
    q=dict(bid=100.,ask=100.02,bid_size=100,ask_size=100,timestamp=NOW.isoformat(),market_data_type=1,min_tick=.01,con_id=123)
    q.update(changes);return q

def plan(c):
    p=dict(paper_only=True,synthetic=False,created_at_utc=NOW.isoformat(),asof_session='2026-11-13',account=ACCOUNT,
           configuration_sha256=c.fingerprint(),orders=[dict(symbol='AAPL',side='BUY',quantity=1,limit_price=100.)])
    p['sha256']=plan_digest(p);return p

def enabled():
    c=Settings();c.paper.submit_enabled=True;c.paper.data_reviewed=True;return c

@pytest.mark.parametrize('account',['U123456','DUabc','', 'F1234','DU123456\n','DU'])
def test_nonpaper_identity_blocked(account):
    with pytest.raises(ValueError): verify_account(account,[account],Settings())

def test_exact_account_and_single_account_required():
    verify_account(ACCOUNT,[ACCOUNT],Settings())
    with pytest.raises(ValueError):verify_account(ACCOUNT,['DU999999'],Settings())
    with pytest.raises(ValueError):verify_account(ACCOUNT,[ACCOUNT,'DU999999'],Settings())

@pytest.mark.parametrize('changes',[
    {'market_data_type':2},{'market_data_type':3},{'market_data_type':4},
    {'bid':float('nan')},{'ask':float('inf')},{'bid':0},{'ask':99},
    {'ask':110},{'timestamp':'2026-11-16T15:59:00Z'},{'timestamp':'2026-11-16T16:01:00Z'},
    {'bid_size':0},{'con_id':0},{'min_tick':0}
])
def test_bad_quotes_blocked(changes):
    with pytest.raises(ValueError):validate_quote(quote(**changes),Settings(),NOW)

def test_good_quote_and_tick_rounding():
    validate_quote(quote(),Settings(),NOW)
    assert limit_price(quote(ask=100.021),'BUY')==100.03
    assert limit_price(quote(bid=100.019),'SELL')==100.01

def test_submit_is_disabled_by_default():
    c=Settings()
    with pytest.raises(ValueError):validate_plan(plan(c),c,ACCOUNT,NOW)

@pytest.mark.parametrize('change',[
    {'synthetic':True},{'paper_only':False},{'account':'U123456'},{'asof_session':'2026-11-12'},
    {'created_at_utc':'2026-11-16T15:00:00Z'},{'created_at_utc':'2026-11-16T16:10:00Z'}
])
def test_unsafe_plan_blocked(change):
    c=enabled();p=plan(c);p.update(change);p['sha256']=plan_digest(p)
    with pytest.raises(ValueError):validate_plan(p,c,ACCOUNT,NOW)

@pytest.mark.parametrize('change',[{'side':'SHORT'},{'quantity':-1},{'quantity':1.5},{'quantity':0},{'symbol':'EVIL'},
                                  {'limit_price':-1},{'quantity':100}])
def test_malformed_order_blocked(change):
    c=enabled();p=plan(c);p['orders'][0].update(change);p['sha256']=plan_digest(p)
    with pytest.raises(ValueError):validate_plan(p,c,ACCOUNT,NOW)

def test_modified_plan_or_settings_blocked():
    c=enabled();p=plan(c);p['orders'][0]['quantity']=2
    with pytest.raises(ValueError):validate_plan(p,c,ACCOUNT,NOW)
    p=plan(c);c.strategy.max_positions=3
    with pytest.raises(ValueError):validate_plan(p,c,ACCOUNT,NOW)

def test_weekend_no_orders():
    c=enabled();p=plan(c);p['created_at_utc']='2026-11-14T16:00:00Z';p['sha256']=plan_digest(p)
    with pytest.raises(ValueError):validate_plan(p,c,ACCOUNT,'2026-11-14T16:00:00Z')

def snapshot(**changes):
    p=dict(currency='USD',net_liquidation=1_000_000.,cash=1_000_000.,available_funds=1_000_000.,daily_pnl=0.,positions={},open_orders=[])
    p.update(changes);return p

def anchor():
    return dict(baseline_net_liquidation=1_000_000.,peak_net_liquidation=1_000_000.,budget=10000.)

@pytest.mark.parametrize('change',[
    {'currency':'GBP'},{'daily_pnl':None},{'daily_pnl':float('nan')},{'cash':-1},{'available_funds':-1},
    {'daily_pnl':-201},{'net_liquidation':998999}
])
def test_paper_risk_halts(change):
    with pytest.raises(ValueError):risk_capital(snapshot(**change),anchor(),Settings())

def test_risk_budget_not_million_dollar_paper_balance():
    assert risk_capital(snapshot(),anchor(),Settings())==10000
    assert risk_capital(snapshot(net_liquidation=999500),anchor(),Settings())==9500

def test_duplicate_batch_is_durably_blocked(tmp_path):
    s=StateStore(tmp_path);s.reserve('account:date',{'orders':[]})
    reloaded=StateStore(tmp_path)
    with pytest.raises(ValueError):reloaded.reserve('account:date',{'orders':[]})

def test_stop_latch_persists(tmp_path):
    s=StateStore(tmp_path);s.assert_running();s.stop('test')
    with pytest.raises(ValueError):StateStore(tmp_path).assert_running()

def test_anchor_cannot_be_silently_reset(tmp_path):
    s=StateStore(tmp_path);s.init_anchor(ACCOUNT,snapshot(),10000)
    with pytest.raises(ValueError):s.init_anchor(ACCOUNT,snapshot(),10000)

def test_fill_ledger_and_reconciliation(tmp_path):
    s=StateStore(tmp_path);s.init_anchor(ACCOUNT,snapshot(),10000);s.record_fill(ACCOUNT,'AAPL','BUY',2)
    s.reconcile(ACCOUNT,{'AAPL':{'quantity':2}})
    with pytest.raises(ValueError):s.reconcile(ACCOUNT,{'AAPL':{'quantity':3}})
    s.record_fill(ACCOUNT,'AAPL','SELL',2);s.reconcile(ACCOUNT,{})

def test_no_short_from_projected_orders():
    with pytest.raises(ValueError):projected_weights({},[dict(symbol='AAPL',side='SELL',quantity=1)],{'AAPL':quote()},10000)

def test_reserved_batch_status_survives_restart(tmp_path):
    s=StateStore(tmp_path);assert s.batch_status('x') is None
    s.reserve('x',{});assert StateStore(tmp_path).batch_status('x')=='reserved'
    s.finish('x','completed');assert StateStore(tmp_path).batch_status('x')=='completed'
