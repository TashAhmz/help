from hashlib import sha256
import json

import pandas as pd
import pytest

from quanttrading.config import INSTRUMENTS
from quanttrading.pipeline import run_pipeline
from quanttrading.plotting import plot_prices
from conftest import START, END, synthetic_response


def test_synthetic_pipeline_writes_auditable_snapshot(tmp_path):
    run, passed = run_pipeline(list(INSTRUMENTS.values()), START, END, tmp_path,
                               loader=synthetic_response, source_label="SYNTHETIC TEST DATA - NOT MARKET DATA")
    assert passed
    manifest = json.loads((run / "manifest.json").read_text())
    assert manifest["status"] == "structural_pass"
    assert not manifest["independent_price_accuracy_verified"]
    assert manifest["source"].startswith("SYNTHETIC")
    assert (run / "price_comparison.png").read_bytes().startswith(b"\x89PNG")
    for symbol in INSTRUMENTS:
        record = manifest["results"][symbol]
        for name, key in [("provider_output.csv", "provider_output_sha256"),
                          ("validated.csv", "validated_sha256")]:
            assert sha256((run / symbol / name).read_bytes()).hexdigest() == record[key]
        saved = pd.read_csv(run / symbol / "validated.csv", parse_dates=["date"])
        assert len(saved) == 7
        assert not saved.duplicated(["symbol", "date"]).any()


def test_partial_failure_blocks_combined_chart(tmp_path):
    def broken_loader(instrument, start, end):
        raw, metadata = synthetic_response(instrument, start, end)
        return (raw.iloc[1:] if instrument.symbol == "QQQ" else raw), metadata
    run, passed = run_pipeline([INSTRUMENTS["SPY"], INSTRUMENTS["QQQ"]], START, END,
                               tmp_path, loader=broken_loader, source_label="SYNTHETIC TEST DATA")
    assert not passed
    assert not (run / "price_comparison.png").exists()
    assert (run / "SPY" / "validated.csv").exists()
    assert (run / "QQQ" / "provider_output.csv").exists()
    assert not (run / "QQQ" / "validated.csv").exists()
    assert json.loads((run / "manifest.json").read_text())["status"] == "failed"


def test_provider_failure_is_recorded(tmp_path, instrument):
    def failed_loader(*args):
        raise ConnectionError("SYNTHETIC test failure")
    run, passed = run_pipeline([instrument], START, END, tmp_path, loader=failed_loader,
                               source_label="SYNTHETIC TEST DATA")
    assert not passed
    failure = json.loads((run / "SPY" / "failure.json").read_text())
    assert failure["error_type"] == "ConnectionError"
    assert not (run / "SPY" / "validated.csv").exists()


def test_rerun_creates_new_snapshot_not_overwrite(tmp_path, instrument):
    first, _ = run_pipeline([instrument], START, END, tmp_path, loader=synthetic_response,
                            source_label="SYNTHETIC TEST DATA")
    second, _ = run_pipeline([instrument], START, END, tmp_path, loader=synthetic_response,
                             source_label="SYNTHETIC TEST DATA")
    assert first != second
    assert (first / "manifest.json").exists()


def test_duplicate_symbols_rejected(tmp_path, instrument):
    with pytest.raises(ValueError, match="unique"):
        run_pipeline([instrument, instrument], START, END, tmp_path, loader=synthetic_response)


def test_unaligned_chart_is_rejected(tmp_path, bars):
    with pytest.raises(ValueError, match="aligned"):
        plot_prices({"A": bars, "B": bars.iloc[1:]}, tmp_path / "should_not_exist.png")
