import sys
from types import SimpleNamespace

import pandas as pd
import pytest

from quanttrading.config import check_dates
from quanttrading.market_data import DataError, FIELDS, fetch_history, normalize_bars
from conftest import START, END


def test_normalization_does_not_mutate_response(response, instrument):
    raw, _ = response
    original = raw.copy(deep=True)
    result = normalize_bars(raw, instrument)
    pd.testing.assert_frame_equal(raw, original)
    assert list(result.columns) == ["symbol", "date", *FIELDS.values()]
    assert result["date"].dt.tz is None
    assert result["symbol"].eq("SPY").all()
    assert result["close"].iloc[0] == 101.0
    assert result["adj_close"].iloc[0] == 100.5


def test_timezone_conversion_retains_exchange_dates(response, instrument):
    raw, _ = response
    raw.index = raw.index.tz_convert("UTC")
    result = normalize_bars(raw, instrument)
    assert result["date"].iloc[0] == pd.Timestamp("2024-01-02")


def test_timezone_is_required(response, instrument):
    raw, _ = response
    raw.index = raw.index.tz_localize(None)
    with pytest.raises(DataError, match="Timezone missing"):
        normalize_bars(raw, instrument)


def test_intraday_labels_are_rejected(response, instrument):
    raw, _ = response
    raw.index += pd.Timedelta(hours=1)
    with pytest.raises(DataError, match="midnight"):
        normalize_bars(raw, instrument)


@pytest.mark.parametrize("field", list(FIELDS))
def test_missing_provider_field_fails(response, instrument, field):
    with pytest.raises(DataError, match="Missing provider fields"):
        normalize_bars(response[0].drop(columns=field), instrument)


def test_capital_gains_are_preserved(response, instrument):
    raw, _ = response
    raw["Capital Gains"] = 0.25
    assert normalize_bars(raw, instrument)["capital_gains"].eq(0.25).all()


def test_no_automatic_deduplication(response, instrument):
    raw, _ = response
    duplicated = pd.concat([raw, raw.iloc[:1]])
    assert len(normalize_bars(duplicated, instrument)) == len(raw) + 1


def test_empty_response_fails(instrument):
    with pytest.raises(DataError, match="empty"):
        normalize_bars(pd.DataFrame(), instrument)


def test_nonnumeric_input_fails(response, instrument):
    raw, _ = response
    raw["Close"] = "broken"
    with pytest.raises(DataError, match="non-numeric"):
        normalize_bars(raw, instrument)


@pytest.mark.parametrize("start,end", [
    ("2024-01-02", "2024-01-01"), ("2024-01-01", "2024-01-01"),
    ("2024-02-30", "2024-03-01"), ("20240101", "2024-01-11"),
    ("2024-01-01", "2099-01-01"),
])
def test_invalid_date_ranges(start, end):
    with pytest.raises(ValueError):
        check_dates(start, end)


def test_adapter_explicit_parameters_and_metadata(monkeypatch, response, instrument):
    captured = {}
    raw, metadata = response
    class FakeTicker:
        def history(self, **kwargs):
            captured.update(kwargs)
            return raw
        def get_history_metadata(self):
            return metadata
    monkeypatch.setitem(sys.modules, "yfinance", SimpleNamespace(Ticker=lambda _: FakeTicker()))
    result, actual_metadata = fetch_history(instrument, START, END, attempts=1)
    assert result is not raw
    assert actual_metadata == metadata
    assert captured == {
        "start": START, "end": END, "interval": "1d", "prepost": False,
        "auto_adjust": False, "back_adjust": False, "actions": True,
        "repair": False, "keepna": True, "rounding": False,
        "timeout": 20, "raise_errors": True,
    }


def test_adapter_retries_transient_failure(monkeypatch, response, instrument):
    attempts = []
    class FakeTicker:
        def history(self, **kwargs):
            attempts.append(1)
            if len(attempts) == 1:
                raise TimeoutError("synthetic timeout")
            return response[0]
        def get_history_metadata(self):
            return response[1]
    monkeypatch.setitem(sys.modules, "yfinance", SimpleNamespace(Ticker=lambda _: FakeTicker()))
    monkeypatch.setattr("quanttrading.market_data.time.sleep", lambda _: None)
    fetch_history(instrument, START, END, attempts=2)
    assert len(attempts) == 2


def test_adapter_stops_on_rate_limit(monkeypatch, instrument):
    calls = []
    class YFRateLimitError(Exception):
        pass
    class FakeTicker:
        def history(self, **kwargs):
            calls.append(1)
            raise YFRateLimitError("synthetic rate limit")
    monkeypatch.setitem(sys.modules, "yfinance", SimpleNamespace(Ticker=lambda _: FakeTicker()))
    with pytest.raises(DataError, match="rate limit"):
        fetch_history(instrument, START, END)
    assert len(calls) == 1


def test_adapter_empty_download_fails(monkeypatch, instrument):
    class FakeTicker:
        def history(self, **kwargs):
            return pd.DataFrame()
    monkeypatch.setitem(sys.modules, "yfinance", SimpleNamespace(Ticker=lambda _: FakeTicker()))
    with pytest.raises(DataError, match="no daily bars"):
        fetch_history(instrument, START, END, attempts=1)
