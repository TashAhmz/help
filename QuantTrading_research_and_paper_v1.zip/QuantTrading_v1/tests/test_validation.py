import numpy as np
import pandas as pd
import pytest

from quanttrading.validation import expected_sessions, validate_bars
from conftest import START, END, synthetic_response
from quanttrading.market_data import normalize_bars


def quality(bars, instrument, response):
    return validate_bars(bars, instrument, START, END, response[1])


def test_valid_fixture_passes_structure_only(bars, instrument, response):
    report = quality(bars, instrument, response)
    assert report["structural_pass"]
    assert not report["independent_price_accuracy_verified"]
    assert report["rows"] == report["expected_sessions"] == 7
    assert report["warnings"] == []


def test_calendar_excludes_holidays_weekends_and_end(instrument):
    sessions = expected_sessions(instrument, START, END)
    assert pd.Timestamp("2024-01-01") not in sessions
    assert pd.Timestamp("2024-01-06") not in sessions
    assert pd.Timestamp(END) not in sessions
    assert sessions.max() == pd.Timestamp("2024-01-10")


def test_exceptional_2025_closure_is_not_treated_as_missing(instrument):
    sessions = expected_sessions(instrument, "2025-01-06", "2025-01-11")
    assert pd.Timestamp("2025-01-09") not in sessions
    assert len(sessions) == 4


def test_weekend_only_range_fails(instrument):
    with pytest.raises(ValueError, match="no scheduled"):
        expected_sessions(instrument, "2024-01-06", "2024-01-08")


def test_duplicate_key_fails(bars, instrument, response):
    bars = pd.concat([bars, bars.iloc[:1]], ignore_index=True).sort_values("date")
    report = quality(bars, instrument, response)
    assert not report["structural_pass"]
    assert report["duplicate_keys"] == 1


def test_missing_session_fails_without_filling(bars, instrument, response):
    bars = bars.drop(index=2)
    before = len(bars)
    report = quality(bars, instrument, response)
    assert not report["structural_pass"]
    assert report["missing_sessions"] == ["2024-01-04"]
    assert len(bars) == before


def test_nontrading_date_fails(bars, instrument, response):
    bars.loc[0, "date"] = pd.Timestamp("2024-01-01")
    report = quality(bars, instrument, response)
    assert not report["structural_pass"]
    assert "2024-01-01" in report["unexpected_sessions"]


@pytest.mark.parametrize("field,value", [
    ("close", np.nan), ("open", np.inf), ("adj_close", 0), ("low", -1),
    ("high", 99), ("low", 102), ("volume", -1), ("volume", 1.5),
    ("dividends", -0.5), ("stock_splits", -4),
])
def test_bad_numeric_value_fails(bars, instrument, response, field, value):
    if field == "volume" and value == 1.5:
        bars["volume"] = bars["volume"].astype(float)
    bars.loc[0, field] = value
    assert not quality(bars, instrument, response)["structural_pass"]


@pytest.mark.parametrize("key", ["symbol", "currency", "exchangeTimezoneName", "instrumentType"])
def test_wrong_metadata_fails(bars, instrument, response, key):
    response[1][key] = "WRONG"
    assert not quality(bars, instrument, response)["structural_pass"]


def test_zero_volume_warns_not_silently_removed(bars, instrument, response):
    bars.loc[0, "volume"] = 0
    report = quality(bars, instrument, response)
    assert report["structural_pass"] and report["review_required"]
    assert any("Zero volume" in message for message in report["warnings"])


def test_large_return_warns_not_silently_repaired(bars, instrument, response):
    bars.loc[1, "adj_close"] = 200.0
    report = quality(bars, instrument, response)
    assert report["structural_pass"] and report["review_required"]
    assert len(report["large_move_dates"]) == 2
    assert bars.loc[1, "adj_close"] == 200.0


def test_unsorted_dates_fail(bars, instrument, response):
    assert not quality(bars.iloc[::-1], instrument, response)["structural_pass"]


def test_dst_transition_is_preserved(instrument):
    raw, metadata = synthetic_response(instrument, "2024-03-08", "2024-03-13")
    bars = normalize_bars(raw, instrument)
    report = validate_bars(bars, instrument, "2024-03-08", "2024-03-13", metadata)
    assert report["structural_pass"]
    assert bars["date"].dt.strftime("%Y-%m-%d").tolist() == ["2024-03-08", "2024-03-11", "2024-03-12"]
