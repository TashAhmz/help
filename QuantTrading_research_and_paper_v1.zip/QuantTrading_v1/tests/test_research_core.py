from copy import deepcopy
from dataclasses import asdict
from pathlib import Path
import json
import numpy as np
import pandas as pd
import pytest
from quanttrading.settings import Settings, load_settings
from quanttrading.calendar_utils import sessions, session_close, previous_session, in_order_window, is_rebalance_close
from quanttrading.research_data import MarketData, load_market_run
from quanttrading.fundamentals import validate_fundamentals, align_fundamentals, parse_companyfacts
from quanttrading.risk import allocate, check_weights
from quanttrading.backtest import simulate
from quanttrading.performance import performance, paired_block_interval
from quanttrading.strategies import build_signals


def market(prices, dates=None, opens=None):
    if dates is None:
        dates = sessions('2024-01-02', '2024-02-15')[:len(prices)]
    close = pd.DataFrame({'AAPL': prices, 'SPY': np.linspace(100, 101, len(prices)), 'MSFT': np.array(prices)*1.1}, index=dates)
    op = close.copy()
    if opens is not None:
        op['AAPL'] = opens
    vol = close * 0 + 2_000_000
    return MarketData(close, op, close.copy(), vol * close, vol, {'source': 'SYNTHETIC TEST', 'synthetic': True})


def small_settings():
    c = Settings(universe=['AAPL', 'MSFT'])
    c.strategy.fast_ma=2
    c.strategy.middle_ma=3
    c.strategy.slow_ma=5
    c.strategy.momentum_short=2
    c.strategy.momentum_long=3
    c.strategy.volatility_window=5
    c.strategy.correlation_window=10
    c.strategy.rebalance='daily'
    c.strategy.min_dollar_volume=0
    c.strategy.max_volatility=5
    c.costs.commission_bps=0
    c.costs.minimum_commission=0
    c.costs.half_spread_bps=0
    c.costs.slippage_bps=0
    return c

@pytest.mark.parametrize('port', [7496,4001,0,1234])
def test_live_ports_rejected(port):
    c=Settings();c.paper.port=port
    with pytest.raises(ValueError): c.validate()

@pytest.mark.parametrize('host', ['0.0.0.0','192.168.1.2','example.com'])
def test_remote_hosts_rejected(host):
    c=Settings();c.paper.host=host
    with pytest.raises(ValueError): c.validate()

@pytest.mark.parametrize('value', [float('nan'),float('inf'),-1,0,1.1])
def test_risk_invalid(value):
    c=Settings();c.risk.max_gross=value
    with pytest.raises(ValueError): c.validate()

def test_config_typo_rejected(tmp_path):
    p=tmp_path/'config.json';p.write_text('{"max_positon":0.9}')
    with pytest.raises(ValueError): load_settings(p)

def test_default_configuration_roundtrip(tmp_path):
    c=Settings();p=tmp_path/'config.json';p.write_text(json.dumps(c.to_dict()))
    assert load_settings(p).fingerprint()==c.fingerprint()

def test_disabled_by_default():
    c=Settings();assert c.paper.submit_enabled is False and c.paper.data_reviewed is False

def test_calendar_holidays_earlyclose_dst():
    assert pd.Timestamp('2024-07-04') not in sessions('2024-07-01','2024-07-08')
    assert session_close('2024-11-29') == pd.Timestamp('2024-11-29T18:00:00Z')
    assert not in_order_window('2024-11-29T18:01:00Z')
    assert in_order_window('2024-03-11T13:45:00Z')
    assert not in_order_window('2024-03-08T13:45:00Z')
    assert not in_order_window('2026-11-14T17:00:00Z')
    assert previous_session('2024-07-05T15:00:00Z') == pd.Timestamp('2024-07-03')
    assert is_rebalance_close('2024-01-12','weekly')  # Monday holiday -> Tuesday still next ISO week.


def fundamentals(events=None):
    if events is not None:
        return pd.DataFrame(events)
    return pd.DataFrame([dict(symbol='AAPL',period_end='2023-09-30',available_at='2024-01-03T22:00:00Z',source='TEST',
                             revenue_growth=.1,earnings_growth=.1,net_margin=.2,cashflow_margin=.3)])

def test_fundamental_after_close_not_seen_until_next_session():
    idx=sessions('2024-01-02','2024-01-08')
    aligned=align_fundamentals(fundamentals(),idx,['AAPL','MSFT'],400)
    assert aligned['AAPL'].loc['2024-01-03'].isna().all()
    assert aligned['AAPL'].loc['2024-01-04','revenue_growth']==.1
    assert aligned['MSFT'].isna().all().all()

def test_fundamental_naive_time_rejected():
    f=fundamentals();f['available_at']='2024-01-03'
    with pytest.raises(ValueError): validate_fundamentals(f)

def test_fundamental_staleness():
    idx=sessions('2025-06-02','2025-06-04')
    assert align_fundamentals(fundamentals(),idx,['AAPL'],400)['AAPL'].isna().all().all()

def test_fundamental_future_does_not_backfill():
    f=fundamentals();future=f.copy();future['available_at']='2025-01-03T22:00:00Z';future['revenue_growth']=999
    idx=sessions('2024-01-02','2024-01-08')
    a=align_fundamentals(f,idx,['AAPL'],400)['AAPL']
    b=align_fundamentals(pd.concat([f,future]),idx,['AAPL'],400)['AAPL']
    pd.testing.assert_frame_equal(a,b)

def test_old_period_amendment_does_not_replace_recent_period():
    f=fundamentals();amend=f.copy();amend['period_end']='2022-09-30';amend['available_at']='2024-01-05T00:00:00Z';amend['revenue_growth']=99
    idx=sessions('2024-01-04','2024-01-08')
    result=align_fundamentals(pd.concat([f,amend]),idx,['AAPL'],400)['AAPL']
    assert (result.revenue_growth==.1).all()

def test_missing_fundamental_not_zero():
    f=fundamentals();f['net_margin']=np.nan
    with pytest.raises(ValueError): validate_fundamentals(f)

def test_duplicate_fundamental_rejected():
    f=fundamentals()
    with pytest.raises(ValueError): validate_fundamentals(pd.concat([f,f]))


def companyfacts():
    tags={'Revenues':(100,120),'NetIncomeLoss':(10,15),'NetCashProvidedByUsedInOperatingActivities':(20,25)}
    result={'facts':{'us-gaap':{}}}
    for tag,values in tags.items():
        rows=[]
        for year,value in zip((2022,2023),values):
            rows.append(dict(start=f'{year}-01-01',end=f'{year}-12-31',val=value,accn='original',form='10-K',filed='2024-02-01'))
        result['facts']['us-gaap'][tag]={'units':{'USD':rows}}
    return result

def test_sec_same_accession_ratios_and_availability():
    data,audit=parse_companyfacts(companyfacts(),'AAPL','SEC TEST')
    assert len(data)==1
    assert data.iloc[0].revenue_growth==pytest.approx(.2)
    assert data.iloc[0].earnings_growth==pytest.approx(.5)
    assert pd.Timestamp(data.iloc[0].available_at)==pd.Timestamp('2024-02-02T05:00:00Z')

def test_sec_future_restatement_not_used_in_original():
    payload=companyfacts()
    for tag,item in payload['facts']['us-gaap'].items():
        rows=[]
        for r in item['units']['USD']:
            r=deepcopy(r);r['accn']='later';r['filed']='2025-02-01'
            if r['end']=='2022-12-31':r['val']*=2
            rows.append(r)
        item['units']['USD'].extend(rows)
    data,_=parse_companyfacts(payload,'AAPL','SEC TEST')
    assert data.loc[data.accession.eq('original'),'revenue_growth'].iloc[0]==pytest.approx(.2)
    assert data.loc[data.accession.eq('later'),'revenue_growth'].iloc[0]==pytest.approx(-.4)

def test_sec_missing_comparable_not_guessed():
    payload=companyfacts();payload['facts']['us-gaap']['Revenues']['units']['USD'].pop(0)
    data,audit=parse_companyfacts(payload,'AAPL','SEC TEST')
    assert data.empty and audit['skipped']

def test_sec_conflicting_fact_rejected():
    payload=companyfacts();r=deepcopy(payload['facts']['us-gaap']['Revenues']['units']['USD'][1]);r['val']=999
    payload['facts']['us-gaap']['Revenues']['units']['USD'].append(r)
    data,_=parse_companyfacts(payload,'AAPL','SEC TEST');assert data.empty


def test_allocator_caps_and_cash():
    c=Settings();rng=np.random.default_rng(0)
    returns=pd.DataFrame(rng.normal(0,.01,(126,6)),columns=c.universe)
    candidates=pd.DataFrame({'score':range(6),'volatility':.2},index=c.universe)
    weights=allocate(candidates,returns,c)
    check_weights(weights,c,returns.corr())
    assert sum(weights.values())<=c.risk.max_gross and max(weights.values())<=c.risk.max_position

def test_correlation_cluster_cap():
    c=Settings(universe=['AAPL','MSFT','NVDA']);c.risk.max_sector=.9;c.risk.max_correlated=.2
    x=np.random.default_rng(0).normal(0,.01,126)
    r=pd.DataFrame({s:x for s in c.universe})
    cand=pd.DataFrame({'score':[3,2,1],'volatility':.2},index=c.universe)
    w=allocate(cand,r,c)
    assert sum(w.values())<=.2+1e-8

def test_invalid_target_not_accepted():
    d=market([100]*6);t=pd.DataFrame(1.1,index=d.dates,columns=['AAPL'])
    with pytest.raises(ValueError):simulate(d,t,small_settings(),str(d.dates[1].date()))

def test_trade_is_next_session_not_signal_session():
    d=market([100,100,200,200,200,200],opens=[100,100,200,200,200,200]);c=small_settings()
    t=pd.DataFrame(0.0,index=d.dates,columns=['AAPL']);t.iloc[1:,0]=.5
    result=simulate(d,t,c,str(d.dates[1].date()),risk_enabled=False)
    assert result.fills.iloc[0]['date']==d.dates[2]
    assert result.fills.iloc[0]['signal_date']==d.dates[1]
    assert result.equity.iloc[1].equity==pytest.approx(c.initial_capital)  # No ownership of the pre-fill price jump.

def test_flat_market_no_fees_conserves_cash_and_equity():
    d=market([100]*10);c=small_settings();t=pd.DataFrame(.5,index=d.dates,columns=['AAPL']);t.iloc[5:]=0
    result=simulate(d,t,c,str(d.dates[1].date()),risk_enabled=False)
    assert np.allclose(result.equity.equity,c.initial_capital)
    assert (result.equity.cash>=0).all()
    assert result.closed_lots.net_pnl.sum()==pytest.approx(0)

def test_fees_and_fifo_reconcile_roundtrip():
    d=market([100]*10);c=small_settings();c.costs.minimum_commission=2;c.costs.slippage_bps=10
    t=pd.DataFrame(.5,index=d.dates,columns=['AAPL']);t.iloc[5:]=0
    result=simulate(d,t,c,str(d.dates[1].date()),risk_enabled=False)
    assert result.equity.equity.iloc[-1]<c.initial_capital
    assert result.equity.equity.iloc[-1]-c.initial_capital==pytest.approx(result.closed_lots.net_pnl.sum())
    assert result.equity.cash.iloc[-1]==pytest.approx(result.equity.equity.iloc[-1])

def test_no_borrowing_on_large_open_gap():
    d=market([100,500,500,500,500,500]);c=small_settings();c.costs.minimum_commission=1
    t=pd.DataFrame(1.,index=d.dates,columns=['AAPL'])
    result=simulate(d,t,c,str(d.dates[1].date()),risk_enabled=False,buy_and_hold=True)
    assert result.equity.cash.min()>=-1e-6

def test_loss_stop_acts_next_open_and_latches():
    d=market([100,100,60,60,100,110]);c=small_settings();c.risk.max_drawdown=.1
    t=pd.DataFrame(.5,index=d.dates,columns=['AAPL'])
    result=simulate(d,t,c,str(d.dates[1].date()))
    sells=result.fills.loc[result.fills.side.eq('SELL')]
    assert sells.iloc[0]['date']==d.dates[3]
    assert result.equity.iloc[-1].gross_exposure==0

def test_adjusted_unit_rescaling_does_not_change_economic_results():
    d=market([100,101,103,102,105,104]);e=deepcopy(d);c=small_settings();c.costs.minimum_commission=1
    e.open['AAPL']*=.1;e.close['AAPL']*=.1
    t=pd.DataFrame(.5,index=d.dates,columns=['AAPL'])
    a=simulate(d,t,c,str(d.dates[1].date()),risk_enabled=False)
    b=simulate(e,t,c,str(e.dates[1].date()),risk_enabled=False)
    np.testing.assert_allclose(a.equity.equity,b.equity.equity)

def test_profit_factor_without_losses_is_null():
    d=market([100]*10);c=small_settings();t=pd.DataFrame(.5,index=d.dates,columns=['AAPL'])
    metric=performance(simulate(d,t,c,str(d.dates[1].date()),risk_enabled=False),c.initial_capital)
    assert metric['profit_factor_closed_fifo_lots'] is None

def test_bootstrap_paired_deterministic():
    r=pd.Series(np.random.default_rng(0).normal(0,.01,100))
    result=paired_block_interval(r,r,iterations=100)
    assert result['estimate']==0 and result['lower_95']==0 and result['upper_95']==0
    assert paired_block_interval(r[:10],r[:10])['available'] is False

def test_future_prices_do_not_change_prior_signals():
    dates=sessions('2023-01-03','2024-02-01');rng=np.random.default_rng(3)
    d=market(100*np.exp(np.cumsum(rng.normal(.001,.005,len(dates)))),dates)
    c=small_settings();c.strategy.min_dollar_volume=0
    cut=100
    e=deepcopy(d);e.close.iloc[cut:]*=3;e.open.iloc[cut:]*=3
    a=build_signals(d,c,None).targets['momentum']
    b=build_signals(e,c,None).targets['momentum']
    pd.testing.assert_frame_equal(a.iloc[:cut],b.iloc[:cut])

def test_last_only_matches_full_signal():
    dates=sessions('2023-01-03','2023-06-01');rng=np.random.default_rng(4)
    d=market(100*np.exp(np.cumsum(rng.normal(.001,.005,len(dates)))),dates)
    c=small_settings()
    a=build_signals(d,c,None).targets['momentum'].iloc[-1]
    b=build_signals(d,c,None,last_only=True).targets['momentum'].iloc[-1]
    pd.testing.assert_series_equal(a,b)

def test_missing_correlation_for_active_positions_is_not_approval():
    c=Settings();corr=pd.DataFrame([[1,np.nan],[np.nan,1]],index=['AAPL','MSFT'],columns=['AAPL','MSFT'])
    with pytest.raises(ValueError):check_weights({'AAPL':.1,'MSFT':.1},c,corr)

def test_fundamental_feature_selection_is_explicit():
    c=Settings();c.strategy.fundamental_features=['revenue_growth'];c.validate()
    c.strategy.fundamental_features=['imaginary_indicator']
    with pytest.raises(ValueError):c.validate()

def test_duplicate_feature_not_double_counted():
    c=Settings();c.strategy.fundamental_features=['net_margin','net_margin']
    with pytest.raises(ValueError):c.validate()
