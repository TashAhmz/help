# Start here: research first, then supervised paper trading

This is an executable Version 1 research and paper-trading implementation, not a certified production trading system. There is no live-trading mode. A working program is not proof of a profitable strategy.

## 1. Open the project

Extract the ZIP into a new folder. Keep the original milestone-1 project unchanged. Open **QuantTrading_v1**, the folder containing `pyproject.toml`, in VS Code. Run every command from this folder.

Install Python 3.13 and select the project's `.venv` interpreter in VS Code. The delivered offline tests ran on Python 3.13.5. Python 3.12 is declared supported but was not tested in this environment. Windows and macOS device-specific installation was not tested here.

### Windows PowerShell

```powershell
py -3.13 -m venv .venv
.\.venv\Scripts\python.exe -m pip install --upgrade pip
.\.venv\Scripts\python.exe -m pip install -e ".[all]"
.\.venv\Scripts\python.exe -m pytest -q
.\.venv\Scripts\python.exe -m quanttrading doctor
.\.venv\Scripts\python.exe -m quanttrading demo
```

These commands do not need an activation script or a PowerShell execution-policy change. For shorter commands below, activate with `.\.venv\Scripts\Activate.ps1`, or replace `python` with `.\.venv\Scripts\python.exe`.

### macOS / Linux

```bash
python3.13 -m venv .venv
source .venv/bin/activate
python -m pip install --upgrade pip
python -m pip install -e ".[all]"
python -m pytest -q
python -m quanttrading doctor
python -m quanttrading demo
```

Convenience equivalents are `scripts/setup.ps1` and `bash scripts/setup.sh`; inspect scripts before running. They install packages and run tests, not broker orders.

If only the optional market/broker installation fails, the offline core can be installed with `python -m pip install -e ".[dev]"`. This permits tests and the synthetic demo, NOT downloads or broker connectivity. Do not silently downgrade the broker library to get installation to pass.

## 2. Open the demo report

The command prints the exact path to `report.html`. Open it in your browser. It uses fictional, clearly labelled data to test the software. An example is also bundled at `examples/synthetic_report/report.html`.

Expected: equity and drawdown charts, holdout and annual tables, costs, execution records and provenance. Synthetic gains or losses are **not investment results**. Demo data is explicitly blocked from broker planning.

## 3. Run research on actual data

Read the data and methodology sections of `README.md`, then run the fetch/fundamentals/research commands. No IBKR account is needed for this stage. Network access and provider availability are needed. Inspect quality reports and check selected prices/filings independently before drawing conclusions.

## 4. Connect IBKR read-only

Follow `docs/IBKR_SETUP.md`. You must install TWS and IBKR Mobile on your own devices and complete account login/2FA. No account or device was configured on your behalf. Keep submission disabled while verifying the account, feeds and baseline.

## 5. Enable only supervised paper execution

After the acceptance checklist, explicitly enable paper submission in your local configuration, review a short-lived plan and submit it using the verified paper account number. Only then consider the foreground paper loop. Keep the computer awake and TWS running. Phone monitoring does not run the algorithm.

Important: paper fills differ from actual market execution. Live trading is deliberately not implemented. Never put account passwords, 2FA codes, access tokens or financial statements in a chat or public repository.
