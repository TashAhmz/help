"""Reproducible SYNTHETIC integration demo. Never substitute for real market data."""
from pathlib import Path
from hashlib import sha256
import numpy as np
import pandas as pd
from .settings import Settings
from .config import INSTRUMENTS
from .validation import expected_sessions
from .pipeline import run_pipeline, write_json
from .research import run_research


def demo_loader():
    def load(instrument, start, end):
        days = expected_sessions(instrument, start, end)
        seed = int(sha256(instrument.symbol.encode()).hexdigest()[:8], 16)
        rng = np.random.default_rng(seed)
        common = np.random.default_rng(2001).normal(0, 0.008, len(days))
        # Deliberately fictional regimes, including selloffs, for code-path coverage.
        drift = 0.00032 + 0.00040 * np.sin(np.arange(len(days)) / 170)
        shocks = rng.normal(0, 0.006, len(days))
        close = 100 * np.exp(np.cumsum(drift + common + shocks))
        opens = np.r_[close[0], close[:-1]] * np.exp(rng.normal(0, 0.002, len(days)))
        high = np.maximum(opens, close) * (1 + rng.uniform(0.001, 0.009, len(days)))
        low = np.minimum(opens, close) * (1 - rng.uniform(0.001, 0.009, len(days)))
        raw = pd.DataFrame({"Open": opens, "High": high, "Low": low, "Close": close,
                            "Adj Close": close, "Volume": rng.integers(2_000_000, 10_000_000, len(days)),
                            "Dividends": 0.0, "Stock Splits": 0.0}, index=days.tz_localize(instrument.timezone))
        return raw, {"symbol": instrument.symbol, "currency": "USD", "exchangeTimezoneName": instrument.timezone,
                     "instrumentType": instrument.instrument_type, "exchangeName": "SYNTHETIC", "dataGranularity": "1d"}
    return load


def synthetic_fundamentals(settings: Settings, years=range(2017, 2026)) -> pd.DataFrame:
    rows = []
    for i, symbol in enumerate(settings.universe):
        for year in years:
            phase = (year + i) % 4
            rows.append({"symbol": symbol, "period_end": f"{year-1}-12-31",
                         "available_at": f"{year}-03-01T22:00:00Z", "source": "SYNTHETIC TEST FIXTURE - NOT REAL FINANCIAL STATEMENTS",
                         "revenue_growth": 0.10 if phase else -0.05, "earnings_growth": 0.14 if phase else -0.10,
                         "net_margin": 0.16, "cashflow_margin": 0.18})
    return pd.DataFrame(rows)


def run_demo(settings: Settings, output: Path) -> Path:
    output.mkdir(parents=True, exist_ok=True)
    run, passed = run_pipeline([INSTRUMENTS[s] for s in settings.symbols], "2018-01-01", "2026-01-01",
                               output / "data", loader=demo_loader(), source_label="SYNTHETIC SOFTWARE TEST - NOT MARKET HISTORY")
    if not passed:
        raise RuntimeError("Synthetic integration data failed structural checks.")
    fundamental_path = run / "synthetic_fundamentals.csv"
    synthetic_fundamentals(settings).to_csv(fundamental_path, index=False)
    write_json(fundamental_path.with_suffix(".metadata.json"), {"synthetic": True, "csv_sha256": sha256(fundamental_path.read_bytes()).hexdigest()})
    return run_research(run, fundamental_path, settings, output / "reports")
