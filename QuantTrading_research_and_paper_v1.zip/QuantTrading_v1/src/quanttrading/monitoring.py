"""Read-only localhost monitor. Never bind publicly or expose the broker port."""
from functools import partial
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from html import escape
import json
from .reporting import STYLE

PAGE = '''<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>QuantTrading paper monitor</title><style>STYLE</style></head><body>
<p class="muted">QUANTTRADING / LOCAL PAPER MONITOR</p><h1>Paper account status</h1>
<div class="banner">PAPER ONLY. This page does not submit orders. Broker status is a saved snapshot, not a live feed.</div>
<p id="age">Loading saved snapshot...</p><div class="card"><table id="metrics"></table></div>
<h2>Positions</h2><div class="card"><pre id="positions"></pre></div><h2>Open orders</h2><div class="card"><pre id="orders"></pre></div>
<p>Refresh account evidence with <code>python -m quanttrading paper-status</code> or run the foreground monitor. Keep this server bound to 127.0.0.1.</p>
<p>IBKR Mobile shows broker positions and P&amp;L, not whether this Python process is healthy. A stale snapshot is not evidence that the account is safe.</p>
<script>
const put=(id,text)=>document.getElementById(id).textContent=text;
async function refresh(){try{const response=await fetch('/status.json',{cache:'no-store'});if(!response.ok)throw new Error('No broker snapshot yet');const s=await response.json();const age=(Date.now()-Date.parse(s.timestamp))/1000;
put('age',`${age>180?'STALE SNAPSHOT - ':''}Last broker snapshot: ${s.timestamp} (${Math.max(0,Math.round(age))} seconds ago)`);
let table=document.getElementById('metrics');table.replaceChildren();for(const [name,key] of [['Account','account_masked'],['Risk status','risk_status'],['Account net liquidation (USD)','net_liquidation'],['Experiment equity (USD)','experiment_equity'],['Experiment P&L (USD)','experiment_pnl'],['Broker daily P&L (USD)','daily_pnl']]){let row=document.createElement('tr');for(const text of [name,s[key]??'unavailable']){let cell=document.createElement('td');cell.textContent=String(text);row.appendChild(cell);}table.appendChild(row);}
put('positions',JSON.stringify(s.positions,null,2));put('orders',JSON.stringify(s.open_orders,null,2));}catch(e){put('age',String(e));}}
refresh();setInterval(refresh,10000);
</script></body></html>'''.replace("STYLE", STYLE)


def serve_monitor(state_dir: Path, port: int = 8765):
    if not 1024 <= port <= 65535:
        raise ValueError("Use an unprivileged valid local port.")
    class Handler(BaseHTTPRequestHandler):
        def do_GET(self):
            if self.path in ("/", "/index.html"):
                data, content_type = PAGE.encode(), "text/html; charset=utf-8"
            elif self.path == "/status.json" and (state_dir / "status.json").exists():
                status = json.loads((state_dir / "status.json").read_text(encoding="utf-8"))
                if (state_dir / "STOP").exists():
                    status["risk_status"] = "HALTED: STOP latch present. Inspect TWS and local journal."
                data, content_type = json.dumps(status, allow_nan=False).encode(), "application/json"
            else:
                self.send_error(404)
                return
            self.send_response(200)
            self.send_header("Content-Type", content_type)
            self.send_header("Cache-Control", "no-store")
            self.send_header("X-Content-Type-Options", "nosniff")
            self.send_header("Content-Length", str(len(data)))
            self.end_headers()
            self.wfile.write(data)
    print(f"Read-only local monitor: http://127.0.0.1:{port} (Ctrl+C to stop)")
    server = ThreadingHTTPServer(("127.0.0.1", port), Handler)
    try:
        server.serve_forever()
    finally:
        server.server_close()
