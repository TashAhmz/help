"""Deterministic long-only risk allocation shared by research and paper planning."""
import math
import numpy as np
import pandas as pd
from .settings import Settings


def check_weights(weights: dict[str, float], settings: Settings, correlation: pd.DataFrame | None = None) -> None:
    r = settings.risk
    if any(s not in settings.universe for s in weights):
        raise ValueError("Unknown portfolio symbol.")
    if any(not math.isfinite(w) or w < -1e-10 or w > r.max_position + 1e-9 for w in weights.values()):
        raise ValueError("Invalid or oversized position weight.")
    if sum(weights.values()) > r.max_gross + 1e-9:
        raise ValueError("Gross exposure limit exceeded.")
    for sector in set(settings.sectors.values()):
        if sum(w for s, w in weights.items() if settings.sectors[s] == sector) > r.max_sector + 1e-9:
            raise ValueError(f"Sector cap exceeded: {sector}")
    if correlation is not None:
        positive = [s for s, w in weights.items() if w > 1e-9]
        if any(s not in correlation for s in positive):
            raise ValueError("Missing correlation evidence.")
        if positive and not np.isfinite(correlation.loc[positive, positive].to_numpy()).all():
            raise ValueError("Incomplete correlation evidence for active positions.")
        for s in weights:
            if s not in correlation:
                raise ValueError("Missing correlation evidence.")
            cluster = [t for t in weights if t == s or correlation.loc[s, t] >= r.correlation_threshold]
            if sum(weights[t] for t in cluster) > r.max_correlated + 1e-9:
                raise ValueError("Correlated exposure cap exceeded.")


def allocate(candidates: pd.DataFrame, returns: pd.DataFrame, settings: Settings) -> dict[str, float]:
    """Rank, inverse-volatility size, then cap. Unallocated budget remains cash."""
    if candidates.empty:
        return {}
    r, st = settings.risk, settings.strategy
    selected = candidates.sort_values("score", ascending=False, kind="stable").head(st.max_positions)
    invvol = 1.0 / selected["volatility"]
    ideal = invvol / invvol.sum() * r.max_gross
    corr = returns.corr(min_periods=max(10, st.correlation_window // 2))
    covariance = returns.cov() * 252
    out = {}
    for symbol in selected.index:
        if not math.isfinite(float(ideal[symbol])) or selected.loc[symbol, "volatility"] <= 0:
            continue
        sector_left = r.max_sector - sum(w for s, w in out.items() if settings.sectors[s] == settings.sectors[symbol])
        proposed = min(float(ideal[symbol]), r.max_position, max(sector_left, 0), r.max_gross - sum(out.values()))
        trial = {**out, symbol: max(proposed, 0)}
        # Enforce every correlated neighbourhood, not only the newest pair.
        for centre in trial:
            cluster = [s for s in trial if s == centre or (pd.notna(corr.loc[centre, s]) and corr.loc[centre, s] >= r.correlation_threshold)]
            if symbol in cluster:
                room = r.max_correlated - sum(trial[s] for s in cluster if s != symbol)
                trial[symbol] = min(trial[symbol], max(room, 0))
        if trial[symbol] > 1e-8:
            out = trial
    if out:
        symbols = list(out)
        cov = covariance.loc[symbols, symbols].to_numpy()
        if not np.isfinite(cov).all():
            return {}  # Missing risk estimates must not increase allocation.
        w = np.array([out[s] for s in symbols])
        predicted = float(np.sqrt(max(w @ cov @ w, 0)))
        if predicted > r.target_volatility:
            out = {s: v * r.target_volatility / predicted for s, v in out.items()}
        check_weights(out, settings, corr)
    return out
