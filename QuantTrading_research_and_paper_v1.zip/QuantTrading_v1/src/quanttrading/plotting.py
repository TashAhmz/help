"""One diagnostic chart; these are not strategy returns."""

from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import pandas as pd


def plot_prices(frames: dict[str, pd.DataFrame], destination: Path) -> None:
    """Rebase each adjusted close series to 100 on the same first session."""
    if not frames:
        raise ValueError("No series to plot.")
    prices = pd.concat(
        {symbol: frame.set_index("date")["adj_close"] for symbol, frame in frames.items()},
        axis=1,
    ).sort_index()
    if prices.empty or prices.isna().any().any() or (prices <= 0).any().any():
        raise ValueError("Plot requires complete, aligned, positive adjusted closes.")
    indexed = prices.div(prices.iloc[0]).mul(100)
    fig, ax = plt.subplots(figsize=(11, 6))
    try:
        for symbol in indexed.columns:
            ax.plot(indexed.index, indexed[symbol], label=symbol, linewidth=1.7)
        ax.set(title="Adjusted close, rebased to 100", xlabel="Trading session",
               ylabel="Index (first shared session = 100)")
        ax.legend(title="Development universe")
        ax.grid(True, alpha=0.25)
        fig.text(0.5, 0.02, "Vendor-adjusted price history | Not strategy returns | No trading costs",
                 ha="center", fontsize=9)
        fig.tight_layout(rect=(0, 0.05, 1, 1))
        destination.parent.mkdir(parents=True, exist_ok=True)
        fig.savefig(destination, dpi=160)
    finally:
        plt.close(fig)
