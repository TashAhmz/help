"""Daily event-driven economic simulation, not an exchange or cash-settlement emulator.

Signals and desired quantities use the previous session close. Orders execute at
the following adjusted open plus explicit frictions. Adjusted prices imply synthetic
fractional total-return units; dividends/splits are NOT credited a second time.
"""
from collections import deque
from dataclasses import dataclass
import math
import numpy as np
import pandas as pd
from .calendar_utils import is_rebalance_close
from .settings import Settings
from .research_data import MarketData

@dataclass
class BacktestResult:
    equity: pd.DataFrame
    fills: pd.DataFrame
    closed_lots: pd.DataFrame
    decisions: pd.DataFrame

FILL_COLUMNS = ["date", "signal_date", "symbol", "side", "units", "price", "notional", "commission", "spread_slippage_cost"]
LOT_COLUMNS = ["symbol", "entry_date", "exit_date", "units", "net_pnl", "return_on_cost"]


def simulate(data: MarketData, targets: pd.DataFrame, settings: Settings,
             start: str, end: str | None = None, *, risk_enabled: bool = True,
             buy_and_hold: bool = False) -> BacktestResult:
    if targets.empty or not targets.index.equals(data.dates):
        raise ValueError("Target index must match the full price history.")
    if not np.isfinite(targets.to_numpy()).all() or (targets < 0).any().any() or (targets.sum(axis=1) > 1 + 1e-9).any():
        raise ValueError("Targets must be finite, long-only and unlevered.")
    symbols = list(targets.columns)
    if any(s not in data.close for s in symbols):
        raise ValueError("Target symbol missing from prices.")
    selected = (data.dates >= pd.Timestamp(start))
    if end is not None:
        selected &= data.dates <= pd.Timestamp(end)
    indices = np.flatnonzero(selected)
    if len(indices) < 2 or indices[0] == 0:
        raise ValueError("Need at least two evaluation sessions plus previous-session history.")
    prices, opens = data.close[symbols].to_numpy(), data.open[symbols].to_numpy()
    weights = targets[symbols].to_numpy()
    if not np.isfinite(prices).all() or not np.isfinite(opens).all() or (prices <= 0).any() or (opens <= 0).any():
        raise ValueError("Prices must be positive and finite.")
    cash = float(settings.initial_capital)
    qty = np.zeros(len(symbols))
    lots = {s: deque() for s in symbols}
    fills, closed, rows, decisions = [], [], [], []
    previous_nav = cash
    peak = cash
    halted = False
    pending = weights[indices[0] - 1].copy()
    costs = settings.costs
    friction = (costs.half_spread_bps + costs.slippage_bps) / 10000
    fee_rate = costs.commission_bps / 10000
    def commission(notional):
        return max(costs.minimum_commission, notional * fee_rate)
    for i in indices:
        date = data.dates[i]
        if pending is not None:
            desired = pending * previous_nav / prices[i - 1]
            deltas = desired - qty
            # Sales precede purchases, but cash is debited only after simulated fills.
            for side in ("SELL", "BUY"):
                for j, symbol in enumerate(symbols):
                    delta = float(deltas[j])
                    if (side == "SELL" and delta >= -1e-9) or (side == "BUY" and delta <= 1e-9):
                        continue
                    amount = min(-delta, qty[j]) if side == "SELL" else delta
                    fill = opens[i, j] * (1 - friction if side == "SELL" else 1 + friction)
                    if side == "BUY":
                        amount = min(amount, max(0.0, (cash - costs.minimum_commission) / (fill * (1 + fee_rate))))
                    if amount <= 1e-9:
                        continue
                    notional = amount * fill
                    full_exit = side == "SELL" and desired[j] < 1e-9
                    if notional < costs.minimum_trade_notional and not full_exit:
                        continue
                    fee = commission(notional)
                    if side == "BUY":
                        cash -= notional + fee
                        qty[j] += amount
                        lots[symbol].append({"date": date, "qty": amount, "unit_cost": (notional + fee) / amount})
                    else:
                        cash += notional - fee
                        qty[j] = max(0.0, qty[j] - amount)
                        remaining = amount
                        while remaining > 1e-8:
                            if not lots[symbol]:
                                raise AssertionError("FIFO inventory underflow")
                            lot = lots[symbol][0]
                            matched = min(remaining, lot["qty"])
                            cost = matched * lot["unit_cost"]
                            pnl = matched * fill - fee * matched / amount - cost
                            closed.append({"symbol": symbol, "entry_date": lot["date"], "exit_date": date,
                                           "units": matched, "net_pnl": pnl, "return_on_cost": pnl / cost})
                            lot["qty"] -= matched
                            remaining -= matched
                            if lot["qty"] <= 1e-8:
                                lots[symbol].popleft()
                    fills.append({"date": date, "signal_date": data.dates[i-1], "symbol": symbol,
                                  "side": side, "units": amount, "price": fill, "notional": notional,
                                  "commission": fee, "spread_slippage_cost": abs(fill - opens[i, j]) * amount})
            pending = None
        nav = cash + float(qty @ prices[i])
        if cash < -1e-6 or nav <= 0 or not math.isfinite(nav):
            raise ValueError("Simulation breached cash/solvency constraints.")
        day_return = nav / previous_nav - 1
        peak = max(peak, nav)
        drawdown = nav / peak - 1
        current_weights = qty * prices[i] / nav
        rows.append({"date": date, "equity": nav, "cash": cash, "daily_return": day_return,
                     "drawdown": drawdown, "gross_exposure": float(current_weights.sum()),
                     **{f"weight_{s}": current_weights[j] for j, s in enumerate(symbols)}})
        reason = "hold"
        if not buy_and_hold and is_rebalance_close(date, settings.strategy.rebalance):
            pending, reason = weights[i].copy(), "scheduled_rebalance"
        if risk_enabled:
            if drawdown <= -settings.risk.max_drawdown:
                halted = True
            if halted or day_return <= -settings.risk.daily_loss:
                pending = np.zeros(len(symbols))
                reason = "drawdown_latch" if halted else "daily_loss_next_open_exit"
            else:
                for j, symbol in enumerate(symbols):
                    if qty[j] <= 1e-9:
                        continue
                    inventory = sum(l["qty"] for l in lots[symbol])
                    average_cost = sum(l["qty"] * l["unit_cost"] for l in lots[symbol]) / inventory
                    if prices[i, j] <= average_cost * (1 - settings.risk.close_stop):
                        if pending is None:
                            pending = current_weights.copy()
                        pending[j] = 0.0
                        reason = "close_stop_next_open_exit"
        if pending is not None:
            decisions.append({"signal_date": date, "reason": reason,
                              **{s: float(pending[j]) for j, s in enumerate(symbols)}})
        previous_nav = nav
    return BacktestResult(pd.DataFrame(rows).set_index("date"),
                          pd.DataFrame(fills, columns=FILL_COLUMNS),
                          pd.DataFrame(closed, columns=LOT_COLUMNS), pd.DataFrame(decisions))
