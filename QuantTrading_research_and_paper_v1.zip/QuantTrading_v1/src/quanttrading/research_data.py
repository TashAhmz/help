"""Load immutable validated runs; preserve adjusted-return vs executable-price distinction."""
from dataclasses import dataclass
from pathlib import Path
from hashlib import sha256
import json
import pandas as pd
import numpy as np
from .config import INSTRUMENTS
from .validation import validate_bars

@dataclass
class MarketData:
    close: pd.DataFrame
    open: pd.DataFrame
    raw_close: pd.DataFrame
    dollar_volume: pd.DataFrame
    volume: pd.DataFrame
    source: dict

    @property
    def synthetic(self) -> bool:
        return self.source.get("synthetic", False) or "SYNTHETIC" in str(self.source.get("source", "")).upper()

    @property
    def dates(self):
        return self.close.index


def load_market_run(path: Path, symbols: list[str]) -> MarketData:
    manifest = json.loads((path / "manifest.json").read_text(encoding="utf-8"))
    if manifest.get("status") not in ("structural_pass", "structural_pass_review_required"):
        raise ValueError("A failed, partial or in-progress data run cannot be used.")
    frames, digests = {}, {}
    for symbol in symbols:
        file = path / symbol / "validated.csv"
        digest = sha256(file.read_bytes()).hexdigest()
        if manifest["results"].get(symbol, {}).get("validated_sha256") != digest:
            raise ValueError(f"Checksum mismatch or missing symbol: {symbol}")
        frame = pd.read_csv(file, parse_dates=["date"])
        metadata = json.loads((path / symbol / "metadata.json").read_text())["provider_metadata"]
        result = validate_bars(frame, INSTRUMENTS[symbol], manifest["start_inclusive"],
                               manifest["end_exclusive"], metadata)
        if not result["structural_pass"]:
            raise ValueError(f"Revalidation failed for {symbol}: {result['errors']}")
        frames[symbol] = frame.set_index("date")
        digests[symbol] = digest
    index = frames[symbols[0]].index
    if any(not frame.index.equals(index) for frame in frames.values()):
        raise ValueError("All comparison assets must have identical complete session coverage.")
    def wide(column):
        return pd.DataFrame({s: f[column] for s, f in frames.items()}, index=index)
    close, raw_close = wide("adj_close"), wide("close")
    adjusted_open = wide("open") * close / raw_close
    if not np.isfinite(adjusted_open.to_numpy()).all() or (adjusted_open <= 0).any().any():
        raise ValueError("Invalid adjusted open.")
    return MarketData(close, adjusted_open, raw_close, wide("volume") * raw_close,
                      wide("volume"), {**manifest, "run_path": str(path.resolve()), "verified_hashes": digests})
