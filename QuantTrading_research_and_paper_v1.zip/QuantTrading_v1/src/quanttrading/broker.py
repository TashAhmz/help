"""IBKR adapter via ib_async 2.1.0. Lazy import; no username/password ever accepted.

Only localhost standard paper ports and an exact DU account allowlist are supported.
These are defensive checks, not cryptographic proof of a broker environment: the
operator must also verify PAPER in TWS before explicitly enabling submission.
"""
from pathlib import Path
import math
import os
import time
import pandas as pd
from .settings import Settings
from .calendar_utils import utc
from .paper_safety import verify_account, validate_quote

class PaperBroker:
    def __init__(self, settings: Settings, *, readonly: bool = True):
        self.settings = settings
        self.account = os.environ.get(settings.paper.account_env, "")
        verify_account(self.account, [self.account], settings)
        try:
            from ib_async import IB, Stock, LimitOrder
        except ImportError as exc:
            raise RuntimeError('Install the broker extra: python -m pip install -e ".[broker]"') from exc
        self.Stock, self.LimitOrder = Stock, LimitOrder
        self.ib = IB()
        self.ib.RequestTimeout = 15
        self.ib.RaiseRequestErrors = True
        self.readonly = readonly
        self.unhealthy = False
        self.contracts, self.details, self.streams = {}, {}, {}
        self.ib.errorEvent += self._error
        self.ib.disconnectedEvent += self._disconnected
        try:
            self.ib.connect(settings.paper.host, settings.paper.port, clientId=settings.paper.client_id,
                            timeout=12, readonly=readonly, account=self.account, raiseSyncErrors=True)
            verify_account(self.account, self.ib.managedAccounts(), settings)
            self.pnl_subscription = self.ib.reqPnL(self.account)
            self.ib.sleep(2)
        except Exception:
            self.ib.disconnect()
            raise
    def _error(self, req_id, code, message, contract=None):
        if code in (1100, 1101, 1102, 1300):
            self.unhealthy = True  # Reconnection must be inspected, never auto-resumed.
    def _disconnected(self):
        self.unhealthy = True
    def assert_connected(self):
        if self.unhealthy or not self.ib.isConnected():
            raise ConnectionError("Broker disconnected or session changed; orders blocked. Reconcile before reconnecting.")
        verify_account(self.account, self.ib.managedAccounts(), self.settings)
    def close(self):
        self.ib.disconnect()
    def __enter__(self):
        return self
    def __exit__(self, *_):
        self.close()
    def snapshot(self) -> dict:
        self.assert_connected()
        # Account updates are streamed. A new process also performs startup sync.
        self.ib.sleep(0.2)
        values = self.ib.accountSummary(self.account)
        def value(tag):
            candidates = [v for v in values if v.account == self.account and v.tag == tag]
            candidates = [v for v in candidates if v.currency == "USD"]
            if len(candidates) != 1:
                raise ValueError(f"Require exactly one USD {tag}; verify USD base currency.")
            number = float(candidates[0].value)
            if not math.isfinite(number):
                raise ValueError(f"Nonfinite {tag}.")
            return number
        positions = {}
        for p in self.ib.positions(self.account):
            quantity = float(p.position)
            if abs(quantity) < 1e-9:
                continue
            c = p.contract
            if c.secType != "STK" or c.currency != "USD" or c.symbol not in self.settings.universe:
                raise ValueError("Dedicated paper account contains an unsupported position; no automatic changes allowed.")
            if quantity < 0 or not quantity.is_integer() or c.symbol in positions:
                raise ValueError("Short, fractional or ambiguous broker position; reconcile manually.")
            positions[c.symbol] = {"quantity": int(quantity), "average_cost": float(p.avgCost), "con_id": int(c.conId)}
        open_trades = [t for t in self.ib.reqAllOpenOrders() if t.order.account == self.account and not t.isDone()]
        daily = float(self.pnl_subscription.dailyPnL)
        return {"timestamp": utc().isoformat(), "currency": "USD", "net_liquidation": value("NetLiquidation"),
                "cash": value("TotalCashValue"), "available_funds": value("AvailableFunds"),
                "daily_pnl": daily if math.isfinite(daily) and abs(daily) < 1e100 else None,
                "positions": positions,
                "open_orders": [{"order_id": t.order.orderId, "client_id": t.order.clientId,
                                 "order_ref": t.order.orderRef, "symbol": t.contract.symbol,
                                 "status": t.orderStatus.status} for t in open_trades]}
    def qualify(self, symbol: str):
        self.assert_connected()
        if symbol not in self.settings.universe:
            raise ValueError("Symbol is not in the approved paper universe.")
        if symbol not in self.contracts:
            details = self.ib.reqContractDetails(self.Stock(symbol, "SMART", "USD"))
            valid = [d for d in details if d.contract.symbol == symbol and d.contract.currency == "USD" and d.contract.secType == "STK"]
            if len(valid) != 1 or valid[0].contract.conId <= 0:
                raise ValueError(f"Ambiguous/unqualified contract: {symbol}")
            self.contracts[symbol], self.details[symbol] = valid[0].contract, valid[0]
        return self.contracts[symbol]
    def quotes(self, symbols: list[str]) -> dict:
        self.assert_connected()
        self.ib.reqMarketDataType(1)
        for symbol in symbols:
            contract = self.qualify(symbol)
            if symbol not in self.streams:
                self.streams[symbol] = self.ib.reqMktData(contract, "", False, False)
        self.ib.sleep(3)
        result = {}
        for symbol in symbols:
            ticker = self.streams[symbol]
            q = {"bid": float(ticker.bid), "ask": float(ticker.ask), "bid_size": float(ticker.bidSize),
                 "ask_size": float(ticker.askSize), "timestamp": pd.Timestamp(ticker.time).isoformat() if ticker.time else "",
                 "market_data_type": int(ticker.marketDataType), "con_id": int(self.contracts[symbol].conId),
                 "min_tick": float(self.details[symbol].minTick)}
            validate_quote(q, self.settings)
            result[symbol] = q
        return result
    def make_order(self, spec: dict, reference: str):
        if self.readonly:
            raise ValueError("This connection is read-only.")
        return self.LimitOrder(spec["side"], spec["quantity"], spec["limit_price"],
                               account=self.account, tif="DAY", outsideRth=False,
                               orderRef=reference, transmit=True)
    def preflight(self, spec: dict, reference: str):
        self.assert_connected()
        state = self.ib.whatIfOrder(self.qualify(spec["symbol"]), self.make_order(spec, reference))
        if getattr(state, "warningText", ""):
            raise ValueError("Broker what-if warning: " + state.warningText)
        # A missing response is not approval; do not infer permission from silence.
        if state is None or not getattr(state, "initMarginChange", ""):
            raise ValueError("Broker did not return a complete what-if response.")
        change = float(state.initMarginChange)
        if not math.isfinite(change) or abs(change) > 1e100:
            raise ValueError("Unusable broker margin preview.")
        return {"initial_margin_change": change, "status": state.status}
    def place_and_wait(self, spec: dict, reference: str, store, check_continue):
        self.assert_connected()
        order = self.make_order(spec, reference)
        store.event("intent_before_send", {"reference": reference, **spec})
        trade = self.ib.placeOrder(self.qualify(spec["symbol"]), order)
        store.event("order_sent", {"reference": reference, "order_id": trade.order.orderId})
        started = time.monotonic()
        while not trade.isDone() and time.monotonic() - started < self.settings.paper.order_wait_seconds:
            check_continue()
            self.assert_connected()
            self.ib.sleep(0.5)
        if not trade.isDone():
            self.ib.cancelOrder(trade.order)
            deadline = time.monotonic() + 10
            while not trade.isDone() and time.monotonic() < deadline:
                self.assert_connected()
                self.ib.sleep(0.5)
        executions = []
        for fill in trade.fills:
            commission = float(fill.commissionReport.commission)
            executions.append({"execution_id": fill.execution.execId, "time": str(fill.time),
                               "quantity": float(fill.execution.shares), "price": float(fill.execution.price),
                               "commission": commission if fill.commissionReport.currency and math.isfinite(commission) and abs(commission) < 1e100 else None,
                               "commission_currency": fill.commissionReport.currency})
        receipt = {"reference": reference, "order_id": trade.order.orderId,
                   "status": trade.orderStatus.status, "filled": float(trade.orderStatus.filled),
                   "remaining": float(trade.orderStatus.remaining), "executions": executions,
                   "broker_log": [{"time": str(x.time), "status": x.status, "message": x.message} for x in trade.log]}
        store.event("order_result", receipt)
        if not trade.isDone():
            raise ConnectionError("Order outcome/cancellation is UNKNOWN. Inspect TWS immediately; do not retry.")
        return receipt
    def cancel_owned(self) -> list[dict]:
        """Never use globalCancel: only this client, this account and QT-prefixed orders."""
        self.assert_connected()
        cancelled = []
        for trade in self.ib.reqOpenOrders():
            o = trade.order
            if (o.account == self.account and o.clientId == self.settings.paper.client_id
                    and o.orderRef.startswith("QT:") and not trade.isDone()):
                self.ib.cancelOrder(o)
                cancelled.append({"order_id": o.orderId, "reference": o.orderRef})
        self.ib.sleep(2)
        unresolved = [t for t in self.ib.openTrades() if t.order.account == self.account
                      and t.order.clientId == self.settings.paper.client_id and t.order.orderRef.startswith("QT:")]
        if unresolved:
            raise ConnectionError("Cancellation not confirmed for every owned order. Verify TWS manually.")
        return cancelled
