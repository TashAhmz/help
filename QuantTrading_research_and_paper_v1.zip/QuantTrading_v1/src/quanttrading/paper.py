"""Supervised PAPER workflow: read-only check -> baseline -> plan -> explicit submit.

No live account option, credential collection, login automation or unattended recovery.
"""
from copy import deepcopy
from hashlib import sha256
from pathlib import Path
import json
import math
import os
import time
import pandas as pd
from .settings import Settings
from .broker import PaperBroker
from .calendar_utils import utc, in_order_window, previous_session, is_rebalance_close
from .state import StateStore
from .paper_safety import validate_plan, validate_quote, limit_price, plan_digest, risk_capital, projected_weights
from .risk import check_weights
from .research_data import load_market_run
from .fundamentals import load_fundamentals, download_sec_fundamentals
from .strategies import build_signals
from .pipeline import write_json, run_pipeline
from .config import INSTRUMENTS


def _store(settings):
    return StateStore(Path(settings.paper.state_dir))


def _risk(broker, store, settings, snapshot):
    store.assert_running()
    store.reconcile(broker.account, snapshot["positions"])
    capital = risk_capital(snapshot, store.anchor(broker.account), settings)
    store.observe(broker.account, snapshot)
    return capital


def paper_status(settings: Settings, *, initialise: bool = False, confirm: str = "") -> dict:
    store = _store(settings)
    with PaperBroker(settings, readonly=True) as broker:
        snapshot = broker.snapshot()
        if initialise:
            if confirm != broker.account:
                raise ValueError("Repeat the verified PAPER account number in --confirm-paper to initialise the baseline.")
            if snapshot["positions"] or snapshot["open_orders"]:
                raise ValueError("Start with a flat, dedicated paper account and no open orders.")
            store.init_anchor(broker.account, snapshot, settings.paper.capital_usd)
        store.observe(broker.account, snapshot)
        display = {**snapshot, "account_masked": "DU..." + broker.account[-3:], "paper_only": True}
        try:
            anchor = store.anchor(broker.account)
            display["experiment_equity"] = anchor["budget"] + snapshot["net_liquidation"] - anchor["baseline_net_liquidation"]
            display["experiment_pnl"] = snapshot["net_liquidation"] - anchor["baseline_net_liquidation"]
            display["baseline_note"] = "Requires no deposits, resets, manual trades or unrelated positions in the dedicated paper account."
            try:
                _risk(broker, store, settings, snapshot)
                display["risk_status"] = "PASS at snapshot time only"
            except ValueError as exc:
                store.stop(str(exc))
                display["risk_status"] = "HALTED: " + str(exc)
        except ValueError:
            display["risk_status"] = "BASELINE NOT INITIALISED"
        write_json(store.folder / "status.json", display)
        return display


def make_plan(data_path: Path, fundamental_path: Path | None, settings: Settings,
              destination: Path, *, broker_factory=PaperBroker, now=None) -> Path:
    current = utc(now)
    store = _store(settings)
    store.assert_running()
    data = load_market_run(data_path, settings.symbols)
    if data.synthetic:
        raise ValueError("Synthetic data can NEVER create a broker order plan.")
    if not in_order_window(current):
        raise ValueError("Paper planning requires the exchange session's safe order window; weekends/holidays are blocked.")
    asof = previous_session(current)
    if data.dates[-1] != asof:
        raise ValueError("Download data through the previous completed US trading session before planning.")
    fundamentals = None
    fundamental_receipt = None
    if settings.paper.strategy in ("fundamental", "combined"):
        if fundamental_path is None:
            raise ValueError("This strategy requires genuine availability-dated fundamentals.")
        fundamentals = load_fundamentals(fundamental_path)
        meta_path = fundamental_path.with_suffix(".metadata.json")
        metadata = json.loads(meta_path.read_text(encoding="utf-8"))
        if metadata.get("synthetic") is not False or metadata.get("csv_sha256") != sha256(fundamental_path.read_bytes()).hexdigest():
            raise ValueError("Fundamentals provenance/hash check failed; synthetic or unverified data blocked.")
        if fundamentals.source.str.contains("SYNTHETIC", case=False).any():
            raise ValueError("Synthetic fundamentals blocked.")
        fundamental_receipt = {"path": str(fundamental_path.resolve()), "sha256": metadata["csv_sha256"]}
    signals = build_signals(data, settings, fundamentals, last_only=True)
    weights = signals.targets[settings.paper.strategy].loc[asof].to_dict()
    trailing = data.close[settings.universe].pct_change(fill_method=None).tail(settings.strategy.correlation_window)
    corr = trailing.corr()
    check_weights(weights, settings, corr)
    with broker_factory(settings, readonly=True) as broker:
        snapshot = broker.snapshot()
        if snapshot["open_orders"]:
            raise ValueError("Existing open orders block a new plan; reconcile them in TWS.")
        capital = _risk(broker, store, settings, snapshot)
        quotes = broker.quotes(settings.universe)
        positions = snapshot["positions"]
        rebalance = is_rebalance_close(asof, settings.strategy.rebalance)
        orders = []
        for symbol in settings.universe:
            held = positions.get(symbol, {}).get("quantity", 0)
            if symbol in positions and positions[symbol]["con_id"] != quotes[symbol]["con_id"]:
                raise ValueError("Held contract does not match the qualified strategy contract.")
            desired = math.floor(capital * weights.get(symbol, 0) / data.raw_close.loc[asof, symbol]) if rebalance else held
            # The last close can trigger a reduction on a non-rebalance day.
            if held:
                basis = positions[symbol]["average_cost"]
                if not math.isfinite(basis) or basis <= 0:
                    raise ValueError("Missing/invalid average-cost stop reference.")
                if data.raw_close.loc[asof, symbol] <= basis * (1 - settings.risk.close_stop):
                    desired = 0
            # Actual prices can gap; don't knowingly enter beyond the position cap.
            desired = min(desired, math.floor(capital * settings.risk.max_position / quotes[symbol]["ask"]))
            delta = desired - held
            if delta == 0:
                continue
            side = "BUY" if delta > 0 else "SELL"
            price = limit_price(quotes[symbol], side)
            quantity = min(abs(delta), math.floor(settings.paper.max_order_usd / price))
            if quantity <= 0:
                continue
            orders.append({"symbol": symbol, "side": side, "quantity": quantity, "limit_price": price,
                           "con_id": quotes[symbol]["con_id"]})
        orders.sort(key=lambda x: (x["side"] != "SELL", x["symbol"]))
        projected = projected_weights(positions, orders, quotes, capital)
        check_weights(projected, settings, corr)
        buy_cash = sum(o["quantity"] * o["limit_price"] for o in orders if o["side"] == "BUY")
        if buy_cash * 1.02 > min(snapshot["cash"], snapshot["available_funds"]):
            raise ValueError("Insufficient existing cash for planned purchases plus reserve; no sale proceeds assumed.")
        # Expiry starts after calculations and quote retrieval, not before them.
        plan = {"schema_version": 1, "paper_only": True, "synthetic": False,
                "created_at_utc": utc().isoformat() if now is None else current.isoformat(),
                "asof_session": str(asof.date()), "account": broker.account,
                "configuration_sha256": settings.fingerprint(), "strategy": settings.paper.strategy,
                "risk_capital_usd": capital, "rebalance": rebalance, "target_weights": weights,
                "positions_before": positions, "quotes": quotes, "orders": orders,
                "data_path": str(data_path.resolve()), "data_hashes": data.source["verified_hashes"],
                "fundamentals": fundamental_receipt,
                "correlations": corr.to_dict(), "note": "An order plan is not an order. Review before explicit paper submission."}
        plan["sha256"] = plan_digest(plan)
        destination.parent.mkdir(parents=True, exist_ok=True)
        write_json(destination, plan)
        store.event("plan_created", {"plan_path": str(destination.resolve()), "sha256": plan["sha256"], "orders": len(orders)})
        return destination


def submit_plan(path: Path, settings: Settings, confirm: str, *, broker_factory=PaperBroker, now=None) -> dict:
    plan = json.loads(path.read_text(encoding="utf-8"))
    account = os.environ.get(settings.paper.account_env, "")
    if confirm != account or not confirm:
        raise ValueError("--confirm-paper must exactly match the allowlisted paper account you verified in TWS.")
    validate_plan(plan, settings, account, now)
    store = _store(settings)
    store.assert_running()
    # Re-check archived evidence, not just the mutable plan file.
    data = load_market_run(Path(plan["data_path"]), settings.symbols)
    if data.synthetic or data.source["verified_hashes"] != plan["data_hashes"]:
        raise ValueError("Market data changed since planning.")
    if plan.get("fundamentals"):
        receipt = plan["fundamentals"]
        if sha256(Path(receipt["path"]).read_bytes()).hexdigest() != receipt["sha256"]:
            raise ValueError("Fundamentals changed since planning.")
    if not plan["orders"]:
        return {"status": "no_orders", "reason": "Hold, no eligible signals, or positions already match the plan."}
    key = account + ":" + str(utc(now).tz_convert("America/New_York").date())
    reserved = False
    receipts = []
    with broker_factory(settings, readonly=False) as broker:
        try:
            snapshot = broker.snapshot()
            if snapshot["open_orders"]:
                raise ValueError("Open orders appeared after planning; reconcile first.")
            if snapshot["positions"] != plan["positions_before"]:
                raise ValueError("Broker inventory changed since planning; generate a new plan.")
            capital = _risk(broker, store, settings, snapshot)
            quotes = broker.quotes(settings.universe)
            corr = data.close[settings.universe].pct_change(fill_method=None).tail(settings.strategy.correlation_window).corr()
            check_weights(projected_weights(snapshot["positions"], plan["orders"], quotes, capital), settings, corr)
            buy_cash = sum(o["quantity"] * o["limit_price"] for o in plan["orders"] if o["side"] == "BUY")
            if buy_cash * 1.02 > min(snapshot["cash"], snapshot["available_funds"]):
                raise ValueError("Cash changed since planning.")
            for order in plan["orders"]:
                if order["con_id"] != quotes[order["symbol"]]["con_id"]:
                    raise ValueError("Contract identity changed.")
                q = quotes[order["symbol"]]
                mid = (q["bid"] + q["ask"]) / 2
                if abs(order["limit_price"] / mid - 1) > 0.005:
                    raise ValueError("Price moved more than 0.5% from the fixed limit. Generate a new plan; no chasing.")
                preview = broker.preflight(order, "QT:preview")
                store.event("what_if", {"symbol": order["symbol"], **preview})
            validate_plan(plan, settings, account, now)
            store.reserve(key, {"plan_sha256": plan["sha256"], "orders": plan["orders"]})
            reserved = True
            for index, order in enumerate(plan["orders"]):
                validate_plan(plan, settings, account, now)
                store.assert_running()
                broker.assert_connected()
                if not in_order_window(utc(now)):
                    raise ValueError("Safe session window ended before batch completion.")
                # Recheck P&L, inventory, quotes and cash between every actual order.
                current_snapshot = broker.snapshot()
                capital = _risk(broker, store, settings, current_snapshot)
                current_quotes = broker.quotes(settings.universe)
                remaining_orders = plan["orders"][index:]
                check_weights(projected_weights(current_snapshot["positions"], remaining_orders, current_quotes, capital), settings, corr)
                q = current_quotes[order["symbol"]]
                validate_quote(q, settings, now)
                if abs(order["limit_price"] / ((q["bid"] + q["ask"])/2) - 1) > 0.005:
                    raise ValueError("Quote drift before send; remaining batch stopped.")
                if order["side"] == "BUY" and order["quantity"] * order["limit_price"] * 1.02 > min(current_snapshot["cash"], current_snapshot["available_funds"]):
                    raise ValueError("Insufficient cash before send.")
                reference = "QT:" + plan["sha256"][:16] + ":" + str(index)
                receipt = broker.place_and_wait(order, reference, store, store.assert_running)
                receipts.append(receipt)
                if receipt["filled"]:
                    store.record_fill(account, order["symbol"], order["side"], receipt["filled"])
                if receipt["status"] != "Filled" or receipt["filled"] != order["quantity"]:
                    store.finish(key, "partial_or_unfilled_review_required")
                    store.stop("An order was not fully filled. Remainder cancelled where confirmed; reconcile before further sessions.")
                    break
            else:
                store.finish(key, "completed")
            snapshot = broker.snapshot()
            store.observe(account, snapshot)
            result = {"status": "completed" if not (store.folder / "STOP").exists() else "review_required",
                      "batch_key": key, "receipts": receipts, "snapshot": snapshot}
            write_json(store.folder / "last_submission.json", result)
            return result
        except (Exception, KeyboardInterrupt) as exc:
            if reserved:
                store.finish(key, "unknown_or_failed_review_required")
                store.stop(str(exc))
                try:
                    store.event("cancel_owned_after_error", {"orders": broker.cancel_owned()})
                except Exception as cancel_exc:
                    store.event("cancellation_unknown", {"error": str(cancel_exc)})
            raise


def stop_paper(settings: Settings, *, cancel: bool = False) -> dict:
    store = _store(settings)
    store.stop("Operator requested stop. Existing positions are NOT liquidated automatically.")
    result = {"stopped": True, "positions_liquidated": False, "cancel_requested": cancel}
    if cancel:
        with PaperBroker(settings, readonly=False) as broker:
            result["cancelled_owned_orders"] = broker.cancel_owned()
    return result


def run_cycle(settings: Settings, *, execute: bool = False, confirm: str = "") -> dict:
    """One foreground daily cycle; intentionally safe to schedule locally.

    No recovery retries: a duplicate/unknown broker batch requires human review.
    """
    settings.validate()
    if execute and (not settings.paper.submit_enabled or not settings.paper.data_reviewed):
        raise ValueError("Explicit submission switches and reviewed data are required.")
    store = _store(settings)
    store.assert_running()
    if not in_order_window():
        return {"status": "outside_market_window", "orders_submitted": False}
    now = utc().tz_convert("America/New_York")
    if execute:
        account = os.environ.get(settings.paper.account_env, "")
        if confirm != account or not confirm:
            raise ValueError("Explicit paper account confirmation is required before fetching or submitting.")
        existing = store.batch_status(account + ":" + str(now.date()))
        if existing == "completed":
            return {"status": "already_submitted_this_session", "orders_submitted": False}
        if existing is not None:
            raise ValueError("A prior reserved/failed batch requires manual reconciliation; no automatic retry.")
    work = store.folder / "cycles" / now.strftime("%Y-%m-%d_%H%M%S")
    work.mkdir(parents=True, exist_ok=False)
    end = now.strftime("%Y-%m-%d")  # Excludes today's incomplete candle.
    start = (now.tz_localize(None).normalize() - pd.DateOffset(years=3)).strftime("%Y-%m-%d")
    run, passed = run_pipeline([INSTRUMENTS[s] for s in settings.symbols], start, end, work / "market")
    if not passed:
        raise ValueError("Daily market-data validation failed; no plan or orders generated.")
    fundamental_path = None
    if settings.paper.strategy in ("fundamental", "combined"):
        fundamental_path = download_sec_fundamentals(settings.universe, work / "fundamentals.csv")
    plan = make_plan(run, fundamental_path, settings, work / "plan.json")
    if execute:
        return submit_plan(plan, settings, confirm)
    return {"status": "plan_only", "plan": str(plan.resolve()), "orders_submitted": False}


def run_foreground(settings: Settings, *, execute: bool = False, confirm: str = "", interval: int = 120):
    """One cycle per US session, plus account snapshots. Never runs as a hidden service."""
    if execute and (confirm != os.environ.get(settings.paper.account_env, "") or not settings.paper.submit_enabled or not settings.paper.data_reviewed):
        raise ValueError("Confirm the paper account and enable the two explicit submission settings first.")
    if interval < 60:
        raise ValueError("Monitoring interval must be at least 60 seconds.")
    store = _store(settings)
    print("FOREGROUND PAPER LOOP. Ctrl+C stops the loop; use paper-stop --cancel to cancel owned orders.")
    while True:
        store.assert_running()
        date = str(utc().tz_convert("America/New_York").date())
        stamp = store.folder / ("cycle_done_" + date + ("_execute" if execute else "_plan") + ".json")
        try:
            status = paper_status(settings)
            if status["risk_status"].startswith("HALTED"):
                if execute:
                    stop_paper(settings, cancel=True)
                raise ValueError(status["risk_status"])
            if in_order_window() and not stamp.exists():
                result = run_cycle(settings, execute=execute, confirm=confirm)
                write_json(stamp, result)
                print(json.dumps(result, default=str))
            else:
                print(json.dumps({"time": utc().isoformat(), "risk_status": status["risk_status"], "action": "monitor_only"}))
        except Exception as exc:
            store.stop("Foreground cycle stopped: " + str(exc))
            raise
        time.sleep(interval)
