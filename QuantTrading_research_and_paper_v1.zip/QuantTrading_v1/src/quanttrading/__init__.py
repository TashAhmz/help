"""QuantTrading 0.2: end-of-day research and guarded PAPER execution only."""
__version__ = "0.2.0"
