"""Full research workflow: common universe, holdout, annual folds and cost stress."""
from copy import deepcopy
from datetime import datetime, timezone
from pathlib import Path
from hashlib import sha256
from uuid import uuid4
import json
import pandas as pd
from .research_data import load_market_run
from .fundamentals import load_fundamentals
from .strategies import build_signals
from .backtest import simulate
from .performance import performance, paired_block_interval
from .reporting import write_report
from .settings import Settings
from .pipeline import write_json, environment_versions


def run_research(data_path: Path, fundamental_path: Path | None, settings: Settings,
                 output: Path = Path("reports"), *, ablations: bool = False) -> Path:
    settings.validate()
    data = load_market_run(data_path, settings.symbols)
    fundamentals = load_fundamentals(fundamental_path) if fundamental_path else None
    if fundamentals is not None and not data.synthetic and fundamentals.source.str.contains("SYNTHETIC", case=False).any():
        raise ValueError("Synthetic fundamentals cannot be mixed into a real-market report.")
    if len(data.dates[data.dates < pd.Timestamp(settings.research_start)]) < settings.strategy.slow_ma:
        raise ValueError("Fetch at least one year before research_start for indicator warmup.")
    if len(data.dates[data.dates >= pd.Timestamp(settings.holdout_start)]) < 60:
        raise ValueError("Need at least 60 holdout sessions; do not relabel an in-sample run as validation.")
    signals = build_signals(data, settings, fundamentals)
    targets = dict(signals.targets)
    targets["buy_hold_SPY"] = pd.DataFrame(1.0, index=data.dates, columns=[settings.benchmark])
    targets["buy_hold_QQQ"] = pd.DataFrame(1.0, index=data.dates, columns=[settings.secondary_benchmark])
    # Common-equity passive comparison at a conservative static risk budget.
    passive = {s: min(settings.risk.max_position, settings.risk.max_gross / len(settings.universe)) for s in settings.universe}
    for group in set(settings.sectors.values()):
        members = [s for s in passive if settings.sectors[s] == group]
        total = sum(passive[s] for s in members)
        factor = min(1, settings.risk.max_sector / total) if total else 1
        for s in members:
            passive[s] *= factor
    targets["passive_same_equities"] = pd.DataFrame([passive] * len(data.dates), index=data.dates)
    results, full, holdout, held = {}, {}, {}, {}
    for mode, target in targets.items():
        passive_mode = mode.startswith("buy_hold") or mode.startswith("passive")
        result = simulate(data, target, settings, settings.research_start, risk_enabled=not passive_mode, buy_and_hold=passive_mode)
        results[mode], full[mode] = result, performance(result, settings.initial_capital)
        h = simulate(data, target, settings, settings.holdout_start, risk_enabled=not passive_mode, buy_and_hold=passive_mode)
        held[mode], holdout[mode] = h, performance(h, settings.initial_capital)
    fold_rows = []
    for year in range(pd.Timestamp(settings.research_start).year + 1, data.dates[-1].year + 1):
        lo, hi = f"{year}-01-01", f"{year}-12-31"
        if len(data.dates[(data.dates >= lo) & (data.dates <= hi)]) < 60:
            continue
        for mode, target in targets.items():
            passive_mode = mode.startswith("buy_hold") or mode.startswith("passive")
            result = simulate(data, target, settings, lo, hi, risk_enabled=not passive_mode, buy_and_hold=passive_mode)
            metric = performance(result, settings.initial_capital)
            fold_rows.append({"year": year, "strategy": mode, "total_return": metric["total_return"],
                              "sharpe": metric["sharpe_zero_cash_rate"], "max_drawdown": metric["max_drawdown"],
                              "mean_gross_exposure": metric["mean_gross_exposure"]})
    stressed = deepcopy(settings)
    for k in ("commission_bps", "minimum_commission", "half_spread_bps", "slippage_bps"):
        setattr(stressed.costs, k, getattr(stressed.costs, k) * 2)
    stress = {m: performance(simulate(data, t, stressed, settings.holdout_start), settings.initial_capital)
              for m, t in signals.targets.items()}
    feature_tests = {}
    if ablations:
        if fundamentals is None:
            raise ValueError("Feature ablations require genuine or clearly synthetic availability-dated fundamentals.")
        for feature in settings.strategy.fundamental_features:
            alternative = deepcopy(settings)
            alternative.strategy.fundamental_features = [feature]
            alternative_signals = build_signals(data, alternative, fundamentals)
            target = alternative_signals.targets["combined"]
            result = simulate(data, target, alternative, settings.holdout_start)
            feature_tests["momentum_plus_" + feature] = performance(result, settings.initial_capital)
    comparisons = {}
    if "combined" in held:
        for base in ("momentum", "fundamental", "passive_same_equities"):
            comparisons[f"combined_minus_{base}"] = paired_block_interval(held["combined"].equity.daily_return, held[base].equity.daily_return)
    run_id = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ") + "_" + uuid4().hex[:8]
    folder = output / run_id
    folder.mkdir(parents=True, exist_ok=False)
    limitations = [
        "No profitability claim: a successful program run is not evidence of a durable trading edge.",
        "A fixed set of surviving large-cap equities is survivorship-biased and concentrated. No delisted-universe reconstruction is included.",
        "The three active strategies use the same equity universe, risk model and fees. SPY/QQQ are 100%-invested reference benchmarks, not risk-matched portfolios. Inspect average exposure.",
        "Signals and desired quantities use the prior close. Execution is modelled at next adjusted open plus frictions. Actual paper orders use integer shares and current quotes after the open, so results will differ.",
        "Adjusted OHLC represent synthetic fractional total-return units. Do not interpret unit counts as historical executable shares. Distributions and splits are not credited again.",
        "Commission, spread and slippage assumptions are illustrative. No market impact, taxes, interest on cash, FX conversion, settlement or order-book simulator is included.",
        "Stops and loss thresholds are observed at daily closes and act at the next open in research. Gaps can exceed thresholds. Drawdown shutdown is latched for the rest of each evaluation run.",
        "Trade statistics use closed FIFO matched lots, not unique ideas or orders. Open positions remain marked to market and are excluded from closed-lot win rates.",
        "Annual SEC features use accession-specific comparisons and a conservative filing-date availability proxy. They are not quarterly, forecast-revision or certified historical-vintage data; inspect coverage and original filings.",
        "A missing or stale fundamental snapshot makes an instrument ineligible; it is not replaced with zero or current information. ETFs do not receive company fundamental scores.",
        "Annual rolling-origin evaluations keep rules frozen and restart capital. No fitted model or optimisation is claimed. The holdout loses its status after repeated tuning against its results.",
        "A 95% resampling interval does not account for all market regimes, multiple testing, survivorship or data-quality errors.",
    ]
    if fundamentals is None:
        limitations.insert(0, "Fundamental and combined tests NOT RUN: provide an availability-dated fundamentals CSV. Only the momentum baseline and passive references are available.")
    summary = {"schema_version": 1, "run_id": run_id, "synthetic": data.synthetic,
               "created_at_utc": datetime.now(timezone.utc).isoformat(), "holdout_start": settings.holdout_start,
               "configuration": settings.to_dict(), "configuration_sha256": settings.fingerprint(),
               "environment": environment_versions(), "data_provenance": data.source,
               "fundamentals": {"path": str(fundamental_path), "sha256": sha256(fundamental_path.read_bytes()).hexdigest()} if fundamental_path else None,
               "full_sample": full, "holdout": holdout, "double_cost_holdout": stress,
               "holdout_comparisons": comparisons, "feature_ablation_holdout": feature_tests, "limitations": limitations}
    if feature_tests:
        pd.DataFrame(feature_tests).T.to_csv(folder / "feature_ablations.csv")
        summary["limitations"].append("Single-feature ablations are exploratory and reuse the holdout; do not select the best feature and then call the same window untouched out-of-sample evidence.")
    signals.diagnostics.to_csv(folder / "signals.csv", index=False)
    for mode, target in signals.targets.items():
        target.to_csv(folder / f"targets_{mode}.csv")
    report = write_report(folder, summary, results, pd.DataFrame(fold_rows))
    for mode, result in held.items():
        out = folder / "holdout" / mode
        out.mkdir(parents=True)
        result.equity.to_csv(out / "equity.csv")
        result.fills.to_csv(out / "fills.csv", index=False)
        result.closed_lots.to_csv(out / "closed_fifo_lots.csv", index=False)
    output.mkdir(exist_ok=True)
    write_json(output / "latest.json", {"report": str(report.resolve()), "run": str(folder.resolve()), "synthetic": data.synthetic})
    return report
