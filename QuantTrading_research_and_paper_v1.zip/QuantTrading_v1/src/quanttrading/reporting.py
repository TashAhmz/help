"""Portable, offline HTML reports plus CSV evidence; no account credentials embedded."""
from html import escape
from pathlib import Path
import json
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import pandas as pd
from .pipeline import write_json

STYLE = """
body{font-family:system-ui,sans-serif;max-width:1180px;margin:36px auto;padding:0 24px;line-height:1.6;background:#f7f8fa;color:#1b2838}
h1{font-size:34px;line-height:1.2}h2{margin-top:36px} .banner{padding:18px;background:#fff1c6;border-left:5px solid #986700;border-radius:6px}
.card{background:white;padding:22px;border:1px solid #d9e0e5;border-radius:10px;margin:20px 0;overflow:auto}
table{border-collapse:collapse;width:100%;font-size:14px}th,td{text-align:right;padding:10px;border-bottom:1px solid #d9e0e5}th:first-child,td:first-child{text-align:left}
img{width:100%;height:auto}code{background:#eef1f4;padding:2px 5px}a{color:#155c84}small{color:#506070}.muted{color:#53616e}
"""


def write_report(folder: Path, summary: dict, results: dict, folds: pd.DataFrame) -> Path:
    folder.mkdir(parents=True, exist_ok=True)
    write_json(folder / "summary.json", summary)
    folds.to_csv(folder / "walk_forward.csv", index=False)
    for mode, result in results.items():
        out = folder / mode
        out.mkdir(exist_ok=True)
        result.equity.to_csv(out / "equity.csv")
        result.fills.to_csv(out / "fills.csv", index=False)
        result.closed_lots.to_csv(out / "closed_fifo_lots.csv", index=False)
        result.decisions.to_csv(out / "decisions.csv", index=False)
    banner = ("SYNTHETIC TEST DATA - These fictional results test the software, not investment performance."
              if summary["synthetic"] else
              "RESEARCH ONLY - Selected-survivor universe, modelled costs and vendor-adjusted prices. Historical results are not proof of future profitability.")
    for column, filename, title in (("equity", "equity.png", "Full evaluation: marked-to-market equity (USD)"),
                                    ("drawdown", "drawdown.png", "Full evaluation: drawdown from running peak")):
        fig, ax = plt.subplots(figsize=(11.4, 5.1))
        for mode, result in results.items():
            ax.plot(result.equity.index, result.equity[column], label=mode.replace("_", " "), linewidth=1.3)
        ax.set_title(("SYNTHETIC / " if summary["synthetic"] else "") + title)
        ax.set_ylabel("USD" if column == "equity" else "Fraction below peak")
        ax.legend(loc="best", fontsize=8)
        ax.grid(alpha=0.22)
        fig.tight_layout()
        fig.savefig(folder / filename, dpi=145)
        plt.close(fig)
    def table(metrics):
        rows = []
        for name, m in metrics.items():
            sharpe = "n/a" if m["sharpe_zero_cash_rate"] is None else f'{m["sharpe_zero_cash_rate"]:.2f}'
            rows.append({"Strategy": name, "Total return": f'{m["total_return"]:.1%}',
                         "Annualised return": f'{m["annualised_return_252_sessions"]:.1%}',
                         "Volatility": f'{m["annualised_volatility"]:.1%}', "Sharpe (cash=0)": sharpe,
                         "Max drawdown": f'{m["max_drawdown"]:.1%}', "Mean exposure": f'{m["mean_gross_exposure"]:.1%}',
                         "Filled orders": m["filled_orders"], "Closed FIFO lots": m["closed_fifo_lots"]})
        return pd.DataFrame(rows).to_html(index=False, escape=True, border=0)
    qualifications = "".join(f"<p>{escape(x)}</p>" for x in summary["limitations"])
    comparisons = escape(json.dumps(summary.get("holdout_comparisons", {}), indent=2))
    ablation_html = ("<h2>Exploratory single-feature additions to momentum</h2><p>Same complete-data sample and risk model; repeated testing consumes the holdout.</p><div class='card'>"
                     + table(summary["feature_ablation_holdout"]) + "</div>") if summary.get("feature_ablation_holdout") else ""
    stress_html = "<h2>Holdout with doubled execution costs</h2><div class='card'>" + table(summary["double_cost_holdout"]) + "</div>"
    doc = f'''<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>QuantTrading research report</title><style>{STYLE}</style></head><body>
<p class="muted">QUANTTRADING / LOCAL RESEARCH</p><h1>Strategy evaluation</h1><div class="banner">{escape(banner)}</div>
<p>Run: <code>{escape(summary['run_id'])}</code>. Primary decision window: holdout beginning {escape(summary['holdout_start'])}.</p>
<h2>Holdout: independently restarted portfolios</h2><p>Parameters are fixed, not fitted. Comparing these results after repeated changes consumes the holdout.</p><div class="card">{table(summary['holdout'])}</div>
<h2>Full evaluation</h2><div class="card">{table(summary['full_sample'])}</div>
<div class="card"><img src="equity.png" alt="Equity by strategy"></div><div class="card"><img src="drawdown.png" alt="Drawdown by strategy"></div>
<h2>Year-by-year rolling-origin evaluation</h2><p>Each year restarts capital, uses earlier observations for indicators, and keeps parameters frozen. This is not model fitting or optimisation.</p>
<div class="card">{folds.to_html(index=False, escape=True, border=0, float_format=lambda x: f'{x:.4f}')}</div>
<h2>Paired holdout return differences</h2><p>Intervals quantify resampling uncertainty only, not the probability that a strategy will be profitable.</p><div class="card"><pre>{comparisons}</pre></div>
{stress_html}{ablation_html}
<h2>Interpretation and limitations</h2><div class="card">{qualifications}</div>
<p><a href="summary.json">Complete metrics and provenance</a> | <a href="walk_forward.csv">Rolling-origin results CSV</a> | <a href="signals.csv">Signal diagnostics CSV</a></p>
<p class="muted">Costs are configurable modelling assumptions, not an IBKR commission quote. No live orders can be sent by this report.</p></body></html>'''
    path = folder / "report.html"
    path.write_text(doc, encoding="utf-8")
    return path
