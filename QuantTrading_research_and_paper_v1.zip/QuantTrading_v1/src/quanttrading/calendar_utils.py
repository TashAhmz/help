"""Exchange-local sessions and UTC event timestamps; no hardcoded UK/US offset."""
from functools import lru_cache
import pandas as pd
import exchange_calendars as xcals

@lru_cache(maxsize=1)
def calendar():
    return xcals.get_calendar("XNYS", start="2010-01-01", end="2035-12-31")

def utc(value=None) -> pd.Timestamp:
    t = pd.Timestamp.now(tz="UTC") if value is None else pd.Timestamp(value)
    if t.tzinfo is None:
        raise ValueError("An explicit timezone is required for event timestamps.")
    return t.tz_convert("UTC")

def sessions(start, end) -> pd.DatetimeIndex:
    return calendar().sessions_in_range(pd.Timestamp(start), pd.Timestamp(end))

def session_close(day) -> pd.Timestamp:
    return calendar().session_close(pd.Timestamp(day).normalize())

def previous_session(now=None) -> pd.Timestamp:
    t = utc(now).tz_convert("America/New_York")
    day = t.tz_localize(None).normalize()
    c = calendar()
    if c.is_session(day):
        return c.previous_session(day)
    return c.date_to_session(day, direction="previous")

def in_order_window(now=None) -> bool:
    t = utc(now)
    day = t.tz_convert("America/New_York").tz_localize(None).normalize()
    c = calendar()
    if not c.is_session(day):
        return False
    return c.session_open(day) + pd.Timedelta(minutes=10) <= t <= c.session_close(day) - pd.Timedelta(minutes=15)

def is_rebalance_close(day, frequency: str) -> bool:
    if frequency == "daily":
        return True
    day = pd.Timestamp(day)
    following = calendar().next_session(day)
    return following.isocalendar()[:2] != day.isocalendar()[:2]
