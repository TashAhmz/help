"""Pure paper-safety functions; tested without an installed broker client."""
from decimal import Decimal, ROUND_CEILING, ROUND_FLOOR
from hashlib import sha256
import json
import math
import re
import pandas as pd
from .settings import Settings
from .calendar_utils import utc, previous_session, in_order_window
from .risk import check_weights


def verify_account(account: str, managed: list[str], settings: Settings):
    settings.validate()
    if not re.fullmatch(r"DU[0-9]{3,}", account or ""):
        raise ValueError("Only explicitly allowlisted DU-number paper accounts are supported; no live account mode exists.")
    if managed != [account]:
        raise ValueError("Connected account must exactly equal the sole allowlisted paper account. Multi-account sessions are unsupported.")


def validate_quote(quote: dict, settings: Settings, now=None):
    current = utc(now)
    if quote.get("market_data_type") != 1:
        raise ValueError("Live streaming quotes required; delayed/frozen quotes cannot authorise orders.")
    for key in ("bid", "ask", "bid_size", "ask_size", "min_tick"):
        value = quote.get(key)
        if not isinstance(value, (int, float)) or not math.isfinite(value) or value <= 0:
            raise ValueError(f"Invalid quote {key}.")
    if quote["ask"] < quote["bid"]:
        raise ValueError("Crossed quote.")
    age = (current - utc(quote["timestamp"])).total_seconds()
    if age < -2 or age > settings.paper.quote_max_age_seconds:
        raise ValueError("Stale or future-dated quote.")
    spread = (quote["ask"] - quote["bid"]) / ((quote["ask"] + quote["bid"]) / 2) * 10000
    if spread > settings.paper.max_spread_bps:
        raise ValueError("Spread exceeds the paper safety limit.")
    if type(quote.get("con_id")) is not int or quote["con_id"] <= 0:
        raise ValueError("Missing qualified contract identifier.")


def limit_price(quote: dict, side: str) -> float:
    if side not in ("BUY", "SELL"):
        raise ValueError("Unknown order side.")
    tick = Decimal(str(quote["min_tick"]))
    price = Decimal(str(quote["ask"] if side == "BUY" else quote["bid"]))
    rounded = (price / tick).to_integral_value(rounding=ROUND_CEILING if side == "BUY" else ROUND_FLOOR) * tick
    return float(rounded)


def plan_digest(plan: dict) -> str:
    return sha256(json.dumps({k: v for k, v in plan.items() if k != "sha256"}, sort_keys=True, allow_nan=False).encode()).hexdigest()


def risk_capital(snapshot: dict, anchor: dict, settings: Settings) -> float:
    for key in ("net_liquidation", "cash", "available_funds", "daily_pnl"):
        value = snapshot.get(key)
        if not isinstance(value, (int, float)) or not math.isfinite(value):
            raise ValueError(f"Missing/nonfinite broker risk input: {key}")
    if snapshot.get("currency") != "USD":
        raise ValueError("Version 1 supports a USD-base paper account only; no implicit FX conversion.")
    if anchor["budget"] != settings.paper.capital_usd:
        raise ValueError("Paper budget changed since baseline; do not silently rescale a running experiment.")
    if snapshot["cash"] < 0 or snapshot["available_funds"] < 0:
        raise ValueError("Negative cash or available funds: no borrowing is permitted.")
    budget = anchor["budget"]
    equity = budget + snapshot["net_liquidation"] - anchor["baseline_net_liquidation"]
    peak = budget + max(anchor["peak_net_liquidation"], snapshot["net_liquidation"]) - anchor["baseline_net_liquidation"]
    if equity <= 0 or equity / peak - 1 <= -settings.risk.max_drawdown:
        raise ValueError("Paper drawdown halt: no new orders; review and reduce exposure manually in TWS.")
    if snapshot["daily_pnl"] <= -budget * settings.risk.daily_loss:
        raise ValueError("Paper daily-loss halt: no new orders; review and reduce exposure manually in TWS.")
    return min(budget, equity)


def validate_plan(plan: dict, settings: Settings, account: str, now=None):
    current = utc(now)
    if not settings.paper.submit_enabled or not settings.paper.data_reviewed:
        raise ValueError("Submission is disabled until both submit_enabled and data_reviewed are explicitly true.")
    if plan.get("paper_only") is not True or plan.get("synthetic") is not False:
        raise ValueError("Only real-data PAPER plans may be submitted.")
    if plan.get("account") != account or not re.fullmatch(r"DU[0-9]{3,}", account):
        raise ValueError("Plan account does not match the allowlisted paper account.")
    if plan.get("configuration_sha256") != settings.fingerprint() or plan.get("sha256") != plan_digest(plan):
        raise ValueError("Configuration changed or plan was modified. Generate a new plan.")
    age = (current - utc(plan["created_at_utc"])).total_seconds()
    if not 0 <= age <= settings.paper.plan_ttl_seconds:
        raise ValueError("Expired or future-dated order plan.")
    if not in_order_window(current):
        raise ValueError("Orders are allowed only 10 minutes after the US open through 15 minutes before its close.")
    if plan["asof_session"] != str(previous_session(current).date()):
        raise ValueError("Signal is not from the previous completed exchange session.")
    seen = set()
    for order in plan["orders"]:
        symbol = order.get("symbol")
        if symbol in seen or symbol not in settings.universe:
            raise ValueError("Duplicate or unknown order symbol.")
        seen.add(symbol)
        if order.get("side") not in ("BUY", "SELL") or type(order.get("quantity")) is not int or order["quantity"] <= 0:
            raise ValueError("Orders require a valid side and a positive integer quantity.")
        price = order.get("limit_price")
        if not isinstance(price, (int, float)) or not math.isfinite(price) or price <= 0:
            raise ValueError("Invalid limit price.")
        if price * order["quantity"] > settings.paper.max_order_usd + 1e-8:
            raise ValueError("Order notional cap exceeded.")


def projected_weights(positions: dict, orders: list[dict], quotes: dict, capital: float) -> dict:
    quantities = {s: float(v["quantity"]) for s, v in positions.items()}
    for order in orders:
        s = order["symbol"]
        quantities[s] = quantities.get(s, 0.0) + order["quantity"] * (1 if order["side"] == "BUY" else -1)
    if any(v < -1e-9 for v in quantities.values()):
        raise ValueError("Order would create a short position.")
    # Ask-side valuation conservatively budgets every retained position.
    return {s: q * quotes[s]["ask"] / capital for s, q in quantities.items() if q > 0}
