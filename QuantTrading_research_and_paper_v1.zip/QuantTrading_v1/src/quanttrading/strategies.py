"""Transparent hypotheses: trend, relative strength, volatility and annual growth."""
from dataclasses import dataclass
import numpy as np
import pandas as pd
from .settings import Settings
from .research_data import MarketData
from .fundamentals import align_fundamentals, METRICS
from .risk import allocate

MODES = ("momentum", "fundamental", "combined")

@dataclass
class Signals:
    targets: dict[str, pd.DataFrame]
    diagnostics: pd.DataFrame


def build_signals(data: MarketData, settings: Settings, fundamentals: pd.DataFrame | None, *, last_only: bool = False) -> Signals:
    st = settings.strategy
    close = data.close
    returns = close.pct_change(fill_method=None)
    benchmark = close[settings.benchmark].pct_change(st.momentum_short, fill_method=None)
    fundamental = align_fundamentals(fundamentals, data.dates, settings.universe, st.fundamentals_max_age_days) if fundamentals is not None else None
    per_symbol = {}
    for s in settings.universe:
        price = close[s]
        f = pd.DataFrame(index=data.dates)
        f["ma_fast"] = price.rolling(st.fast_ma).mean()
        f["ma_middle"] = price.rolling(st.middle_ma).mean()
        f["ma_slow"] = price.rolling(st.slow_ma).mean()
        f["roc_short"] = price.pct_change(st.momentum_short, fill_method=None)
        f["roc_long"] = price.pct_change(st.momentum_long, fill_method=None)
        f["relative_strength"] = f.roc_short - benchmark
        f["volatility"] = returns[s].rolling(st.volatility_window).std(ddof=1) * np.sqrt(252)
        f["dollar_volume"] = data.dollar_volume[s].rolling(20).mean()
        f["volume_ratio"] = data.volume[s] / data.volume[s].rolling(20).mean()
        f["risk_eligible"] = ((f.volatility > 0) & (f.volatility <= st.max_volatility)
                              & (f.dollar_volume >= st.min_dollar_volume) & (f.volume_ratio >= st.min_volume_ratio)
                              & f.ma_slow.notna())
        f["momentum_pass"] = (f.risk_eligible & (price > f.ma_fast) & (f.ma_fast > f.ma_middle)
                               & (f.ma_middle > f.ma_slow) & (f.roc_short > 0) & (f.roc_long > 0)
                               & (f.relative_strength > 0))
        f["momentum_score"] = 0.5 * f.roc_short + 0.5 * f.roc_long + f.relative_strength
        for metric in METRICS:
            f[metric] = fundamental[s][metric] if fundamental is not None else np.nan
        thresholds = {"revenue_growth": st.revenue_growth_min, "earnings_growth": st.earnings_growth_min,
                      "net_margin": st.margin_min, "cashflow_margin": st.cashflow_margin_min}
        # Keep the same complete-data sample in feature ablations to isolate rule effects.
        f["fundamental_pass"] = f.risk_eligible & f[METRICS].notna().all(axis=1)
        for metric in st.fundamental_features:
            f["fundamental_pass"] &= f[metric] > thresholds[metric]
        # Bounded contributions prevent one tiny earnings denominator dominating.
        f["fundamental_score"] = f[st.fundamental_features].clip(-1, 1).sum(axis=1, min_count=len(st.fundamental_features))
        per_symbol[s] = f
    modes = MODES if fundamentals is not None else ("momentum",)
    targets = {m: pd.DataFrame(0.0, index=data.dates, columns=settings.universe) for m in modes}
    indices = [len(data.dates)-1] if last_only else range(len(data.dates))
    for i in indices:
        date = data.dates[i]
        if i < max(st.slow_ma, st.correlation_window, st.momentum_long):
            continue
        snapshot = pd.DataFrame({s: f.loc[date] for s, f in per_symbol.items()}).T
        trailing = returns[settings.universe].iloc[max(0, i-st.correlation_window+1):i+1]
        for mode in modes:
            if mode == "momentum":
                mask, score = snapshot.momentum_pass.astype(bool), snapshot.momentum_score
            elif mode == "fundamental":
                mask, score = snapshot.fundamental_pass.astype(bool), snapshot.fundamental_score
            else:
                mask = snapshot.momentum_pass.astype(bool) & snapshot.fundamental_pass.astype(bool)
                # Cross-sectional ranks put heterogeneous features on comparable scales.
                score = snapshot.momentum_score.rank(pct=True) + snapshot.fundamental_score.rank(pct=True)
            candidates = pd.DataFrame({"score": score, "volatility": snapshot.volatility}).loc[mask].astype(float)
            weights = allocate(candidates, trailing, settings)
            for symbol, weight in weights.items():
                targets[mode].loc[date, symbol] = weight
    diagnostics = pd.concat(per_symbol, names=["symbol", "date"]).reset_index()
    return Signals(targets, diagnostics)
