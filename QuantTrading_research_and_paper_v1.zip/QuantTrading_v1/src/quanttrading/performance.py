"""Inspectable statistics. Undefined ratios are null, never 'infinite performance'."""
import numpy as np
import pandas as pd
from .backtest import BacktestResult


def performance(result: BacktestResult, initial_capital: float) -> dict:
    equity = result.equity
    r = equity.daily_return.to_numpy(dtype=float)
    n = len(r)
    deviation = float(np.std(r, ddof=1)) if n > 1 else 0.0
    pnl = result.closed_lots.net_pnl if not result.closed_lots.empty else pd.Series(dtype=float)
    wins, losses = pnl[pnl > 0], pnl[pnl < 0]
    return {
        "sessions": n, "first_session": str(equity.index.min().date()), "last_session": str(equity.index.max().date()),
        "initial_equity_usd": initial_capital, "final_equity_usd": float(equity.equity.iloc[-1]),
        "total_return": float(equity.equity.iloc[-1] / initial_capital - 1),
        "annualised_return_252_sessions": float((equity.equity.iloc[-1] / initial_capital) ** (252 / n) - 1),
        "annualised_volatility": deviation * np.sqrt(252),
        "sharpe_zero_cash_rate": float(np.mean(r) / deviation * np.sqrt(252)) if deviation > 1e-12 else None,
        "max_drawdown": float(equity.drawdown.min()),
        "mean_gross_exposure": float(equity.gross_exposure.mean()),
        "filled_orders": len(result.fills), "closed_fifo_lots": len(pnl),
        "win_rate_closed_fifo_lots": float((pnl > 0).mean()) if len(pnl) else None,
        "average_win_usd": float(wins.mean()) if len(wins) else None,
        "average_loss_usd": float(losses.mean()) if len(losses) else None,
        "profit_factor_closed_fifo_lots": float(wins.sum() / -losses.sum()) if len(losses) else None,
        "commission_usd": float(result.fills.commission.sum()),
        "modelled_spread_slippage_usd": float(result.fills.spread_slippage_cost.sum()),
        "traded_notional_over_initial_equity": float(result.fills.notional.sum() / initial_capital),
        "open_positions_marked_not_liquidated": True,
    }


def paired_block_interval(a: pd.Series, b: pd.Series, *, block: int = 10,
                          iterations: int = 1000, seed: int = 1907) -> dict:
    paired = pd.concat([a, b], axis=1, join="inner").dropna()
    if len(paired) < 60:
        return {"available": False, "reason": "Fewer than 60 paired sessions"}
    diff = paired.iloc[:, 0].to_numpy() - paired.iloc[:, 1].to_numpy()
    rng = np.random.default_rng(seed)
    n = len(diff)
    starts = rng.integers(0, n, size=(iterations, int(np.ceil(n / block))))
    indices = (starts[:, :, None] + np.arange(block)) % n
    samples = diff[indices.reshape(iterations, -1)[:, :n]].mean(axis=1) * 252
    low, high = np.quantile(samples, [0.025, 0.975])
    return {"available": True, "metric": "annualised arithmetic mean daily return difference",
            "estimate": float(diff.mean() * 252), "lower_95": float(low), "upper_95": float(high),
            "block_sessions": block, "resamples": iterations, "paired_sessions": n,
            "qualification": "Exploratory circular block bootstrap; no multiple-testing, selection-bias or structural-regime correction."}
