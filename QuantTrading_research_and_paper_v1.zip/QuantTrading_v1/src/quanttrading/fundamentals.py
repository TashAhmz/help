"""Filing-dated annual fundamentals. No current-summary backfill and no forecast data.

The SEC adapter uses facts from the SAME accession for current/prior-year values.
A date-only filing becomes usable at 00:00 New York on the FOLLOWING calendar day;
signals then use the next available session close and execute no earlier than the
following session. This conservative proxy is not an exact release timestamp.
"""
from pathlib import Path
from hashlib import sha256
from datetime import datetime, timezone
import json
import os
import time
import numpy as np
import pandas as pd
import requests
from .calendar_utils import session_close
from .pipeline import write_json

METRICS = ["revenue_growth", "earnings_growth", "net_margin", "cashflow_margin"]
REQUIRED = ["symbol", "period_end", "available_at", "source", *METRICS]
TAGS = {
    "revenue": ["RevenueFromContractWithCustomerExcludingAssessedTax", "RevenueFromContractWithCustomerIncludingAssessedTax", "Revenues", "SalesRevenueNet"],
    "income": ["NetIncomeLoss", "ProfitLoss"],
    "cashflow": ["NetCashProvidedByUsedInOperatingActivities"],
}


def validate_fundamentals(frame: pd.DataFrame) -> pd.DataFrame:
    if frame.empty or set(REQUIRED) - set(frame.columns):
        raise ValueError(f"Fundamentals need nonempty records and columns: {REQUIRED}")
    out = frame.copy()
    # Reject naive timestamps instead of silently treating them as UTC.
    if any(pd.Timestamp(v).tzinfo is None for v in out.available_at):
        raise ValueError("available_at must include a timezone (UTC recommended).")
    out["available_at"] = pd.to_datetime(out.available_at, utc=True, errors="raise")
    out["period_end"] = pd.to_datetime(out.period_end, errors="raise")
    if out["period_end"].dt.tz is not None or out.period_end.isna().any():
        raise ValueError("period_end must be a valid date without a timezone.")
    if (out.period_end.dt.tz_localize("UTC") > out.available_at).any():
        raise ValueError("A reported period cannot end after its availability time.")
    if out.duplicated(["symbol", "available_at"]).any():
        raise ValueError("Conflicting fundamental snapshots at the same availability time.")
    if out[["symbol", "source"]].isna().any().any() or (out.source.astype(str).str.strip() == "").any():
        raise ValueError("Symbol and source provenance are required.")
    for column in METRICS:
        out[column] = pd.to_numeric(out[column], errors="raise")
        if not np.isfinite(out[column]).all():
            raise ValueError(f"Missing or nonfinite fundamental feature: {column}")
    # Ratios are fractions, not percentages. Large ratios can be genuine; no clipping.
    return out.sort_values(["symbol", "available_at", "period_end"]).reset_index(drop=True)


def load_fundamentals(path: Path) -> pd.DataFrame:
    return validate_fundamentals(pd.read_csv(path))


def align_fundamentals(frame: pd.DataFrame, dates: pd.DatetimeIndex,
                       symbols: list[str], max_age_days: int) -> dict[str, pd.DataFrame]:
    """Backward-only join at actual exchange closes, including early closes."""
    frame = validate_fundamentals(frame)
    clock = pd.DataFrame({"close_at": [session_close(d) for d in dates], "date": dates})
    aligned = {}
    for symbol in symbols:
        events = frame.loc[frame.symbol.eq(symbol)].sort_values("available_at").copy()
        if events.empty:
            aligned[symbol] = pd.DataFrame(np.nan, index=dates, columns=METRICS)
            continue
        # An amendment for an OLD period must not replace a later fiscal period.
        events = events.loc[events.period_end.ge(events.period_end.cummax())]
        joined = pd.merge_asof(clock, events, left_on="close_at", right_on="available_at",
                               direction="backward", allow_exact_matches=True)
        age = (joined.close_at - joined.available_at).dt.total_seconds() / 86400
        values = joined[METRICS].copy()
        values.loc[age.gt(max_age_days) | age.isna(), :] = np.nan
        values.index = dates
        aligned[symbol] = values
    return aligned


def _annual_rows(payload: dict, tag: str) -> list[dict]:
    values = payload.get("facts", {}).get("us-gaap", {}).get(tag, {}).get("units", {}).get("USD", [])
    result = []
    for row in values:
        try:
            days = (pd.Timestamp(row["end"]) - pd.Timestamp(row["start"])).days
            if row["form"] in ("10-K", "10-K/A") and 330 <= days <= 380 and np.isfinite(float(row["val"])):
                result.append(row)
        except (KeyError, ValueError, TypeError):
            continue
    return result


def parse_companyfacts(payload: dict, symbol: str, source: str) -> tuple[pd.DataFrame, dict]:
    by_tag = {tag: _annual_rows(payload, tag) for tags in TAGS.values() for tag in tags}
    accessions = sorted({r["accn"] for rows in by_tag.values() for r in rows})
    output, skipped = [], []
    for accn in accessions:
        # Consistent annual dates, units and reporting vintage for every ratio.
        rev_rows, chosen_tag = [], None
        for tag in TAGS["revenue"]:
            rows = [r for r in by_tag[tag] if r["accn"] == accn]
            if rows:
                rev_rows, chosen_tag = rows, tag
                break
        if not rev_rows:
            skipped.append({"accession": accn, "reason": "No supported annual revenue tag"})
            continue
        latest = max(r["end"] for r in rev_rows)
        def pick(tags, end):
            for tag in tags:
                rows = [r for r in by_tag[tag] if r["accn"] == accn and r["end"] == end]
                if rows:
                    unique = {(r["start"], float(r["val"])) for r in rows}
                    if len(unique) != 1:
                        raise ValueError("Conflicting facts or durations in one filing")
                    return rows[0], tag
            raise ValueError("Missing comparable annual fact")
        try:
            current, _ = pick([chosen_tag], latest)
            previous_ends = [r["end"] for r in rev_rows if 300 < (pd.Timestamp(latest) - pd.Timestamp(r["end"])).days < 430]
            if not previous_ends:
                raise ValueError("No prior-year comparison in the same filing")
            previous_end = max(previous_ends)
            prior, _ = pick([chosen_tag], previous_end)
            income, income_tag = pick(TAGS["income"], latest)
            prior_income, _ = pick([income_tag], previous_end)
            cash, cash_tag = pick(TAGS["cashflow"], latest)
            rows = [current, prior, income, prior_income, cash]
            if len({r["filed"] for r in rows}) != 1:
                raise ValueError("Inconsistent filing dates")
            if income["start"] != current["start"] or cash["start"] != current["start"] or prior_income["start"] != prior["start"]:
                raise ValueError("Inconsistent fiscal durations")
            rev, old_rev = float(current["val"]), float(prior["val"])
            inc, old_inc = float(income["val"]), float(prior_income["val"])
            if min(rev, old_rev, old_inc) <= 0:
                raise ValueError("Growth comparison requires positive prior earnings/revenue")
            filed = current["filed"]
            usable = (pd.Timestamp(filed) + pd.Timedelta(days=1)).tz_localize("America/New_York").tz_convert("UTC")
            output.append({"symbol": symbol, "period_end": latest, "filed_date": filed,
                           "available_at": usable.isoformat(), "accession": accn,
                           "source": source, "availability_basis": "SEC filing date + next local midnight; conservative proxy",
                           "revenue_growth": rev / old_rev - 1, "earnings_growth": inc / old_inc - 1,
                           "net_margin": inc / rev, "cashflow_margin": float(cash["val"]) / rev,
                           "revenue_tag": chosen_tag, "income_tag": income_tag, "cashflow_tag": cash_tag})
        except ValueError as exc:
            skipped.append({"accession": accn, "reason": str(exc)})
    out = pd.DataFrame(output)
    if not out.empty:
        # Same-day collisions cannot be ordered safely without acceptance timestamps.
        conflict = out.duplicated(["symbol", "available_at"], keep=False)
        for _, r in out.loc[conflict].iterrows():
            skipped.append({"accession": r.accession, "reason": "Ambiguous same-day availability collision"})
        out = out.loc[~conflict].reset_index(drop=True)
    return out, {"symbol": symbol, "accepted_snapshots": len(out), "skipped": skipped}


def download_sec_fundamentals(symbols: list[str], destination: Path) -> Path:
    agent = os.environ.get("SEC_USER_AGENT", "")
    if "@" not in agent or len(agent.split()) < 2:
        raise ValueError("Set SEC_USER_AGENT locally to your application/name and contact email; do not send it in chat.")
    if destination.exists():
        raise ValueError("Use a new fundamentals filename; research evidence is never overwritten.")
    destination.parent.mkdir(parents=True, exist_ok=True)
    rawdir = destination.parent / (destination.stem + "_source")
    rawdir.mkdir(exist_ok=False)
    session = requests.Session()
    session.headers.update({"User-Agent": agent, "Accept-Encoding": "gzip, deflate", "Accept": "application/json"})
    receipts = []
    def get(url, filename):
        time.sleep(0.35)
        response = session.get(url, timeout=(10, 45))
        response.raise_for_status()
        content = response.content
        (rawdir / filename).write_bytes(content)
        receipts.append({"url": url, "file": filename, "sha256": sha256(content).hexdigest(),
                         "retrieved_at_utc": datetime.now(timezone.utc).isoformat()})
        return response.json()
    try:
        mapping = get("https://www.sec.gov/files/company_tickers.json", "company_tickers.json")
        ciks = {v["ticker"]: v["cik_str"] for v in mapping.values()}
        frames, audits = [], []
        for symbol in symbols:
            if symbol not in ciks:
                raise ValueError(f"No SEC ticker mapping for {symbol}.")
            url = f"https://data.sec.gov/api/xbrl/companyfacts/CIK{ciks[symbol]:010d}.json"
            payload = get(url, symbol + ".json")
            frame, audit = parse_companyfacts(payload, symbol, url)
            audits.append(audit)
            write_json(rawdir / "parsing_audit.json", {"results": audits})
            if frame.empty:
                raise ValueError(f"No supported complete annual snapshots for {symbol}; review source and tags.")
            frames.append(frame)
        result = validate_fundamentals(pd.concat(frames, ignore_index=True))
        temp = destination.with_suffix(".tmp")
        result.to_csv(temp, index=False)
        temp.replace(destination)
        write_json(destination.with_suffix(".metadata.json"), {
            "status": "completed", "source": "SEC EDGAR companyfacts, annual same-accession ratios",
            "csv_sha256": sha256(destination.read_bytes()).hexdigest(), "synthetic": False,
            "limitations": ["Annual, not quarterly or forecast revisions", "Filing-date proxy, not exact announcement timestamp",
                            "Current SEC collection is not a certified vintage database; validate against original filings",
                            "Ticker mapping and selected universe are current and survivorship-biased"], "receipts": receipts})
        return destination
    except Exception as exc:
        write_json(rawdir / "failure.json", {"error": str(exc), "receipts": receipts})
        raise
    finally:
        session.close()
