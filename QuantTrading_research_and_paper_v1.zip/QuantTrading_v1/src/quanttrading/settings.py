"""Validated, versioned settings. All thresholds are hypotheses, not optimised values."""
from dataclasses import dataclass, field, asdict
from hashlib import sha256
from pathlib import Path
import json
import math

@dataclass
class StrategySettings:
    fast_ma: int = 20
    middle_ma: int = 50
    slow_ma: int = 200
    momentum_short: int = 63
    momentum_long: int = 126
    volatility_window: int = 63
    correlation_window: int = 126
    min_dollar_volume: float = 20_000_000
    min_volume_ratio: float = 0.0
    max_volatility: float = 0.60
    revenue_growth_min: float = 0.0
    earnings_growth_min: float = 0.0
    margin_min: float = 0.05
    cashflow_margin_min: float = 0.05
    fundamentals_max_age_days: int = 400
    fundamental_features: list[str] = field(default_factory=lambda: ["revenue_growth", "earnings_growth", "net_margin", "cashflow_margin"])
    rebalance: str = "weekly"
    max_positions: int = 4

@dataclass
class RiskSettings:
    max_position: float = 0.15
    max_gross: float = 0.60
    max_sector: float = 0.30
    correlation_threshold: float = 0.85
    max_correlated: float = 0.30
    target_volatility: float = 0.10
    daily_loss: float = 0.02
    max_drawdown: float = 0.10
    close_stop: float = 0.10

@dataclass
class CostSettings:
    commission_bps: float = 1.0
    minimum_commission: float = 1.0
    half_spread_bps: float = 2.5
    slippage_bps: float = 2.5
    minimum_trade_notional: float = 25.0

@dataclass
class PaperSettings:
    host: str = "127.0.0.1"
    port: int = 7497
    client_id: int = 71
    account_env: str = "IBKR_PAPER_ACCOUNT"
    submit_enabled: bool = False
    data_reviewed: bool = False
    strategy: str = "combined"
    capital_usd: float = 10000.0
    max_order_usd: float = 1500.0
    max_spread_bps: float = 30.0
    quote_max_age_seconds: int = 15
    plan_ttl_seconds: int = 120
    order_wait_seconds: int = 20
    state_dir: str = "runtime"

@dataclass
class Settings:
    schema_version: int = 1
    universe: list[str] = field(default_factory=lambda: ["AAPL", "MSFT", "AMZN", "GOOGL", "META", "NVDA"])
    benchmark: str = "SPY"
    secondary_benchmark: str = "QQQ"
    sectors: dict[str, str] = field(default_factory=lambda: {
        "AAPL": "Technology", "MSFT": "Technology", "NVDA": "Technology",
        "AMZN": "Consumer", "GOOGL": "Communication", "META": "Communication"})
    initial_capital: float = 10000.0
    research_start: str = "2020-01-01"
    holdout_start: str = "2024-01-01"
    strategy: StrategySettings = field(default_factory=StrategySettings)
    risk: RiskSettings = field(default_factory=RiskSettings)
    costs: CostSettings = field(default_factory=CostSettings)
    paper: PaperSettings = field(default_factory=PaperSettings)

    def validate(self) -> None:
        from .config import INSTRUMENTS
        if self.schema_version != 1:
            raise ValueError("Unknown configuration schema.")
        symbols = self.universe + [self.benchmark, self.secondary_benchmark]
        if not self.universe or len(set(self.universe)) != len(self.universe):
            raise ValueError("Universe must be nonempty and unique.")
        if any(s not in INSTRUMENTS for s in symbols):
            raise ValueError("Add instruments explicitly to config.py before using new tickers.")
        if any(INSTRUMENTS[s].instrument_type != "EQUITY" for s in self.universe):
            raise ValueError("The common comparison universe must contain equities, not ETFs.")
        if any(not self.sectors.get(s) for s in self.universe):
            raise ValueError("Every instrument needs an explicit sector group.")
        for name, value in asdict(self.risk).items():
            if not isinstance(value, (int, float)) or not math.isfinite(value) or not 0 < value <= 1:
                raise ValueError(f"risk.{name} must be finite and in (0, 1].")
        if self.risk.max_position > self.risk.max_gross:
            raise ValueError("Position cap exceeds gross cap.")
        if not 1 <= self.strategy.fast_ma < self.strategy.middle_ma < self.strategy.slow_ma:
            raise ValueError("Moving averages must be strictly increasing.")
        for k in ("fast_ma", "middle_ma", "slow_ma", "momentum_short", "momentum_long",
                  "volatility_window", "correlation_window", "max_positions", "fundamentals_max_age_days"):
            v = getattr(self.strategy, k)
            if type(v) is not int or v < 1:
                raise ValueError(f"strategy.{k} must be a positive integer.")
        features = self.strategy.fundamental_features
        if not features or len(set(features)) != len(features) or set(features) - {"revenue_growth", "earnings_growth", "net_margin", "cashflow_margin"}:
            raise ValueError("Choose unique supported fundamental features.")
        if self.strategy.rebalance not in ("daily", "weekly"):
            raise ValueError("Rebalance must be daily or weekly.")
        for k, v in asdict(self.strategy).items():
            if isinstance(v, (int, float)) and not math.isfinite(v):
                raise ValueError(f"Nonfinite strategy setting: {k}")
        for k, v in asdict(self.costs).items():
            if not isinstance(v, (int, float)) or not math.isfinite(v) or v < 0:
                raise ValueError(f"Invalid cost: {k}")
        if self.costs.half_spread_bps + self.costs.slippage_bps >= 1000:
            raise ValueError("Execution friction must be below 10% per side.")
        for v in (self.initial_capital, self.paper.capital_usd, self.paper.max_order_usd):
            if not isinstance(v, (int, float)) or not math.isfinite(v) or v <= 0:
                raise ValueError("Capital and order caps must be finite and positive.")
        if self.paper.host not in ("127.0.0.1", "localhost") or self.paper.port not in (7497, 4002):
            raise ValueError("Only local standard PAPER ports 7497/4002 are supported.")
        if type(self.paper.submit_enabled) is not bool or type(self.paper.data_reviewed) is not bool:
            raise ValueError("Paper switches must be JSON booleans.")
        if self.paper.strategy not in ("momentum", "fundamental", "combined"):
            raise ValueError("Unsupported paper strategy.")
        if self.paper.client_id < 1:
            raise ValueError("Use a dedicated nonzero client ID.")
        for k in ("max_spread_bps", "quote_max_age_seconds", "plan_ttl_seconds", "order_wait_seconds"):
            v = getattr(self.paper, k)
            if not isinstance(v, (int, float)) or not math.isfinite(v) or v <= 0:
                raise ValueError(f"Invalid paper.{k}")
        if self.paper.plan_ttl_seconds > 300 or self.paper.quote_max_age_seconds > 30:
            raise ValueError("Paper freshness limits cannot be widened beyond 300s/30s.")
        if self.paper.max_order_usd > self.paper.capital_usd * self.risk.max_position:
            raise ValueError("Order cap exceeds the configured position budget.")
        import pandas as pd
        if pd.Timestamp(self.research_start) >= pd.Timestamp(self.holdout_start):
            raise ValueError("Holdout must follow the research start.")

    def to_dict(self) -> dict:
        return asdict(self)

    def fingerprint(self) -> str:
        return sha256(json.dumps(self.to_dict(), sort_keys=True, allow_nan=False).encode()).hexdigest()

    @property
    def symbols(self) -> list[str]:
        return list(dict.fromkeys([self.benchmark, self.secondary_benchmark, *self.universe]))


def load_settings(path: Path | None = None) -> Settings:
    raw = json.loads(path.read_text(encoding="utf-8")) if path else {}
    known = set(Settings.__dataclass_fields__)
    if set(raw) - known:
        raise ValueError(f"Unknown configuration keys: {sorted(set(raw) - known)}")
    for key, cls in (("strategy", StrategySettings), ("risk", RiskSettings),
                     ("costs", CostSettings), ("paper", PaperSettings)):
        if key in raw:
            raw[key] = cls(**raw[key])
    settings = Settings(**raw)
    settings.validate()
    return settings
