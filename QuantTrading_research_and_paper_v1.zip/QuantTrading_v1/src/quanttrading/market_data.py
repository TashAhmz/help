"""Yahoo adapter and normalization. The rest of the project does not use yfinance."""

import logging
import time
from typing import Any

import pandas as pd

from .config import Instrument, check_dates

LOG = logging.getLogger(__name__)
FIELDS = {
    "Open": "open", "High": "high", "Low": "low", "Close": "close",
    "Adj Close": "adj_close", "Volume": "volume", "Dividends": "dividends",
    "Stock Splits": "stock_splits",
}
META_KEYS = ("symbol", "currency", "exchangeTimezoneName", "instrumentType",
             "exchangeName", "dataGranularity")


class DataError(RuntimeError):
    """Provider data could not be retrieved or safely normalized."""


def fetch_history(
    instrument: Instrument, start: str, end: str, *, attempts: int = 3,
) -> tuple[pd.DataFrame, dict[str, Any]]:
    """Return provider output, without automatic repair or OHLC adjustment.

    'auto_adjust=False' does NOT promise as-traded, pre-split Yahoo prices.
    The normalized fields retain the vendor's price basis.
    """
    check_dates(start, end)
    if not 1 <= attempts <= 3:
        raise ValueError("attempts must be between 1 and 3.")
    try:
        import yfinance as yf
    except ImportError as exc:
        raise DataError('Install dependencies: python -m pip install -e ".[dev]"') from exc

    for attempt in range(attempts):
        try:
            ticker = yf.Ticker(instrument.symbol)
            frame = ticker.history(
                start=start, end=end, interval="1d", prepost=False,
                auto_adjust=False, back_adjust=False, actions=True,
                repair=False, keepna=True, rounding=False,
                timeout=20, raise_errors=True,
            )
            if not isinstance(frame, pd.DataFrame) or frame.empty:
                raise DataError(f"{instrument.symbol}: provider returned no daily bars.")
            metadata = ticker.get_history_metadata()
            if not isinstance(metadata, dict):
                raise DataError("Provider metadata is missing or malformed.")
            return frame.copy(), {key: metadata.get(key) for key in META_KEYS}
        except Exception as exc:
            # Stop on rate limits instead of retrying a blocked endpoint rapidly.
            if type(exc).__name__ == "YFRateLimitError":
                raise DataError("Yahoo rate limit: stop and retry later, not in a loop.") from exc
            if attempt == attempts - 1:
                raise DataError(f"{instrument.symbol}: download failed: {exc}") from exc
            LOG.warning("%s: attempt %d failed (%s); retrying.",
                        instrument.symbol, attempt + 1, type(exc).__name__)
            time.sleep(2 ** attempt)
    raise AssertionError("Unreachable retry state")


def normalize_bars(raw: pd.DataFrame, instrument: Instrument) -> pd.DataFrame:
    """One row per symbol and exchange-local session date. Never fill or deduplicate."""
    if not isinstance(raw, pd.DataFrame) or raw.empty:
        raise DataError("Cannot normalize an empty response.")
    if isinstance(raw.columns, pd.MultiIndex) or raw.columns.has_duplicates:
        raise DataError("Expected unique, single-level provider columns.")
    missing = set(FIELDS) - set(raw.columns)
    if missing:
        raise DataError(f"Missing provider fields: {sorted(missing)}")
    if not isinstance(raw.index, pd.DatetimeIndex) or raw.index.hasnans:
        raise DataError("Expected a non-null DatetimeIndex.")
    if raw.index.tz is None:
        raise DataError("Timezone missing; refusing to guess the daily session date.")
    local = raw.index.tz_convert(instrument.timezone)
    if not local.equals(local.normalize()):
        raise DataError("Expected midnight exchange-local labels for daily bars.")
    columns = dict(FIELDS)
    if "Capital Gains" in raw.columns:
        columns["Capital Gains"] = "capital_gains"
    result = raw.loc[:, list(columns)].rename(columns=columns).copy()
    try:
        result = result.apply(pd.to_numeric, errors="raise")
    except (TypeError, ValueError) as exc:
        raise DataError("A numeric provider field contains non-numeric values.") from exc
    result.insert(0, "date", local.tz_localize(None))
    result.insert(0, "symbol", instrument.symbol)
    # Sorting is safe; deleting duplicate or incomplete observations is not.
    return result.sort_values("date", kind="stable").reset_index(drop=True)
