"""Durable local journal. A reserved batch is never automatically retried."""
from datetime import datetime, timezone
from contextlib import contextmanager
from pathlib import Path
import json
import sqlite3

class StateStore:
    def __init__(self, folder: Path):
        self.folder = folder
        folder.mkdir(parents=True, exist_ok=True)
        self.path = folder / "paper.sqlite"
        with self.connect() as con:
            con.executescript('''
            CREATE TABLE IF NOT EXISTS batches (
                batch_key TEXT PRIMARY KEY, status TEXT NOT NULL, created_at TEXT NOT NULL, payload TEXT NOT NULL);
            CREATE TABLE IF NOT EXISTS events (
                id INTEGER PRIMARY KEY AUTOINCREMENT, created_at TEXT NOT NULL, kind TEXT NOT NULL, payload TEXT NOT NULL);
            CREATE TABLE IF NOT EXISTS anchors (account TEXT PRIMARY KEY, payload TEXT NOT NULL);
            CREATE TABLE IF NOT EXISTS observations (
                id INTEGER PRIMARY KEY AUTOINCREMENT, created_at TEXT NOT NULL, account TEXT NOT NULL, payload TEXT NOT NULL);
            ''')
    @contextmanager
    def connect(self):
        con = sqlite3.connect(self.path, timeout=10)
        try:
            con.execute("PRAGMA journal_mode=WAL")
            con.execute("PRAGMA synchronous=FULL")
            with con:
                yield con
        finally:
            con.close()
    @staticmethod
    def now():
        return datetime.now(timezone.utc).isoformat()
    def event(self, kind: str, payload: dict):
        with self.connect() as con:
            con.execute("INSERT INTO events(created_at,kind,payload) VALUES(?,?,?)",
                        (self.now(), kind, json.dumps(payload, default=str, allow_nan=False)))
    def reserve(self, key: str, payload: dict):
        try:
            with self.connect() as con:
                con.execute("INSERT INTO batches VALUES(?,?,?,?)", (key, "reserved", self.now(), json.dumps(payload, allow_nan=False)))
        except sqlite3.IntegrityError as exc:
            raise ValueError("This account/session already has a reserved batch. Reconcile in TWS; never delete the journal to retry.") from exc
    def finish(self, key: str, status: str):
        with self.connect() as con:
            con.execute("UPDATE batches SET status=? WHERE batch_key=?", (status, key))
    def init_anchor(self, account: str, snapshot: dict, budget: float):
        payload = {"baseline_net_liquidation": snapshot["net_liquidation"], "peak_net_liquidation": snapshot["net_liquidation"],
                   "budget": budget, "created_at": self.now(), "expected_positions": {}}
        try:
            with self.connect() as con:
                con.execute("INSERT INTO anchors VALUES(?,?)", (account, json.dumps(payload)))
        except sqlite3.IntegrityError as exc:
            raise ValueError("Baseline already exists. Do not reset a loss history; use a documented new experiment.") from exc
        self.event("baseline_initialized", {"account": account, **payload})
    def anchor(self, account: str) -> dict:
        with self.connect() as con:
            row = con.execute("SELECT payload FROM anchors WHERE account=?", (account,)).fetchone()
        if not row:
            raise ValueError("Run paper-init with a flat, dedicated PAPER account before planning orders.")
        return json.loads(row[0])
    def observe(self, account: str, snapshot: dict):
        with self.connect() as con:
            con.execute("INSERT INTO observations(created_at,account,payload) VALUES(?,?,?)", (self.now(), account, json.dumps(snapshot, allow_nan=False)))
            row = con.execute("SELECT payload FROM anchors WHERE account=?", (account,)).fetchone()
            if row:
                anchor = json.loads(row[0])
                anchor["peak_net_liquidation"] = max(anchor["peak_net_liquidation"], snapshot["net_liquidation"])
                con.execute("UPDATE anchors SET payload=? WHERE account=?", (json.dumps(anchor), account))
    def stop(self, reason: str):
        (self.folder / "STOP").write_text(self.now() + "\n" + reason + "\n", encoding="utf-8")
        self.event("STOP", {"reason": reason})
    def assert_running(self):
        if (self.folder / "STOP").exists():
            raise ValueError("STOP latch exists. Review broker positions/orders and resolve the cause before manually removing it.")

    def record_fill(self, account: str, symbol: str, side: str, quantity: float):
        with self.connect() as con:
            row = con.execute("SELECT payload FROM anchors WHERE account=?", (account,)).fetchone()
            if row is None:
                raise ValueError("Missing accounting baseline")
            anchor = json.loads(row[0])
            positions = anchor.setdefault("expected_positions", {})
            q = positions.get(symbol, 0) + quantity * (1 if side == "BUY" else -1)
            if q < -1e-8 or not float(q).is_integer():
                raise ValueError("Unexpected short/fractional execution; manual reconciliation required")
            if q > 0:
                positions[symbol] = int(q)
            else:
                positions.pop(symbol, None)
            con.execute("UPDATE anchors SET payload=? WHERE account=?", (json.dumps(anchor), account))
    def reconcile(self, account: str, positions: dict):
        expected = self.anchor(account).get("expected_positions", {})
        observed = {s: int(p["quantity"]) for s, p in positions.items() if p["quantity"]}
        if expected != observed:
            raise ValueError("Broker positions differ from the durable fill ledger. Possible manual trade, corporate action or interrupted submission; reconcile manually, never resubmit blindly.")

    def batch_status(self, key: str):
        with self.connect() as con:
            row = con.execute("SELECT status FROM batches WHERE batch_key=?", (key,)).fetchone()
        return row[0] if row else None
