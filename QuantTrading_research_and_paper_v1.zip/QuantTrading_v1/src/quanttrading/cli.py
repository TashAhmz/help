"""Explicit subcommands; never connect to a broker during installation or research."""
import argparse
from pathlib import Path
import json
import logging
import sys
from .settings import load_settings


def parser():
    p = argparse.ArgumentParser(description="QuantTrading: research and PAPER only. There is no live mode.")
    p.add_argument("--config", type=Path, default=Path("config/default.json"), help="Run from the project root, or supply an absolute config path.")
    sub = p.add_subparsers(dest="command", required=True)
    sub.add_parser("doctor", help="Check local packages and configuration; no network/broker calls.")
    demo = sub.add_parser("demo", help="Run the complete SYNTHETIC software demo; never trading evidence.")
    demo.add_argument("--output", type=Path, default=Path("demo_output"))
    fetch = sub.add_parser("fetch", help="Retrieve and validate Yahoo daily market snapshots.")
    fetch.add_argument("--start", default="2018-01-01")
    fetch.add_argument("--end", default="2026-01-01", help="Exclusive date; defaults to completed 2018-2025 history.")
    fetch.add_argument("--output", type=Path, default=Path("data/runs"))
    fund = sub.add_parser("fundamentals", help="Download SEC annual filing-dated snapshots; requires SEC_USER_AGENT.")
    fund.add_argument("--output", type=Path, default=Path("data/fundamentals.csv"))
    research = sub.add_parser("research", help="Generate historical, holdout, rolling-origin and cost-stress results.")
    research.add_argument("--data", type=Path, required=True)
    research.add_argument("--fundamentals", type=Path)
    research.add_argument("--output", type=Path, default=Path("reports"))
    research.add_argument("--ablations", action="store_true", help="Exploratory momentum-plus-one-fundamental comparisons; consumes the holdout.")
    sub.add_parser("paper-check", help="Read-only broker connection and account check; no orders.")
    sub.add_parser("paper-status", help="Save a fresh account snapshot for the local dashboard.")
    init = sub.add_parser("paper-init", help="Record a baseline on a flat dedicated PAPER account; no orders.")
    init.add_argument("--confirm-paper", required=True)
    plan = sub.add_parser("paper-plan", help="Build an expiring plan from actual data; never submits orders.")
    plan.add_argument("--data", type=Path, required=True)
    plan.add_argument("--fundamentals", type=Path)
    plan.add_argument("--output", type=Path, default=Path("runtime/plan.json"))
    submit = sub.add_parser("paper-submit", help="Explicitly submit a reviewed PAPER plan; disabled by default.")
    submit.add_argument("--plan", type=Path, required=True)
    submit.add_argument("--confirm-paper", required=True)
    for name in ("paper-cycle", "paper-run"):
        cmd = sub.add_parser(name, help="One daily cycle" if name == "paper-cycle" else "Foreground daily cycle plus monitoring; keep computer awake.")
        cmd.add_argument("--execute", action="store_true", help="Explicit PAPER submission; otherwise plans only.")
        cmd.add_argument("--confirm-paper", default="")
    stop = sub.add_parser("paper-stop", help="Latch stop; optionally cancel this application's open orders. Does not liquidate positions.")
    stop.add_argument("--cancel", action="store_true")
    dashboard = sub.add_parser("dashboard", help="Serve saved paper snapshots on localhost, read-only.")
    dashboard.add_argument("--port", type=int, default=8765)
    return p


def main(argv=None) -> int:
    args = parser().parse_args(argv)
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
    try:
        settings = load_settings(args.config)
        command = args.command
        if command == "doctor":
            from importlib.metadata import version, PackageNotFoundError
            packages = {}
            for name in ("numpy", "pandas", "scipy", "matplotlib", "exchange-calendars", "requests", "yfinance", "ib_async", "pytest"):
                try:
                    packages[name] = version(name)
                except PackageNotFoundError:
                    packages[name] = "NOT INSTALLED (optional broker/market extras may be needed)"
            print(json.dumps({"python": sys.version, "packages": packages, "configuration": "valid", "live_mode": "not implemented",
                              "paper_submit_enabled": settings.paper.submit_enabled}, indent=2))
        elif command == "demo":
            from .demo import run_demo
            report = run_demo(settings, args.output)
            print("SYNTHETIC SOFTWARE TEST ONLY. Report: " + str(report.resolve()))
        elif command == "fetch":
            from .pipeline import run_pipeline
            from .config import INSTRUMENTS
            run, passed = run_pipeline([INSTRUMENTS[s] for s in settings.symbols], args.start, args.end, args.output)
            print(json.dumps({"run": str(run.resolve()), "structural_pass": passed, "independently_price_verified": False}, indent=2))
            return 0 if passed else 1
        elif command == "fundamentals":
            from .fundamentals import download_sec_fundamentals
            print(download_sec_fundamentals(settings.universe, args.output).resolve())
        elif command == "research":
            from .research import run_research
            print("Research report: " + str(run_research(args.data, args.fundamentals, settings, args.output, ablations=args.ablations).resolve()))
        elif command in ("paper-check", "paper-status", "paper-init"):
            from .paper import paper_status
            result = paper_status(settings, initialise=command == "paper-init", confirm=getattr(args, "confirm_paper", ""))
            print(json.dumps(result, indent=2))
        elif command == "paper-plan":
            from .paper import make_plan
            path = make_plan(args.data, args.fundamentals, settings, args.output)
            print(path.read_text(encoding="utf-8"))
            print("PLAN ONLY - no orders sent. Saved: " + str(path.resolve()))
        elif command == "paper-submit":
            from .paper import submit_plan
            print(json.dumps(submit_plan(args.plan, settings, args.confirm_paper), indent=2))
        elif command in ("paper-cycle", "paper-run"):
            from .paper import run_cycle, run_foreground
            if command == "paper-cycle":
                print(json.dumps(run_cycle(settings, execute=args.execute, confirm=args.confirm_paper), indent=2))
            else:
                run_foreground(settings, execute=args.execute, confirm=args.confirm_paper)
        elif command == "paper-stop":
            from .paper import stop_paper
            print(json.dumps(stop_paper(settings, cancel=args.cancel), indent=2))
        elif command == "dashboard":
            from .monitoring import serve_monitor
            serve_monitor(Path(settings.paper.state_dir), args.port)
        return 0
    except KeyboardInterrupt:
        print("Stopped by operator. Positions remain open; verify any outstanding broker orders in TWS.", file=sys.stderr)
        return 130
    except Exception as exc:
        logging.error("%s: %s", type(exc).__name__, exc)
        return 1
