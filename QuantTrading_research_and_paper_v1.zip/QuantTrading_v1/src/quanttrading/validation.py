"""Structural checks, not a claim of independently verified market prices."""

from typing import Any

import exchange_calendars as xcals
import numpy as np
import pandas as pd

from .config import Instrument, check_dates
from .market_data import FIELDS


def expected_sessions(instrument: Instrument, start: str, end: str) -> pd.DatetimeIndex:
    """End is exclusive. A weekday calendar would incorrectly include holidays."""
    check_dates(start, end)
    first, last = pd.Timestamp(start), pd.Timestamp(end)
    calendar = xcals.get_calendar(
        instrument.calendar, start=first - pd.Timedelta(days=14),
        end=last + pd.Timedelta(days=14),
    )
    sessions = calendar.sessions_in_range(first, last - pd.Timedelta(days=1))
    if sessions.tz is not None:
        sessions = sessions.tz_localize(None)
    if sessions.empty:
        raise ValueError("Requested range contains no scheduled trading sessions.")
    return sessions


def validate_bars(
    bars: pd.DataFrame, instrument: Instrument, start: str, end: str,
    metadata: dict[str, Any],
) -> dict[str, Any]:
    """Fail closed on schema, metadata, numeric, OHLC, and session defects.

    Missing sessions are errors for this fixed, established-instrument universe.
    An IPO or suspended instrument would need an explicit eligibility policy.
    """
    sessions = expected_sessions(instrument, start, end)
    errors: list[str] = []
    warnings: list[str] = []
    report: dict[str, Any] = {
        "symbol": instrument.symbol, "rows": len(bars),
        "expected_sessions": len(sessions), "calendar_requested": instrument.calendar,
        "calendar_resolved": xcals.get_calendar(instrument.calendar).name,
        "errors": errors, "warnings": warnings, "structural_pass": False,
        "independent_price_accuracy_verified": False,
    }
    required = {"date", "symbol", *FIELDS.values()}
    missing = required - set(bars.columns)
    if missing:
        errors.append(f"Missing normalized fields: {sorted(missing)}")
        return report
    if bars.empty:
        errors.append("Empty dataset.")
        return report
    for key, expected in {
        "symbol": instrument.symbol, "currency": instrument.currency,
        "exchangeTimezoneName": instrument.timezone,
        "instrumentType": instrument.instrument_type,
    }.items():
        if metadata.get(key) != expected:
            errors.append(f"Metadata {key}: expected {expected!r}, got {metadata.get(key)!r}.")
    if not bars["symbol"].eq(instrument.symbol).all():
        errors.append("Unexpected or missing symbol.")
    dates = bars["date"]
    if not pd.api.types.is_datetime64_any_dtype(dates) or dates.dt.tz is not None:
        errors.append("date must contain timezone-naive exchange-local session labels.")
        return report
    if dates.isna().any() or not dates.eq(dates.dt.normalize()).all():
        errors.append("Missing dates or non-midnight session labels.")
    if not dates.is_monotonic_increasing:
        errors.append("Session dates are not sorted.")
    duplicates = int(bars.duplicated(["symbol", "date"]).sum())
    report["duplicate_keys"] = duplicates
    if duplicates:
        errors.append(f"Duplicate (symbol, date) keys: {duplicates}.")
    observed = pd.DatetimeIndex(dates.dropna()).unique()
    absent, extra = sessions.difference(observed), observed.difference(sessions)
    report["missing_sessions"] = absent.strftime("%Y-%m-%d").tolist()
    report["unexpected_sessions"] = extra.strftime("%Y-%m-%d").tolist()
    if len(absent):
        errors.append(f"Missing expected sessions: {len(absent)}; no values were filled.")
    if len(extra):
        errors.append(f"Out-of-range or non-trading session dates: {len(extra)}.")
    numeric_names = list(FIELDS.values())
    if "capital_gains" in bars.columns:
        numeric_names.append("capital_gains")
    numbers = bars[numeric_names].apply(pd.to_numeric, errors="coerce")
    finite = np.isfinite(numbers.to_numpy(dtype=float))
    report["nonfinite_values"] = int((~finite).sum())
    if not finite.all():
        errors.append("Missing, non-numeric, or infinite numeric values.")
    price_names = ["open", "high", "low", "close", "adj_close"]
    if (numbers[price_names] <= 0).any().any():
        errors.append("Prices must be strictly positive.")
    tolerance = 1e-8 * numbers[["open", "high", "low", "close"]].abs().max(axis=1)
    bad_ohlc = (
        (numbers["low"] > numbers[["open", "close", "high"]].min(axis=1) + tolerance)
        | (numbers["high"] < numbers[["open", "close", "low"]].max(axis=1) - tolerance)
    )
    if bad_ohlc.any():
        errors.append(f"OHLC ordering violated in {int(bad_ohlc.sum())} rows.")
    volume = numbers["volume"]
    if ((volume < 0) | (volume % 1 != 0)).any():
        errors.append("Volume must be a non-negative whole number of shares.")
    zero_volume = int(volume.eq(0).sum())
    if zero_volume:
        warnings.append(f"Zero volume in {zero_volume} sessions: investigate before research.")
    action_names = ["dividends", "stock_splits"]
    if "capital_gains" in numbers:
        action_names.append("capital_gains")
    if (numbers[action_names] < 0).any().any():
        errors.append("Negative distributions or split ratios.")
    moves = numbers["adj_close"].pct_change(fill_method=None).abs() > 0.25
    report["large_move_dates"] = dates[moves].dt.strftime("%Y-%m-%d").tolist()
    if moves.any():
        warnings.append(f"{int(moves.sum())} adjusted-close moves exceed 25%; inspect, do not delete.")
    report["first_session"] = str(dates.min().date()) if dates.notna().any() else None
    report["last_session"] = str(dates.max().date()) if dates.notna().any() else None
    report["structural_pass"] = not errors
    report["review_required"] = bool(warnings)
    return report
