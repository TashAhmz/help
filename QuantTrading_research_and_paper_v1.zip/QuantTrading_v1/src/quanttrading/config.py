"""Explicit USD daily-bar instrument registry; additions require deliberate metadata."""

from dataclasses import dataclass
from datetime import date, datetime
from zoneinfo import ZoneInfo


@dataclass(frozen=True)
class Instrument:
    symbol: str
    calendar: str
    instrument_type: str
    currency: str = "USD"
    timezone: str = "America/New_York"


INSTRUMENTS = {
    "SPY": Instrument("SPY", "ARCX", "ETF"),
    "QQQ": Instrument("QQQ", "XNAS", "ETF"),
    "AAPL": Instrument("AAPL", "XNAS", "EQUITY"),
    "MSFT": Instrument("MSFT", "XNAS", "EQUITY"),
    "AMZN": Instrument("AMZN", "XNAS", "EQUITY"),
    "GOOGL": Instrument("GOOGL", "XNAS", "EQUITY"),
    "META": Instrument("META", "XNAS", "EQUITY"),
    "NVDA": Instrument("NVDA", "XNAS", "EQUITY"),
}
DEFAULT_START = "2020-01-01"
DEFAULT_END = "2026-01-01"  # Exclusive: never means a bar for 1 January.


def check_dates(start: str, end: str) -> None:
    """Reject invalid ranges and today's possibly incomplete daily candle."""
    first, last = date.fromisoformat(start), date.fromisoformat(end)
    if (first.isoformat(), last.isoformat()) != (start, end):
        raise ValueError("Use YYYY-MM-DD dates.")
    if first >= last:
        raise ValueError("start must be earlier than exclusive end.")
    today_ny = datetime.now(ZoneInfo("America/New_York")).date()
    if last > today_ny:
        raise ValueError("end must be no later than today's New York date.")
