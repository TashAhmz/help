"""
APEX TRADING SYSTEM - Oracle Database Configuration
=====================================================

SETUP STEPS (all free):
  1. Go to: https://cloud.oracle.com
  2. Click "Start for free" → Create account
  3. Sign in → top-left menu → Oracle Database → Autonomous Database
  4. Click "Create Autonomous Database"
     - Display name: APEX_TRADING
     - Workload type: Transaction Processing
     - Deployment: Serverless
     - Always Free: ✅ ON
     - Password: set a strong password
  5. Once created → click "DB Connection"
  6. Download Wallet → save as ZIP
  7. Extract wallet ZIP to: config/oracle_wallet/ folder
  8. Fill in the values below
"""

# ─────────────────────────────────────────────
# ORACLE CREDENTIALS
# ─────────────────────────────────────────────
ORACLE_USER     = "YOUR_ORACLE_USER"       # Usually "admin"
ORACLE_PASSWORD = "YOUR_ORACLE_PASSWORD"   # Password you set when creating DB
ORACLE_DSN      = "YOUR_DB_NAME_high"      # From tnsnames.ora in wallet folder
                                           # e.g. "apextrading_high"

# ─────────────────────────────────────────────
# WALLET (downloaded from Oracle Cloud)
# ─────────────────────────────────────────────
ORACLE_WALLET_DIR      = "config/oracle_wallet"   # Folder with wallet files
ORACLE_WALLET_PASSWORD = "YOUR_WALLET_PASSWORD"   # Set when downloading wallet

# ─────────────────────────────────────────────
# CONNECTION POOL
# ─────────────────────────────────────────────
ORACLE_POOL_MIN  = 1
ORACLE_POOL_MAX  = 5
ORACLE_POOL_INC  = 1
