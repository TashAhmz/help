@echo off
title APEX Trading System - Setup
color 0B
echo.
echo  ============================================
echo   ^  APEX TRADING SYSTEM v3 - INSTALLER
echo  ============================================
echo.

python --version >nul 2>&1
if %errorlevel% neq 0 (
    echo  [ERROR] Python not found!
    echo  Download from: https://www.python.org/downloads/
    echo  IMPORTANT: Tick "Add Python to PATH" during install!
    pause
    exit /b 1
)
echo  [OK] Python found:
python --version

echo.
echo  Installing all dependencies...
echo  (This may take 3-5 minutes)
echo.

pip install -r requirements.txt

echo.
echo  ============================================
echo   SETUP COMPLETE!
echo  ============================================
echo.
echo  Next steps:
echo.
echo  1. Install MT5 from vantagemarkets.com
echo  2. Log in with your Vantage DEMO account
echo  3. In MT5: click "Algo Trading" button until GREEN
echo  4. Open config\mt5_config.py in Notepad and fill in:
echo       MT5_LOGIN    = your demo account number
echo       MT5_PASSWORD = your password
echo       MT5_SERVER   = VantageInternational-Demo
echo.
echo  5. Double-click DASHBOARD_DEMO.bat to test
echo  6. Double-click LAUNCH.bat to go live
echo.
echo  ORACLE DB (optional, free):
echo     cloud.oracle.com - Create free account
echo     Fill in config\oracle_config.py
echo.
pause
