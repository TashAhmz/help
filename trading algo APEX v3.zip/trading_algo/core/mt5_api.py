"""
APEX TRADING SYSTEM - MetaTrader5 Python API Connector
=======================================================
Uses the official MetaTrader5 Python library as the SOLE
connection method for both market data AND trade execution.

This replaces both the REST API and the old MT5 bridge.
All data — prices, OHLCV, positions, history — comes directly
from MT5. All orders are placed directly through MT5.

SETUP:
  pip install MetaTrader5
  → Open MT5 (Vantage demo account)
  → Tools → Options → Expert Advisors → tick Allow Automated Trading
  → Fill in config/mt5_config.py
"""

import time
import logging
import numpy as np
import pandas as pd
from datetime import datetime, timedelta
from typing import Optional, Dict, List
import uuid

logger = logging.getLogger(__name__)

# ── Vantage MT5 Symbol Map ────────────────────────────────────
# These are the exact symbol names used on Vantage MT5 demo.
# Open MT5 → View → Symbols to verify on your account.
SYMBOL_MAP = {
    "XAUUSD": "XAUUSD",
    "XAGUSD": "XAGUSD",
    "USOIL":  "USOIL",
    "UKOIL":  "UKOIL",
    "NGAS":   "NGAS",
    "HEAT":   "HEAT",
    "RBOB":   "RBOB",
    "CARBON": "CARBON",
    "ETHUSD": "ETHUSD",
}

# MT5 timeframe map
TF_MAP = {
    "1m":  1,
    "5m":  5,
    "15m": 15,
    "30m": 30,
    "1h":  16385,
    "4h":  16388,
    "1d":  16408,
    "1w":  32769,
    "1mn": 49153,
}

APEX_MAGIC = 20250101  # Unique identifier for APEX orders in MT5


class MT5API:
    """
    Primary broker interface using the MetaTrader5 Python API.
    Handles market data, order execution, position management,
    and account information — all through MT5 directly.
    """

    def __init__(self, mode: str = "paper"):
        self.mode = mode
        self.connected = False
        self._mt5 = None
        self._account_cache: Optional[Dict] = None
        self._price_cache: Dict[str, Dict] = {}
        self._paper_positions: Dict[str, Dict] = {}
        self._paper_balance = 10000.0
        self._paper_trades: List[Dict] = []
        self._connect()

    # ─────────────────────────────────────────────
    # CONNECTION
    # ─────────────────────────────────────────────

    def _connect(self):
        """Connect to the running MT5 terminal."""
        try:
            import MetaTrader5 as mt5
            self._mt5 = mt5
        except ImportError:
            logger.error(
                "MetaTrader5 not installed. Run: pip install MetaTrader5\n"
                "Requires Windows + MT5 terminal installed."
            )
            return

        from config.mt5_config import MT5_LOGIN, MT5_PASSWORD, MT5_SERVER, MT5_PATH

        # Check credentials are set
        if not MT5_LOGIN or MT5_LOGIN == 0:
            logger.warning(
                "MT5 credentials not configured — running in paper mode.\n"
                "Edit config/mt5_config.py to connect your Vantage demo account."
            )
            return

        # Initialize
        kwargs = {
            "login":    int(MT5_LOGIN),
            "password": str(MT5_PASSWORD),
            "server":   str(MT5_SERVER),
        }
        if MT5_PATH:
            kwargs["path"] = MT5_PATH

        if not self._mt5.initialize(**kwargs):
            err = self._mt5.last_error()
            logger.error(
                f"MT5 init failed: {err}\n"
                "Check:\n"
                "  1. MT5 is installed and running\n"
                "  2. Credentials in config/mt5_config.py are correct\n"
                "  3. AutoTrading is enabled (green button in MT5 toolbar)"
            )
            return

        acct = self._mt5.account_info()
        if acct is None:
            logger.error("MT5 connected but cannot retrieve account info")
            self._mt5.shutdown()
            return

        self.connected = True
        self._paper_balance = float(acct.balance)

        logger.info(
            f"✅ MT5 Connected\n"
            f"   Account  : #{acct.login}\n"
            f"   Name     : {acct.name}\n"
            f"   Server   : {acct.server}\n"
            f"   Balance  : ${acct.balance:,.2f}\n"
            f"   Leverage : 1:{acct.leverage}\n"
            f"   Demo     : {acct.trade_mode == 0}"
        )

        # Enable all symbols we trade
        self._enable_symbols()

    def _enable_symbols(self):
        """Ensure all APEX symbols are visible in MT5 market watch."""
        for apex_sym, mt5_sym in SYMBOL_MAP.items():
            result = self._mt5.symbol_select(mt5_sym, True)
            if not result:
                logger.warning(f"Could not enable {mt5_sym} — may not exist on this server")

    def sym(self, apex_symbol: str) -> str:
        """Resolve APEX symbol name to MT5 symbol name."""
        from config.mt5_config import SYMBOL_OVERRIDES
        overrides = SYMBOL_OVERRIDES or {}
        return overrides.get(apex_symbol, SYMBOL_MAP.get(apex_symbol, apex_symbol))

    # ─────────────────────────────────────────────
    # ACCOUNT INFO
    # ─────────────────────────────────────────────

    def get_account_info(self) -> Dict:
        if not self.connected:
            return self._paper_account_info()
        try:
            a = self._mt5.account_info()
            info = {
                "login":        a.login,
                "name":         a.name,
                "server":       a.server,
                "balance":      float(a.balance),
                "equity":       float(a.equity),
                "margin":       float(a.margin),
                "free_margin":  float(a.margin_free),
                "margin_level": float(a.margin_level) if a.margin_level else 0.0,
                "profit":       float(a.profit),
                "currency":     a.currency,
                "leverage":     a.leverage,
                "is_demo":      a.trade_mode == 0,
            }
            self._account_cache = info
            return info
        except Exception as e:
            logger.error(f"account_info error: {e}")
            return self._account_cache or self._paper_account_info()

    def get_account_balance(self) -> float:
        return float(self.get_account_info().get("balance", 0))

    def get_equity(self) -> float:
        return float(self.get_account_info().get("equity", 0))

    def _paper_account_info(self) -> Dict:
        unrealized = sum(
            p.get("unrealized_pnl", 0) for p in self._paper_positions.values()
        )
        return {
            "login": 0, "name": "Paper Account", "server": "Paper",
            "balance": self._paper_balance,
            "equity":  self._paper_balance + unrealized,
            "margin": 0.0, "free_margin": self._paper_balance,
            "margin_level": 0.0, "profit": unrealized,
            "currency": "USD", "leverage": 500, "is_demo": True,
        }

    # ─────────────────────────────────────────────
    # MARKET DATA — via MT5 Python API
    # ─────────────────────────────────────────────

    def get_tick(self, symbol: str) -> Optional[Dict]:
        """Get latest tick (bid/ask/last) from MT5."""
        if not self.connected:
            return self._synthetic_tick(symbol)
        try:
            mt5_sym = self.sym(symbol)
            tick = self._mt5.symbol_info_tick(mt5_sym)
            if tick:
                data = {
                    "symbol": symbol,
                    "bid":    float(tick.bid),
                    "ask":    float(tick.ask),
                    "price":  float((tick.bid + tick.ask) / 2),
                    "spread": float(tick.ask - tick.bid),
                    "volume": float(tick.volume),
                    "time":   datetime.fromtimestamp(tick.time).isoformat(),
                }
                self._price_cache[symbol] = data
                return data
        except Exception as e:
            logger.error(f"get_tick {symbol}: {e}")
        return self._price_cache.get(symbol) or self._synthetic_tick(symbol)

    def get_price(self, symbol: str) -> Optional[Dict]:
        """Alias for get_tick — keeps compatibility."""
        return self.get_tick(symbol)

    def get_prices_bulk(self, symbols: List[str]) -> Dict:
        """Fetch ticks for multiple symbols efficiently."""
        result = {}
        for sym in symbols:
            tick = self.get_tick(sym)
            if tick:
                result[sym] = tick
        return result

    def get_ohlcv(self, symbol: str, timeframe: str = "1h",
                  limit: int = 500) -> Optional[List[Dict]]:
        """
        Fetch OHLCV bars directly from MT5.
        Returns list of dicts with: timestamp, open, high, low, close, volume
        """
        if not self.connected:
            return None
        try:
            mt5_sym = self.sym(symbol)
            tf = TF_MAP.get(timeframe, 16385)
            rates = self._mt5.copy_rates_from_pos(mt5_sym, tf, 0, limit)
            if rates is None or len(rates) == 0:
                logger.warning(f"No OHLCV data from MT5 for {symbol} {timeframe}")
                return None
            return [
                {
                    "timestamp": int(r["time"]),
                    "open":   float(r["open"]),
                    "high":   float(r["high"]),
                    "low":    float(r["low"]),
                    "close":  float(r["close"]),
                    "volume": float(r["tick_volume"]),
                }
                for r in rates
            ]
        except Exception as e:
            logger.error(f"get_ohlcv {symbol} {timeframe}: {e}")
            return None

    def get_ohlcv_df(self, symbol: str, timeframe: str = "1h",
                     limit: int = 500) -> Optional[pd.DataFrame]:
        """Get OHLCV as a pandas DataFrame with DatetimeIndex."""
        if not self.connected:
            return None
        try:
            mt5_sym = self.sym(symbol)
            tf = TF_MAP.get(timeframe, 16385)
            rates = self._mt5.copy_rates_from_pos(mt5_sym, tf, 0, limit)
            if rates is None or len(rates) == 0:
                return None
            df = pd.DataFrame(rates)
            df["time"] = pd.to_datetime(df["time"], unit="s")
            df.set_index("time", inplace=True)
            df.rename(columns={"tick_volume": "volume"}, inplace=True)
            df = df[["open", "high", "low", "close", "volume"]].astype(float)
            df.sort_index(inplace=True)
            return df
        except Exception as e:
            logger.error(f"get_ohlcv_df {symbol}: {e}")
            return None

    def get_symbol_info(self, symbol: str) -> Optional[Dict]:
        """Get symbol specs: digits, contract size, min/max volume."""
        if not self.connected:
            return None
        try:
            mt5_sym = self.sym(symbol)
            info = self._mt5.symbol_info(mt5_sym)
            if info:
                return {
                    "symbol":              symbol,
                    "digits":              info.digits,
                    "point":               info.point,
                    "contract_size":       info.trade_contract_size,
                    "volume_min":          info.volume_min,
                    "volume_max":          info.volume_max,
                    "volume_step":         info.volume_step,
                    "spread":              info.spread,
                    "stops_level":         info.trade_stops_level,
                    "margin_initial":      info.margin_initial,
                    "currency_profit":     info.currency_profit,
                }
        except Exception as e:
            logger.error(f"symbol_info {symbol}: {e}")
        return None

    def is_market_open(self, symbol: str) -> bool:
        """Check if symbol is currently tradeable."""
        if not self.connected:
            return True
        try:
            info = self._mt5.symbol_info(self.sym(symbol))
            return info is not None and info.trade_mode != 0
        except Exception:
            return True

    # ─────────────────────────────────────────────
    # ORDER EXECUTION — via MT5 Python API
    # ─────────────────────────────────────────────

    def place_order(self, symbol: str, side: str, order_type: str = "market",
                    volume: float = 0.01, price: float = None,
                    stop_loss: float = None, take_profit: float = None,
                    comment: str = "APEX") -> Optional[Dict]:
        """
        Place a trade order through MT5.
        Supports market and limit orders.
        Routes to paper simulation if mode == 'paper'.
        """
        if self.mode == "paper":
            return self._paper_place_order(
                symbol, side, order_type, volume, price, stop_loss, take_profit
            )

        if not self.connected:
            logger.error("MT5 not connected — cannot place live order")
            return None

        try:
            mt5_sym = self.sym(symbol)
            sym_info = self._mt5.symbol_info(mt5_sym)
            if not sym_info:
                logger.error(f"Symbol {mt5_sym} not found in MT5")
                return None

            # Clamp volume to broker limits
            vol_min  = sym_info.volume_min
            vol_max  = sym_info.volume_max
            vol_step = sym_info.volume_step
            volume = max(vol_min, min(vol_max, round(volume / vol_step) * vol_step))

            # Current tick
            tick = self._mt5.symbol_info_tick(mt5_sym)
            if not tick:
                logger.error(f"No tick data for {mt5_sym}")
                return None

            # Order type and execution price
            if side.lower() == "buy":
                if order_type == "limit":
                    mt5_type = self._mt5.ORDER_TYPE_BUY_LIMIT
                    exec_price = price or tick.ask
                else:
                    mt5_type = self._mt5.ORDER_TYPE_BUY
                    exec_price = tick.ask
            else:
                if order_type == "limit":
                    mt5_type = self._mt5.ORDER_TYPE_SELL_LIMIT
                    exec_price = price or tick.bid
                else:
                    mt5_type = self._mt5.ORDER_TYPE_SELL
                    exec_price = tick.bid

            # Validate SL/TP distance (broker minimum stops_level)
            stops_level = sym_info.trade_stops_level * sym_info.point
            if stop_loss:
                sl_dist = abs(exec_price - stop_loss)
                if sl_dist < stops_level:
                    logger.warning(f"SL too close ({sl_dist:.5f} < {stops_level:.5f}), adjusting")
                    stop_loss = (exec_price - stops_level * 1.5
                                 if side == "buy"
                                 else exec_price + stops_level * 1.5)
            if take_profit:
                tp_dist = abs(exec_price - take_profit)
                if tp_dist < stops_level:
                    logger.warning(f"TP too close, adjusting")
                    take_profit = (exec_price + stops_level * 1.5
                                   if side == "buy"
                                   else exec_price - stops_level * 1.5)

            # Build MT5 request
            request = {
                "action":       self._mt5.TRADE_ACTION_DEAL,
                "symbol":       mt5_sym,
                "volume":       float(volume),
                "type":         mt5_type,
                "price":        float(exec_price),
                "deviation":    30,
                "magic":        APEX_MAGIC,
                "comment":      comment[:31],
                "type_time":    self._mt5.ORDER_TIME_GTC,
                "type_filling": self._mt5.ORDER_FILLING_IOC,
            }
            if stop_loss:
                request["sl"] = float(round(stop_loss, sym_info.digits))
            if take_profit:
                request["tp"] = float(round(take_profit, sym_info.digits))

            result = self._mt5.order_send(request)

            if result is None:
                logger.error(f"order_send returned None for {symbol}")
                return None

            if result.retcode == self._mt5.TRADE_RETCODE_DONE:
                logger.info(
                    f"✅ Order filled | {side.upper()} {volume} {symbol} "
                    f"@ {result.price:.5f} | Ticket #{result.order}"
                )
                return {
                    "id":          str(result.order),
                    "ticket":      result.order,
                    "symbol":      symbol,
                    "side":        side.lower(),
                    "volume":      float(volume),
                    "price":       float(result.price),
                    "stopLoss":    stop_loss,
                    "takeProfit":  take_profit,
                    "status":      "filled",
                    "timestamp":   datetime.now().isoformat(),
                }
            else:
                logger.error(
                    f"Order rejected | {symbol} | "
                    f"Code: {result.retcode} — {self._retcode_desc(result.retcode)} | "
                    f"Comment: {result.comment}"
                )
                return None

        except Exception as e:
            logger.error(f"place_order exception {symbol}: {e}", exc_info=True)
            return None

    def close_position(self, position_id: str,
                       volume: float = None) -> Optional[Dict]:
        """Close an open position by ticket ID."""
        if self.mode == "paper":
            return self._paper_close_position(position_id)

        if not self.connected:
            return None
        try:
            ticket = int(position_id)
            positions = self._mt5.positions_get(ticket=ticket)
            if not positions:
                logger.warning(f"Position #{ticket} not found")
                return None

            pos = positions[0]
            mt5_sym = pos.symbol
            close_vol = volume or pos.volume
            tick = self._mt5.symbol_info_tick(mt5_sym)

            if pos.type == 0:  # Buy → close with sell
                close_type  = self._mt5.ORDER_TYPE_SELL
                close_price = tick.bid
            else:              # Sell → close with buy
                close_type  = self._mt5.ORDER_TYPE_BUY
                close_price = tick.ask

            request = {
                "action":       self._mt5.TRADE_ACTION_DEAL,
                "symbol":       mt5_sym,
                "volume":       float(close_vol),
                "type":         close_type,
                "position":     ticket,
                "price":        float(close_price),
                "deviation":    30,
                "magic":        APEX_MAGIC,
                "comment":      "APEX_CLOSE",
                "type_time":    self._mt5.ORDER_TIME_GTC,
                "type_filling": self._mt5.ORDER_FILLING_IOC,
            }
            result = self._mt5.order_send(request)

            if result and result.retcode == self._mt5.TRADE_RETCODE_DONE:
                logger.info(f"Position #{ticket} closed @ {result.price}")
                return {
                    "status": "closed", "id": position_id,
                    "price": result.price, "ticket": ticket
                }
            else:
                code = result.retcode if result else "None"
                logger.error(f"Close failed: {code}")
                return None

        except Exception as e:
            logger.error(f"close_position error: {e}")
            return None

    def modify_position(self, position_id: str,
                        stop_loss: float = None,
                        take_profit: float = None) -> Optional[Dict]:
        """Modify SL/TP of an existing position."""
        if self.mode == "paper":
            if position_id in self._paper_positions:
                if stop_loss:
                    self._paper_positions[position_id]["stop_loss"] = stop_loss
                if take_profit:
                    self._paper_positions[position_id]["take_profit"] = take_profit
            return {"status": "modified"}

        if not self.connected:
            return None
        try:
            ticket = int(position_id)
            positions = self._mt5.positions_get(ticket=ticket)
            if not positions:
                return None
            pos = positions[0]
            request = {
                "action":   self._mt5.TRADE_ACTION_SLTP,
                "symbol":   pos.symbol,
                "position": ticket,
                "sl": float(stop_loss)   if stop_loss   else pos.sl,
                "tp": float(take_profit) if take_profit else pos.tp,
            }
            result = self._mt5.order_send(request)
            if result and result.retcode == self._mt5.TRADE_RETCODE_DONE:
                return {"status": "modified", "id": position_id}
            return None
        except Exception as e:
            logger.error(f"modify_position error: {e}")
            return None

    # Alias for compatibility
    def modify_order(self, order_id: str, stop_loss: float = None,
                     take_profit: float = None) -> Optional[Dict]:
        return self.modify_position(order_id, stop_loss, take_profit)

    # ─────────────────────────────────────────────
    # POSITIONS & HISTORY
    # ─────────────────────────────────────────────

    def get_open_positions(self) -> List[Dict]:
        """Get all open positions from MT5."""
        if not self.connected:
            return list(self._paper_positions.values())
        try:
            positions = self._mt5.positions_get()
            if not positions:
                return []
            result = []
            for p in positions:
                result.append({
                    "id":             str(p.ticket),
                    "ticket":         p.ticket,
                    "symbol":         p.symbol,
                    "side":           "buy" if p.type == 0 else "sell",
                    "volume":         float(p.volume),
                    "entry_price":    float(p.price_open),
                    "current_price":  float(p.price_current),
                    "stop_loss":      float(p.sl),
                    "take_profit":    float(p.tp),
                    "unrealized_pnl": float(p.profit),
                    "swap":           float(p.swap),
                    "comment":        p.comment,
                    "magic":          p.magic,
                    "opened_at":      datetime.fromtimestamp(p.time).isoformat(),
                })
            return result
        except Exception as e:
            logger.error(f"get_open_positions error: {e}")
            return []

    def get_trade_history(self, from_date: datetime = None,
                          to_date: datetime = None) -> List[Dict]:
        """Get closed trade history from MT5."""
        if not self.connected:
            return list(self._paper_trades)
        try:
            if not from_date:
                from_date = datetime.now() - timedelta(days=30)
            if not to_date:
                to_date = datetime.now() + timedelta(hours=1)

            deals = self._mt5.history_deals_get(from_date, to_date)
            if not deals:
                return []

            trades = []
            for d in deals:
                if d.entry == 1 and d.magic == APEX_MAGIC:
                    trades.append({
                        "id":          str(d.ticket),
                        "symbol":      d.symbol,
                        "side":        "buy" if d.type == 0 else "sell",
                        "volume":      float(d.volume),
                        "entry_price": float(d.price),
                        "profit":      float(d.profit),
                        "commission":  float(d.commission),
                        "swap":        float(d.swap),
                        "closed_at":   datetime.fromtimestamp(d.time).isoformat(),
                        "comment":     d.comment,
                    })
            return trades
        except Exception as e:
            logger.error(f"get_trade_history error: {e}")
            return []

    def get_daily_pnl(self) -> float:
        today = datetime.now().replace(hour=0, minute=0, second=0, microsecond=0)
        trades = self.get_trade_history(from_date=today)
        return sum(float(t.get("profit", 0)) for t in trades)

    def get_pending_orders(self) -> List[Dict]:
        if not self.connected:
            return []
        try:
            orders = self._mt5.orders_get()
            if not orders:
                return []
            return [
                {"id": str(o.ticket), "symbol": o.symbol,
                 "type": o.type, "volume": o.volume_current,
                 "price": o.price_open, "sl": o.sl, "tp": o.tp}
                for o in orders
            ]
        except Exception as e:
            logger.error(f"get_pending_orders error: {e}")
            return []

    # ─────────────────────────────────────────────
    # PAPER TRADING SIMULATION
    # ─────────────────────────────────────────────

    def _paper_place_order(self, symbol, side, order_type,
                           volume, price, sl, tp) -> Dict:
        tick = self.get_tick(symbol)
        exec_price = price or (
            tick["ask"] if side == "buy" else tick["bid"]
        ) if tick else 100.0

        order_id = str(uuid.uuid4())[:8].upper()
        position = {
            "id":             order_id,
            "symbol":         symbol,
            "side":           side.lower(),
            "volume":         volume,
            "entry_price":    exec_price,
            "current_price":  exec_price,
            "stop_loss":      sl or 0,
            "take_profit":    tp or 0,
            "unrealized_pnl": 0.0,
            "opened_at":      datetime.now().isoformat(),
            "comment":        "PAPER",
        }
        self._paper_positions[order_id] = position
        logger.info(
            f"[PAPER] {side.upper()} {volume} {symbol} @ {exec_price:.4f} "
            f"| SL={sl} TP={tp} | ID={order_id}"
        )
        return {
            "id": order_id, "symbol": symbol, "side": side,
            "volume": volume, "price": exec_price,
            "stopLoss": sl, "takeProfit": tp,
            "status": "filled", "timestamp": datetime.now().isoformat(),
            "paper": True,
        }

    def _paper_close_position(self, position_id: str) -> Optional[Dict]:
        pos = self._paper_positions.pop(position_id, None)
        if not pos:
            return None
        tick = self.get_tick(pos["symbol"])
        current = tick["bid"] if pos["side"] == "buy" else tick["ask"] if tick else pos["entry_price"]
        if pos["side"] == "buy":
            profit = (current - pos["entry_price"]) * pos["volume"] * 100
        else:
            profit = (pos["entry_price"] - current) * pos["volume"] * 100
        self._paper_balance += profit
        trade = {**pos, "profit": profit, "closed_at": datetime.now().isoformat()}
        self._paper_trades.append(trade)
        return {"status": "closed", "id": position_id, "profit": profit}

    def update_paper_prices(self):
        """Update unrealized P&L for paper positions."""
        for pos_id, pos in self._paper_positions.items():
            tick = self.get_tick(pos["symbol"])
            if tick:
                current = tick["bid"] if pos["side"] == "buy" else tick["ask"]
                pos["current_price"] = current
                if pos["side"] == "buy":
                    pos["unrealized_pnl"] = (current - pos["entry_price"]) * pos["volume"] * 100
                else:
                    pos["unrealized_pnl"] = (pos["entry_price"] - current) * pos["volume"] * 100

    # ─────────────────────────────────────────────
    # SYNTHETIC DATA (when not connected)
    # ─────────────────────────────────────────────

    def _synthetic_tick(self, symbol: str) -> Dict:
        """Generate realistic synthetic tick for demo/paper mode."""
        import math
        base = {
            "XAUUSD": 2045.0, "XAGUSD": 24.3,
            "USOIL":  78.9,   "UKOIL":  82.4,
            "NGAS":   2.48,   "HEAT":   2.81,
            "RBOB":   2.41,   "CARBON": 65.0, "ETHUSD": 3200.0,
        }.get(symbol, 100.0)

        t = time.time()
        noise = base * 0.0008 * math.sin(t / 13.7 + hash(symbol) % 100)
        mid = base + noise
        spread = base * 0.0002
        return {
            "symbol": symbol, "bid": mid - spread / 2,
            "ask": mid + spread / 2, "price": mid,
            "spread": spread, "volume": 0,
            "time": datetime.now().isoformat(),
        }

    # ─────────────────────────────────────────────
    # UTILITIES
    # ─────────────────────────────────────────────

    def _retcode_desc(self, code: int) -> str:
        DESC = {
            10004: "Requote", 10006: "Rejected", 10007: "Cancelled",
            10009: "Done", 10013: "Invalid request", 10014: "Invalid volume",
            10015: "Invalid price", 10016: "Invalid stops",
            10017: "Trade disabled", 10018: "Market closed",
            10019: "Insufficient funds", 10024: "Too many requests",
            10026: "Autotrading disabled by server",
            10027: "Autotrading disabled by client",
        }
        return DESC.get(code, f"Code {code}")

    def shutdown(self):
        """Cleanly disconnect from MT5."""
        if self.connected and self._mt5:
            self._mt5.shutdown()
            self.connected = False
            logger.info("MT5 disconnected cleanly")
