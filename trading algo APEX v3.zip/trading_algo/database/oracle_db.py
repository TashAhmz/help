"""
APEX TRADING SYSTEM - Oracle Database Connector
=================================================
Uses Oracle Cloud Free Tier (Always Free) as the persistent
database for all trading data.

Oracle Free Tier includes:
  - 2x AMD compute VMs (always free)
  - Autonomous Database — 20GB storage, always free
  - No credit card charges after trial

SETUP GUIDE:
  1. Go to: cloud.oracle.com → Create Free Account
  2. Sign in → Oracle Database → Autonomous Database
  3. Create Autonomous Transaction Processing (ATP) — Always Free
  4. Download Wallet (connection credentials ZIP)
  5. Extract wallet to: config/oracle_wallet/
  6. Fill in config/oracle_config.py
  7. pip install oracledb

SCHEMA (auto-created on first run):
  POSITIONS       — Live open positions
  TRADE_HISTORY   — All closed trades
  DAILY_PNL       — Daily P&L snapshots
  SIGNALS_LOG     — ML signal log
  PORTFOLIO_SNAP  — Portfolio snapshots
  SYSTEM_LOG      — System events & errors
  ML_METRICS      — Model performance metrics
"""

import json
import logging
import threading
from datetime import datetime, date
from typing import Dict, List, Any, Optional
from pathlib import Path

logger = logging.getLogger(__name__)


class OracleDB:
    """
    Oracle Autonomous Database connector.
    Falls back to local SQLite if Oracle not yet configured.
    Same interface as the old FirebaseDB — drop-in replacement.
    """

    def __init__(self):
        self._lock = threading.Lock()
        self.connected = False
        self._conn = None
        self._use_sqlite = False
        self._connect()

    # ─────────────────────────────────────────────
    # CONNECTION
    # ─────────────────────────────────────────────

    def _connect(self):
        """Connect to Oracle or fall back to SQLite."""
        # Try Oracle first
        if self._try_oracle():
            return
        # Fall back to SQLite
        logger.warning(
            "Oracle not configured — using local SQLite database.\n"
            "Set up Oracle Free Tier and edit config/oracle_config.py to persist data to the cloud."
        )
        self._use_sqlite = True
        self._connect_sqlite()

    def _try_oracle(self) -> bool:
        """Attempt Oracle connection."""
        try:
            from config.oracle_config import (
                ORACLE_USER, ORACLE_PASSWORD, ORACLE_DSN,
                ORACLE_WALLET_DIR, ORACLE_WALLET_PASSWORD
            )

            if ORACLE_USER == "YOUR_ORACLE_USER":
                return False

            import oracledb

            # Thick mode for wallet-based connections
            wallet_path = Path(ORACLE_WALLET_DIR)
            if wallet_path.exists():
                oracledb.init_oracle_client()
                self._conn = oracledb.connect(
                    user=ORACLE_USER,
                    password=ORACLE_PASSWORD,
                    dsn=ORACLE_DSN,
                    wallet_location=str(wallet_path),
                    wallet_password=ORACLE_WALLET_PASSWORD,
                )
            else:
                # Thin mode (no wallet — for TCP connections)
                self._conn = oracledb.connect(
                    user=ORACLE_USER,
                    password=ORACLE_PASSWORD,
                    dsn=ORACLE_DSN,
                )

            self.connected = True
            logger.info("✅ Oracle Autonomous Database connected")
            self._create_schema()
            return True

        except ImportError:
            logger.warning("oracledb not installed. Run: pip install oracledb")
            return False
        except Exception as e:
            logger.warning(f"Oracle connection failed: {e}")
            return False

    def _connect_sqlite(self):
        """Connect to local SQLite as fallback."""
        import sqlite3
        Path("data").mkdir(exist_ok=True)
        self._conn = sqlite3.connect(
            "data/apex_local.db",
            check_same_thread=False
        )
        self._conn.row_factory = sqlite3.Row
        self.connected = True
        logger.info("✅ SQLite fallback database connected: data/apex_local.db")
        self._create_schema()

    def _create_schema(self):
        """Create all tables if they don't exist."""
        tables = [
            """CREATE TABLE IF NOT EXISTS positions (
                id            VARCHAR2(64)  PRIMARY KEY,
                symbol        VARCHAR2(20)  NOT NULL,
                side          VARCHAR2(10),
                volume        NUMBER(10,4),
                entry_price   NUMBER(20,8),
                current_price NUMBER(20,8),
                stop_loss     NUMBER(20,8),
                take_profit   NUMBER(20,8),
                unrealized_pnl NUMBER(15,4),
                opened_at     TIMESTAMP,
                updated_at    TIMESTAMP,
                extra_json    CLOB
            )""",
            """CREATE TABLE IF NOT EXISTS trade_history (
                id            VARCHAR2(64)  PRIMARY KEY,
                symbol        VARCHAR2(20),
                side          VARCHAR2(10),
                volume        NUMBER(10,4),
                entry_price   NUMBER(20,8),
                close_price   NUMBER(20,8),
                profit        NUMBER(15,4),
                commission    NUMBER(10,4),
                swap          NUMBER(10,4),
                opened_at     TIMESTAMP,
                closed_at     TIMESTAMP,
                comment       VARCHAR2(255),
                strategy      VARCHAR2(64),
                confidence    NUMBER(5,4)
            )""",
            """CREATE TABLE IF NOT EXISTS daily_pnl (
                trade_date    DATE          PRIMARY KEY,
                pnl           NUMBER(15,4),
                pnl_pct       NUMBER(8,4),
                trades_count  INTEGER,
                equity        NUMBER(15,4),
                balance       NUMBER(15,4),
                win_count     INTEGER,
                loss_count    INTEGER
            )""",
            """CREATE TABLE IF NOT EXISTS signals_log (
                id            VARCHAR2(64)  PRIMARY KEY,
                symbol        VARCHAR2(20),
                action        VARCHAR2(10),
                confidence    NUMBER(5,4),
                entry_price   NUMBER(20,8),
                stop_loss     NUMBER(20,8),
                take_profit   NUMBER(20,8),
                risk_reward   NUMBER(8,4),
                regime        VARCHAR2(20),
                strategy      VARCHAR2(64),
                created_at    TIMESTAMP
            )""",
            """CREATE TABLE IF NOT EXISTS portfolio_snapshots (
                id            INTEGER       PRIMARY KEY,
                balance       NUMBER(15,4),
                equity        NUMBER(15,4),
                daily_pnl     NUMBER(15,4),
                daily_pnl_pct NUMBER(8,4),
                open_positions INTEGER,
                mode          VARCHAR2(20),
                snapshot_at   TIMESTAMP
            )""",
            """CREATE TABLE IF NOT EXISTS system_log (
                id            INTEGER       PRIMARY KEY,
                event_type    VARCHAR2(50),
                message       CLOB,
                logged_at     TIMESTAMP
            )""",
            """CREATE TABLE IF NOT EXISTS ml_metrics (
                symbol        VARCHAR2(20)  PRIMARY KEY,
                rf_accuracy   NUMBER(5,4),
                gb_accuracy   NUMBER(5,4),
                xgb_accuracy  NUMBER(5,4),
                samples       INTEGER,
                features      INTEGER,
                trained_at    TIMESTAMP
            )""",
        ]

        # SQLite uses INTEGER PRIMARY KEY autoincrement differently
        if self._use_sqlite:
            tables = [t.replace("VARCHAR2", "TEXT").replace("NUMBER", "REAL")
                       .replace("INTEGER       PRIMARY KEY",
                                "INTEGER PRIMARY KEY AUTOINCREMENT")
                       .replace("CLOB", "TEXT").replace("TIMESTAMP", "TEXT")
                       .replace("DATE", "TEXT")
                      for t in tables]

        with self._lock:
            cursor = self._conn.cursor()
            for ddl in tables:
                try:
                    cursor.execute(ddl)
                except Exception as e:
                    if "already exists" not in str(e).lower():
                        logger.error(f"Schema creation error: {e}")
            self._conn.commit()
            cursor.close()

    # ─────────────────────────────────────────────
    # CORE DB HELPERS
    # ─────────────────────────────────────────────

    def _execute(self, sql: str, params=None, fetch: bool = False):
        """Thread-safe SQL execution."""
        with self._lock:
            try:
                cursor = self._conn.cursor()
                cursor.execute(sql, params or [])
                if fetch:
                    rows = cursor.fetchall()
                    cursor.close()
                    return rows
                self._conn.commit()
                cursor.close()
                return True
            except Exception as e:
                logger.error(f"DB execute error: {e}\nSQL: {sql}\nParams: {params}")
                try:
                    self._conn.rollback()
                except Exception:
                    pass
                return None

    def _now(self) -> str:
        return datetime.now().isoformat()

    # ─────────────────────────────────────────────
    # POSITIONS
    # ─────────────────────────────────────────────

    def sync_position(self, position: Dict):
        """Upsert a live position."""
        sql = """
            MERGE INTO positions p
            USING (SELECT :1 AS id FROM dual) src ON (p.id = src.id)
            WHEN MATCHED THEN UPDATE SET
                current_price  = :2,
                unrealized_pnl = :3,
                stop_loss      = :4,
                take_profit    = :5,
                updated_at     = :6
            WHEN NOT MATCHED THEN INSERT
                (id, symbol, side, volume, entry_price, current_price,
                 stop_loss, take_profit, unrealized_pnl, opened_at, updated_at)
            VALUES (:7, :8, :9, :10, :11, :12, :13, :14, :15, :16, :17)
        """ if not self._use_sqlite else """
            INSERT INTO positions
                (id, symbol, side, volume, entry_price, current_price,
                 stop_loss, take_profit, unrealized_pnl, opened_at, updated_at)
            VALUES (?,?,?,?,?,?,?,?,?,?,?)
            ON CONFLICT(id) DO UPDATE SET
                current_price=excluded.current_price,
                unrealized_pnl=excluded.unrealized_pnl,
                stop_loss=excluded.stop_loss,
                take_profit=excluded.take_profit,
                updated_at=excluded.updated_at
        """
        now = self._now()
        pos_id = str(position.get("id", ""))

        if not self._use_sqlite:
            self._execute(sql, [
                pos_id,
                position.get("current_price"), position.get("unrealized_pnl"),
                position.get("stop_loss"), position.get("take_profit"), now,
                pos_id, position.get("symbol"), position.get("side"),
                position.get("volume"), position.get("entry_price"),
                position.get("current_price"), position.get("stop_loss"),
                position.get("take_profit"), position.get("unrealized_pnl"),
                position.get("opened_at", now), now,
            ])
        else:
            self._execute(sql, (
                pos_id, position.get("symbol"), position.get("side"),
                position.get("volume"), position.get("entry_price"),
                position.get("current_price"), position.get("stop_loss"),
                position.get("take_profit"), position.get("unrealized_pnl"),
                position.get("opened_at", now), now,
            ))

    def remove_position(self, position_id: str):
        """Delete a closed position."""
        ph = ":1" if not self._use_sqlite else "?"
        self._execute(f"DELETE FROM positions WHERE id = {ph}", [str(position_id)])

    def get_open_positions_db(self) -> List[Dict]:
        """Load open positions from DB."""
        rows = self._execute("SELECT * FROM positions", fetch=True)
        if not rows:
            return []
        return [dict(zip([d[0].lower() for d in rows[0].description
                          if hasattr(rows[0], 'description')], row))
                if hasattr(rows[0], 'description') else dict(row)
                for row in rows] if rows else []

    # ─────────────────────────────────────────────
    # TRADE HISTORY
    # ─────────────────────────────────────────────

    def record_trade(self, trade: Dict):
        """Insert a completed trade."""
        ph = lambda n: f":{n}" if not self._use_sqlite else "?"
        sql = f"""
            INSERT INTO trade_history
                (id, symbol, side, volume, entry_price, close_price,
                 profit, commission, swap, closed_at, comment, strategy, confidence)
            VALUES
                ({ph(1)},{ph(2)},{ph(3)},{ph(4)},{ph(5)},{ph(6)},
                 {ph(7)},{ph(8)},{ph(9)},{ph(10)},{ph(11)},{ph(12)},{ph(13)})
        """
        import uuid
        self._execute(sql, [
            trade.get("id", str(uuid.uuid4())[:8]),
            trade.get("symbol"), trade.get("side"),
            trade.get("volume"), trade.get("entry_price"),
            trade.get("close_price", trade.get("entry_price")),
            trade.get("profit", 0), trade.get("commission", 0),
            trade.get("swap", 0), trade.get("closed_at", self._now()),
            trade.get("comment", ""), trade.get("strategy", ""),
            trade.get("confidence", 0),
        ])

    def get_trade_history_db(self, days: int = 30) -> List[Dict]:
        """Get recent trade history from DB."""
        ph = ":1" if not self._use_sqlite else "?"
        if self._use_sqlite:
            sql = f"SELECT * FROM trade_history WHERE closed_at >= datetime('now', '-{days} days') ORDER BY closed_at DESC"
            rows = self._execute(sql, fetch=True)
        else:
            sql = f"SELECT * FROM trade_history WHERE closed_at >= SYSDATE - {ph} ORDER BY closed_at DESC"
            rows = self._execute(sql, [days], fetch=True)
        return [dict(row) for row in rows] if rows else []

    # ─────────────────────────────────────────────
    # DAILY P&L
    # ─────────────────────────────────────────────

    def update_daily_pnl(self, pnl_data: Dict):
        """Upsert today's P&L record."""
        today = date.today().isoformat()
        if self._use_sqlite:
            sql = """
                INSERT INTO daily_pnl
                    (trade_date, pnl, pnl_pct, trades_count, equity, balance, win_count, loss_count)
                VALUES (?,?,?,?,?,?,?,?)
                ON CONFLICT(trade_date) DO UPDATE SET
                    pnl=excluded.pnl, pnl_pct=excluded.pnl_pct,
                    trades_count=excluded.trades_count, equity=excluded.equity,
                    balance=excluded.balance, win_count=excluded.win_count,
                    loss_count=excluded.loss_count
            """
        else:
            sql = """
                MERGE INTO daily_pnl d
                USING (SELECT :1 AS td FROM dual) src ON (d.trade_date = TO_DATE(src.td,'YYYY-MM-DD'))
                WHEN MATCHED THEN UPDATE SET
                    pnl=:2, pnl_pct=:3, trades_count=:4, equity=:5, balance=:6
                WHEN NOT MATCHED THEN INSERT
                    (trade_date, pnl, pnl_pct, trades_count, equity, balance, win_count, loss_count)
                VALUES (TO_DATE(:7,'YYYY-MM-DD'),:8,:9,:10,:11,:12,:13,:14)
            """
        self._execute(sql, [
            today,
            pnl_data.get("pnl", 0), pnl_data.get("pnl_pct", 0),
            pnl_data.get("trades_count", 0), pnl_data.get("equity", 0),
            pnl_data.get("balance", 0),
            pnl_data.get("win_count", 0), pnl_data.get("loss_count", 0),
        ])

    def get_daily_pnl_history(self, days: int = 30) -> List[Dict]:
        """Get P&L history for the last N days."""
        if self._use_sqlite:
            sql = f"SELECT * FROM daily_pnl ORDER BY trade_date DESC LIMIT {days}"
            rows = self._execute(sql, fetch=True)
        else:
            sql = "SELECT * FROM daily_pnl WHERE trade_date >= SYSDATE - :1 ORDER BY trade_date DESC"
            rows = self._execute(sql, [days], fetch=True)
        return [dict(row) for row in rows] if rows else []

    # ─────────────────────────────────────────────
    # SIGNALS
    # ─────────────────────────────────────────────

    def log_signal(self, signal):
        """Log an ML signal."""
        import uuid
        ph = lambda n: f":{n}" if not self._use_sqlite else "?"
        sql = f"""
            INSERT INTO signals_log
                (id, symbol, action, confidence, entry_price, stop_loss,
                 take_profit, risk_reward, regime, strategy, created_at)
            VALUES ({ph(1)},{ph(2)},{ph(3)},{ph(4)},{ph(5)},{ph(6)},
                    {ph(7)},{ph(8)},{ph(9)},{ph(10)},{ph(11)})
        """
        self._execute(sql, [
            str(uuid.uuid4())[:16],
            signal.symbol, signal.action, signal.confidence,
            signal.entry_price, signal.stop_loss, signal.take_profit,
            signal.risk_reward, signal.regime, signal.strategy_used,
            signal.timestamp.isoformat(),
        ])

    # ─────────────────────────────────────────────
    # PORTFOLIO SNAPSHOTS
    # ─────────────────────────────────────────────

    def update_portfolio_snapshot(self, snapshot: Dict):
        """Insert a portfolio snapshot."""
        ph = lambda n: f":{n}" if not self._use_sqlite else "?"
        seq = "apex_seq.NEXTVAL" if not self._use_sqlite else "NULL"
        sql = f"""
            INSERT INTO portfolio_snapshots
                (id, balance, equity, daily_pnl, daily_pnl_pct, open_positions, mode, snapshot_at)
            VALUES ({seq},{ph(1)},{ph(2)},{ph(3)},{ph(4)},{ph(5)},{ph(6)},{ph(7)})
        """
        self._execute(sql, [
            snapshot.get("balance", 0), snapshot.get("equity", 0),
            snapshot.get("daily_pnl", 0), snapshot.get("daily_pnl_pct", 0),
            snapshot.get("open_positions", 0), snapshot.get("mode", "paper"),
            self._now(),
        ])

    # ─────────────────────────────────────────────
    # SYSTEM LOG
    # ─────────────────────────────────────────────

    def log_system_event(self, event_type: str, message: str):
        """Log a system event."""
        ph = lambda n: f":{n}" if not self._use_sqlite else "?"
        seq = "apex_syslog_seq.NEXTVAL" if not self._use_sqlite else "NULL"
        sql = f"""
            INSERT INTO system_log (id, event_type, message, logged_at)
            VALUES ({seq},{ph(1)},{ph(2)},{ph(3)})
        """
        self._execute(sql, [event_type, str(message)[:4000], self._now()])

    # ─────────────────────────────────────────────
    # ML METRICS
    # ─────────────────────────────────────────────

    def update_ml_metrics(self, symbol: str, metrics: Dict):
        """Upsert ML model performance metrics."""
        if self._use_sqlite:
            sql = """
                INSERT INTO ml_metrics
                    (symbol, rf_accuracy, gb_accuracy, xgb_accuracy, samples, features, trained_at)
                VALUES (?,?,?,?,?,?,?)
                ON CONFLICT(symbol) DO UPDATE SET
                    rf_accuracy=excluded.rf_accuracy,
                    gb_accuracy=excluded.gb_accuracy,
                    xgb_accuracy=excluded.xgb_accuracy,
                    samples=excluded.samples, trained_at=excluded.trained_at
            """
        else:
            sql = """
                MERGE INTO ml_metrics m USING (SELECT :1 AS sym FROM dual) src ON (m.symbol=src.sym)
                WHEN MATCHED THEN UPDATE SET
                    rf_accuracy=:2, gb_accuracy=:3, xgb_accuracy=:4,
                    samples=:5, trained_at=:6
                WHEN NOT MATCHED THEN INSERT
                    (symbol, rf_accuracy, gb_accuracy, xgb_accuracy, samples, features, trained_at)
                VALUES (:7,:8,:9,:10,:11,:12,:13)
            """
        self._execute(sql, [
            symbol,
            metrics.get("rf_cv_accuracy", 0), metrics.get("gb_cv_accuracy", 0),
            metrics.get("xgb_cv_accuracy", 0), metrics.get("samples", 0),
            self._now(),
            symbol,
            metrics.get("rf_cv_accuracy", 0), metrics.get("gb_cv_accuracy", 0),
            metrics.get("xgb_cv_accuracy", 0), metrics.get("samples", 0),
            metrics.get("features", 0), self._now(),
        ] if not self._use_sqlite else [
            symbol,
            metrics.get("rf_cv_accuracy", 0), metrics.get("gb_cv_accuracy", 0),
            metrics.get("xgb_cv_accuracy", 0), metrics.get("samples", 0),
            metrics.get("features", 0), self._now(),
        ])

    # ─────────────────────────────────────────────
    # REPORTS
    # ─────────────────────────────────────────────

    def save_daily_report(self, date_str: str, report: Dict):
        """Save daily report data (stores as JSON in system_log)."""
        self.log_system_event("daily_report", json.dumps(report, default=str))

    def set_value(self, key: str, value: Any):
        """Generic key-value store — logs to system_log."""
        self.log_system_event(f"kv:{key}", json.dumps(value, default=str))

    def close(self):
        """Close the database connection."""
        if self._conn:
            try:
                self._conn.close()
                logger.info("Database connection closed")
            except Exception:
                pass
