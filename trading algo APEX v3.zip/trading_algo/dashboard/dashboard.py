"""
APEX TRADING SYSTEM - Trading Terminal Dashboard v3
=====================================================
Professional Bloomberg-terminal layout. Clean grid, no clutter.

Layout:
┌──────────────────────────────────────────────────────────────┐
│  HEADER: Logo | Status Pill | Mode | Time | Pause | Halt     │
├──────────────────────────────────────────────────────────────┤
│  KPI STRIP: Equity | P&L | Positions | Trades | Signals | WR │
├───────────────┬──────────────────────────┬───────────────────┤
│  LEFT         │  CENTER                  │  RIGHT            │
│  Markets &    │  Open Positions          │  ML Signals       │
│  Live Prices  │  ───────────────────     │  ───────────────  │
│  w/ signals   │  Trade History Today     │  System Log       │
└───────────────┴──────────────────────────┴───────────────────┘
│  STATUS BAR                                                   │
└──────────────────────────────────────────────────────────────┘
"""

import sys
import math
import time as _time
import threading
from datetime import datetime
from typing import Dict, List, Optional

from PyQt6.QtWidgets import (
    QApplication, QMainWindow, QWidget, QVBoxLayout, QHBoxLayout,
    QLabel, QPushButton, QTableWidget, QTableWidgetItem,
    QHeaderView, QFrame, QSplitter, QTextEdit,
    QComboBox, QScrollArea, QProgressBar
)
from PyQt6.QtCore import Qt, QTimer, QThread, pyqtSignal
from PyQt6.QtGui import QColor, QFont


# ─────────────────────────────────────────────
# DESIGN TOKENS
# ─────────────────────────────────────────────
C = {
    "bg0":     "#05080F",
    "bg1":     "#090D18",
    "bg2":     "#0D1220",
    "bg3":     "#111827",
    "hover":   "#1A2235",
    "border":  "#162033",
    "border2": "#1E3050",
    "blue":    "#1E90FF",
    "cyan":    "#00D4FF",
    "teal":    "#00C8A0",
    "green":   "#00E676",
    "red":     "#FF3D57",
    "amber":   "#FFB300",
    "white":   "#E8F0FE",
    "dim":     "#5A7090",
    "dimmer":  "#2A3A50",
    "buy":     "#00E676",
    "sell":    "#FF3D57",
    "hold":    "#FFB300",
}

GLOBAL_SS = f"""
* {{ font-family: 'Consolas', 'Courier New', monospace; color: {C['white']}; }}
QMainWindow, QWidget {{ background: {C['bg0']}; border: none; }}
QSplitter::handle {{ background: {C['border']}; }}
QScrollBar:vertical {{ background:{C['bg1']}; width:5px; border-radius:2px; }}
QScrollBar::handle:vertical {{ background:{C['border2']}; border-radius:2px; }}
QScrollBar::add-line, QScrollBar::sub-line {{ height:0; width:0; }}
"""

TABLE_SS = f"""
QTableWidget {{
    background:{C['bg1']}; alternate-background-color:{C['bg2']};
    gridline-color:{C['border']}; border:none; font-size:11px;
    selection-background-color:{C['hover']}; selection-color:{C['cyan']};
}}
QTableWidget::item {{ padding:5px 10px; border-bottom:1px solid {C['border']}; }}
QHeaderView::section {{
    background:{C['bg0']}; color:{C['dim']}; font-size:9px;
    letter-spacing:1.5px; font-weight:700; text-transform:uppercase;
    padding:7px 10px; border:none; border-bottom:1px solid {C['border2']};
}}
"""

BTN_SS = f"""
QPushButton {{
    background:{C['bg2']}; color:{C['dim']}; border:1px solid {C['border2']};
    border-radius:4px; padding:6px 14px; font-size:10px;
    font-weight:700; letter-spacing:1px;
}}
QPushButton:hover {{ background:{C['hover']}; border-color:{C['blue']}; color:{C['blue']}; }}
"""

HALT_SS = f"""
QPushButton {{
    background:{C['red']}18; color:{C['red']}; border:1px solid {C['red']}50;
    border-radius:4px; padding:6px 14px; font-size:10px; font-weight:800; letter-spacing:1px;
}}
QPushButton:hover {{ background:{C['red']}35; border-color:{C['red']}; }}
"""

COMBO_SS = f"""
QComboBox {{
    background:{C['bg2']}; border:1px solid {C['border2']}; border-radius:4px;
    padding:5px 10px; font-size:10px; font-weight:700; letter-spacing:1px; color:{C['white']};
}}
QComboBox::drop-down {{ border:none; width:0; }}
QComboBox QAbstractItemView {{ background:{C['bg2']}; border:1px solid {C['border2']};
    selection-background-color:{C['hover']}; }}
"""


# ─────────────────────────────────────────────
# HELPERS
# ─────────────────────────────────────────────

def lbl(text, size=11, color=None, bold=False, spacing=None):
    w = QLabel(text)
    s = f"font-size:{size}px; color:{color or C['white']};"
    if bold:   s += " font-weight:700;"
    if spacing: s += f" letter-spacing:{spacing};"
    w.setStyleSheet(s)
    return w

def sep(vertical=False):
    line = QFrame()
    line.setFrameShape(QFrame.Shape.VLine if vertical else QFrame.Shape.HLine)
    line.setStyleSheet(f"background:{C['border']}; max-{'width' if vertical else 'height'}:1px;")
    return line

def section_hdr(text):
    w = QLabel(text.upper())
    w.setFixedHeight(30)
    w.setStyleSheet(f"""
        color:{C['dim']}; font-size:9px; font-weight:800; letter-spacing:2px;
        padding:0 12px; border-bottom:1px solid {C['border']}; background:{C['bg0']};
    """)
    return w


# ─────────────────────────────────────────────
# KPI CARD
# ─────────────────────────────────────────────

class KpiCard(QFrame):
    def __init__(self, label, value="—", accent=None):
        super().__init__()
        self._accent = accent or C['cyan']
        self.setStyleSheet(f"""
            QFrame {{
                background:{C['bg1']}; border:1px solid {C['border']};
                border-top:2px solid {self._accent}; border-radius:4px;
            }}
        """)
        v = QVBoxLayout(self)
        v.setContentsMargins(14, 10, 14, 8)
        v.setSpacing(2)
        self._lbl = QLabel(label.upper())
        self._lbl.setStyleSheet(f"color:{C['dim']};font-size:8px;font-weight:800;letter-spacing:1.5px;")
        self._val = QLabel(value)
        self._val.setStyleSheet(f"color:{self._accent};font-size:20px;font-weight:900;")
        self._sub = QLabel("")
        self._sub.setStyleSheet(f"color:{C['dim']};font-size:10px;")
        v.addWidget(self._lbl)
        v.addWidget(self._val)
        v.addWidget(self._sub)

    def update(self, value, sub="", color=None):
        self._val.setText(value)
        self._sub.setText(sub)
        c = color or self._accent
        self._val.setStyleSheet(f"color:{c};font-size:20px;font-weight:900;")


# ─────────────────────────────────────────────
# MARKET ROW
# ─────────────────────────────────────────────

class MarketRow(QFrame):
    def __init__(self, symbol, name):
        super().__init__()
        self.symbol = symbol
        self.setFixedHeight(44)
        self.setStyleSheet(f"""
            QFrame {{ background:{C['bg1']}; border-bottom:1px solid {C['border']}; }}
            QFrame:hover {{ background:{C['hover']}; }}
        """)
        h = QHBoxLayout(self)
        h.setContentsMargins(12, 0, 12, 0)
        h.setSpacing(0)

        sym_lbl = QLabel(symbol)
        sym_lbl.setFixedWidth(76)
        sym_lbl.setStyleSheet(f"color:{C['cyan']};font-size:11px;font-weight:800;")
        h.addWidget(sym_lbl)

        name_lbl = QLabel(name[:16])
        name_lbl.setFixedWidth(115)
        name_lbl.setStyleSheet(f"color:{C['dim']};font-size:10px;")
        h.addWidget(name_lbl)

        h.addStretch()

        self._price = QLabel("———")
        self._price.setFixedWidth(88)
        self._price.setAlignment(Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignVCenter)
        self._price.setStyleSheet(f"color:{C['white']};font-size:12px;font-weight:700;")
        h.addWidget(self._price)

        self._chg = QLabel("")
        self._chg.setFixedWidth(68)
        self._chg.setAlignment(Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignVCenter)
        self._chg.setStyleSheet(f"color:{C['dim']};font-size:10px;")
        h.addWidget(self._chg)

        h.addSpacing(10)

        self._sig = QLabel("···")
        self._sig.setFixedWidth(52)
        self._sig.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self._sig.setStyleSheet(f"""
            background:{C['bg3']}; border:1px solid {C['border2']};
            border-radius:3px; color:{C['dimmer']};
            font-size:9px; font-weight:800; letter-spacing:1px; padding:2px 0;
        """)
        h.addWidget(self._sig)

        h.addSpacing(8)

        self._bar = QProgressBar()
        self._bar.setFixedSize(46, 4)
        self._bar.setTextVisible(False)
        self._bar.setValue(0)
        self._bar.setStyleSheet(f"""
            QProgressBar {{ background:{C['bg3']}; border-radius:2px; border:none; }}
            QProgressBar::chunk {{ background:{C['cyan']}; border-radius:2px; }}
        """)
        h.addWidget(self._bar)

    def set_price(self, price, chg_pct):
        self._price.setText(f"${price:,.3f}" if price < 10000 else f"${price:,.1f}")
        color = C['green'] if chg_pct >= 0 else C['red']
        sign  = "+" if chg_pct >= 0 else ""
        self._chg.setText(f"{sign}{chg_pct:.2f}%")
        self._chg.setStyleSheet(f"color:{color};font-size:10px;")

    def set_signal(self, action, confidence):
        c = {"BUY":C['buy'],"SELL":C['sell'],"HOLD":C['hold']}.get(action, C['dim'])
        self._sig.setText(action)
        self._sig.setStyleSheet(f"""
            background:{c}18; border:1px solid {c}60; border-radius:3px;
            color:{c}; font-size:9px; font-weight:800; letter-spacing:1px; padding:2px 0;
        """)
        self._bar.setValue(int(confidence * 100))
        self._bar.setStyleSheet(f"""
            QProgressBar {{ background:{C['bg3']}; border-radius:2px; border:none; }}
            QProgressBar::chunk {{ background:{c}; border-radius:2px; }}
        """)


# ─────────────────────────────────────────────
# DATA WORKER
# ─────────────────────────────────────────────

class DataWorker(QThread):
    tick = pyqtSignal(dict)
    err  = pyqtSignal(str)

    def __init__(self, engine=None):
        super().__init__()
        self.engine  = engine
        self._running = True
        self._cycle   = 0

    def run(self):
        import random
        while self._running:
            try:
                self._cycle += 1
                data = self.engine.get_dashboard_data() if self.engine else self._demo(random)
                self.tick.emit(data)
            except Exception as e:
                self.err.emit(str(e))
            self.msleep(2000)

    def _demo(self, rng) -> dict:
        t = _time.time()
        def wp(base, amp, per, seed):
            return base + amp * math.sin(t / per + seed) + rng.gauss(0, amp * 0.04)

        prices = {
            "XAUUSD": wp(2044,  6,   110, 1),
            "XAGUSD": wp(24.3,  0.2,  85, 2),
            "USOIL":  wp(78.9,  1.0, 130, 3),
            "UKOIL":  wp(82.4,  0.9, 120, 4),
            "NGAS":   wp(2.48,  0.07, 75, 5),
            "HEAT":   wp(2.81,  0.05, 95, 6),
            "RBOB":   wp(2.41,  0.04, 90, 7),
            "ETHUSD": wp(3200,  40,  200, 8),
            "CARBON": wp(65.0,  0.8, 160, 9),
        }

        acts = ["BUY","SELL","HOLD"]
        signals = {}
        for sym, price in prices.items():
            act  = rng.choices(acts, weights=[3,3,5])[0]
            conf = rng.uniform(0.63, 0.92) if act != "HOLD" else rng.uniform(0.40, 0.63)
            signals[sym] = {
                "action": act, "confidence": conf, "entry": price,
                "sl":  price * (0.982 if act=="BUY" else 1.018),
                "tp":  price * (1.030 if act=="BUY" else 0.970),
                "rr":  round(rng.uniform(1.8, 3.6), 2),
                "regime": rng.choice(["trending","ranging","volatile"]),
            }

        positions = [
            {"symbol":"USOIL",  "side":"buy",  "volume":0.50,
             "entry_price":77.85, "unrealized_pnl":(prices["USOIL"]-77.85)*50,
             "stop_loss":76.20,  "take_profit":80.50},
            {"symbol":"XAUUSD", "side":"buy",  "volume":0.10,
             "entry_price":2038.0,"unrealized_pnl":(prices["XAUUSD"]-2038.0)*10,
             "stop_loss":2025.0, "take_profit":2065.0},
        ]

        history = [
            {"symbol":"UKOIL", "side":"sell","volume":0.3,"profit": 87.30,"closed_at":"10:14"},
            {"symbol":"XAGUSD","side":"buy", "volume":0.5,"profit":-32.10,"closed_at":"10:52"},
            {"symbol":"USOIL", "side":"buy", "volume":0.4,"profit":124.80,"closed_at":"11:30"},
            {"symbol":"NGAS",  "side":"sell","volume":1.0,"profit": 43.20,"closed_at":"12:05"},
            {"symbol":"XAUUSD","side":"buy", "volume":0.2,"profit": 67.50,"closed_at":"13:20"},
            {"symbol":"RBOB",  "side":"sell","volume":0.3,"profit":-18.40,"closed_at":"14:11"},
            {"symbol":"HEAT",  "side":"buy", "volume":0.5,"profit": 91.30,"closed_at":"15:00"},
        ]

        total_upnl = sum(p["unrealized_pnl"] for p in positions)
        daily_pnl  = sum(t["profit"] for t in history) + total_upnl * 0.3
        wins       = len([t for t in history if t["profit"] > 0])

        return {
            "prices": prices, "signals": signals,
            "positions": positions, "history": history,
            "portfolio": {
                "balance":        10000.0,
                "equity":         10000.0 + daily_pnl,
                "daily_pnl":      daily_pnl,
                "daily_pnl_pct":  daily_pnl / 100,
                "open_positions": len(positions),
                "daily_trades":   len(history),
                "wins":           wins,
            },
            "status": {
                "mode":"paper","halted":False,"halt_reason":"",
                "cycle":self._cycle,"signals_gen":self._cycle*9,
                "trades_exec":len(history),"connected":False,
            }
        }

    def stop(self):
        self._running = False


# ─────────────────────────────────────────────
# MAIN WINDOW
# ─────────────────────────────────────────────

class ApexTerminal(QMainWindow):

    def __init__(self, engine=None):
        super().__init__()
        self.engine = engine
        self._prev_prices: Dict[str, float] = {}
        self._log_lines: List[str] = []

        self.setWindowTitle("⚡ APEX — Trading Terminal")
        self.setMinimumSize(1280, 780)
        self.resize(1600, 960)
        self.setStyleSheet(GLOBAL_SS)
        self._build_ui()
        self._start_worker()

        clock = QTimer(self)
        clock.timeout.connect(self._tick_clock)
        clock.start(1000)
        self._tick_clock()

    # ─────────────────────────────────────────────
    # BUILD UI
    # ─────────────────────────────────────────────

    def _build_ui(self):
        root = QWidget()
        self.setCentralWidget(root)
        v = QVBoxLayout(root)
        v.setSpacing(0)
        v.setContentsMargins(0, 0, 0, 0)
        v.addWidget(self._mk_header())
        v.addWidget(self._mk_kpi_strip())
        v.addWidget(sep(), 0)
        v.addWidget(self._mk_body(), 1)
        v.addWidget(self._mk_statusbar())

    # ── HEADER ────────────────────────────────────

    def _mk_header(self):
        w = QWidget()
        w.setFixedHeight(52)
        w.setStyleSheet(f"background:{C['bg0']};border-bottom:1px solid {C['border2']};")
        h = QHBoxLayout(w)
        h.setContentsMargins(16, 0, 16, 0)
        h.setSpacing(10)

        h.addWidget(lbl("⚡", 18, C['blue']))
        h.addWidget(lbl("APEX", 16, C['blue'], bold=True, spacing="4px"))
        h.addWidget(lbl("TRADING TERMINAL", 8, C['dimmer'], bold=True, spacing="3px"))
        h.addSpacing(16)

        self._pill = QLabel("  ● PAPER MODE  ")
        self._pill.setStyleSheet(f"""
            background:{C['amber']}18; border:1px solid {C['amber']}60;
            border-radius:10px; color:{C['amber']};
            font-size:9px; font-weight:800; letter-spacing:1px; padding:3px 10px;
        """)
        h.addWidget(self._pill)
        h.addStretch()

        h.addWidget(lbl("MODE", 8, C['dim'], bold=True, spacing="1.5px"))
        self._mode = QComboBox()
        self._mode.addItems(["📝  PAPER", "⚡  LIVE"])
        self._mode.setStyleSheet(COMBO_SS)
        self._mode.currentTextChanged.connect(self._on_mode)
        h.addWidget(self._mode)

        h.addSpacing(8)

        self._pause_btn = QPushButton("⏸  PAUSE")
        self._pause_btn.setStyleSheet(BTN_SS)
        self._pause_btn.clicked.connect(self._toggle_pause)
        h.addWidget(self._pause_btn)

        halt = QPushButton("⛔  HALT")
        halt.setStyleSheet(HALT_SS)
        halt.clicked.connect(self._halt)
        h.addWidget(halt)

        h.addSpacing(14)
        self._clock_lbl = lbl("00:00:00", 13, C['dim'], bold=True)
        self._clock_lbl.setMinimumWidth(72)
        h.addWidget(self._clock_lbl)
        return w

    # ── KPI STRIP ────────────────────────────────

    def _mk_kpi_strip(self):
        w = QWidget()
        w.setFixedHeight(92)
        w.setStyleSheet(f"background:{C['bg0']};border-bottom:1px solid {C['border']};")
        h = QHBoxLayout(w)
        h.setContentsMargins(12, 8, 12, 8)
        h.setSpacing(8)

        self._kpi_eq   = KpiCard("Account Equity", "$——,———", C['cyan'])
        self._kpi_pnl  = KpiCard("Today's P&L",    "$0.00",   C['green'])
        self._kpi_pos  = KpiCard("Open Positions",  "0",       C['amber'])
        self._kpi_tr   = KpiCard("Trades Today",    "0",       C['blue'])
        self._kpi_sig  = KpiCard("Signals",         "0",       C['teal'])
        self._kpi_wr   = KpiCard("Win Rate",        "—%",      C['white'])

        for card in [self._kpi_eq, self._kpi_pnl, self._kpi_pos,
                     self._kpi_tr, self._kpi_sig, self._kpi_wr]:
            h.addWidget(card, 1)
        return w

    # ── BODY ──────────────────────────────────────

    def _mk_body(self):
        splitter = QSplitter(Qt.Orientation.Horizontal)
        splitter.setHandleWidth(1)
        splitter.addWidget(self._mk_left())
        splitter.addWidget(self._mk_center())
        splitter.addWidget(self._mk_right())
        splitter.setSizes([320, 720, 360])
        return splitter

    def _mk_left(self):
        w = QWidget()
        w.setStyleSheet(f"background:{C['bg1']};border-right:1px solid {C['border']};")
        v = QVBoxLayout(w)
        v.setSpacing(0)
        v.setContentsMargins(0, 0, 0, 0)
        v.addWidget(section_hdr("Markets & Live Prices"))

        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setFrameShape(QScrollArea.Shape.NoFrame)
        scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        scroll.setStyleSheet("background:transparent;border:none;")

        inner = QWidget()
        inner.setStyleSheet("background:transparent;")
        iv = QVBoxLayout(inner)
        iv.setSpacing(0)
        iv.setContentsMargins(0, 0, 0, 0)

        from config.config import ALL_MARKETS
        self._rows: Dict[str, MarketRow] = {}
        for sym, info in ALL_MARKETS.items():
            row = MarketRow(sym, info["name"])
            self._rows[sym] = row
            iv.addWidget(row)
        iv.addStretch()

        scroll.setWidget(inner)
        v.addWidget(scroll, 1)
        return w

    def _mk_center(self):
        w = QWidget()
        w.setStyleSheet(f"background:{C['bg1']};")
        v = QVBoxLayout(w)
        v.setSpacing(0)
        v.setContentsMargins(0, 0, 0, 0)

        v.addWidget(section_hdr("Open Positions"))
        self._pos_tbl = self._mk_table(
            ["Symbol","Side","Vol","Entry","Current","Unrealized P&L","Stop Loss","Take Profit"]
        )
        v.addWidget(self._pos_tbl, 2)

        v.addWidget(sep())
        v.addWidget(section_hdr("Trade History — Today"))
        self._hist_tbl = self._mk_table(["Symbol","Side","Volume","Profit / Loss","Closed"])
        v.addWidget(self._hist_tbl, 3)
        return w

    def _mk_right(self):
        w = QWidget()
        w.setStyleSheet(f"background:{C['bg1']};border-left:1px solid {C['border']};")
        v = QVBoxLayout(w)
        v.setSpacing(0)
        v.setContentsMargins(0, 0, 0, 0)

        v.addWidget(section_hdr("ML Signal Engine"))
        self._sig_tbl = self._mk_table(["Symbol","Signal","Confidence","R:R","Regime"])
        v.addWidget(self._sig_tbl, 2)

        v.addWidget(sep())

        # Log header
        lh = QWidget()
        lh.setFixedHeight(30)
        lh.setStyleSheet(f"background:{C['bg0']};border-bottom:1px solid {C['border']};")
        lhh = QHBoxLayout(lh)
        lhh.setContentsMargins(12, 0, 12, 0)
        lhh.addWidget(lbl("System Log", 9, C['dim'], bold=True, spacing="2px"))
        lhh.addStretch()
        clr = QPushButton("CLEAR")
        clr.setFixedHeight(20)
        clr.setStyleSheet(BTN_SS + "QPushButton{padding:2px 8px;font-size:8px;}")
        clr.clicked.connect(lambda: (self._log_lines.clear(), self._log_box.clear()))
        lhh.addWidget(clr)
        v.addWidget(lh)

        self._log_box = QTextEdit()
        self._log_box.setReadOnly(True)
        self._log_box.setStyleSheet(f"""
            background:{C['bg1']}; color:{C['dim']};
            border:none; font-size:10px; padding:8px; line-height:1.6;
        """)
        v.addWidget(self._log_box, 3)
        return w

    def _mk_statusbar(self):
        w = QWidget()
        w.setFixedHeight(24)
        w.setStyleSheet(f"background:{C['bg0']};border-top:1px solid {C['border']};")
        h = QHBoxLayout(w)
        h.setContentsMargins(12, 0, 12, 0)
        h.setSpacing(20)
        self._st_left  = lbl("Initializing...", 9, C['dim'])
        self._st_right = lbl("MT5 Python API  ·  Oracle DB", 9, C['dim'])
        self._st_right.setAlignment(Qt.AlignmentFlag.AlignRight)
        h.addWidget(self._st_left, 1)
        h.addWidget(self._st_right)
        return w

    # ─────────────────────────────────────────────
    # TABLE FACTORY
    # ─────────────────────────────────────────────

    def _mk_table(self, headers):
        t = QTableWidget()
        t.setColumnCount(len(headers))
        t.setHorizontalHeaderLabels(headers)
        t.setStyleSheet(TABLE_SS)
        t.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.Stretch)
        t.verticalHeader().setVisible(False)
        t.setAlternatingRowColors(True)
        t.setEditTriggers(QTableWidget.EditTrigger.NoEditTriggers)
        t.setSelectionBehavior(QTableWidget.SelectionBehavior.SelectRows)
        t.setSelectionMode(QTableWidget.SelectionMode.SingleSelection)
        t.setShowGrid(False)
        t.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        t.verticalHeader().setDefaultSectionSize(36)
        return t

    def _cell(self, text, color=None, align=Qt.AlignmentFlag.AlignCenter, bold=False):
        item = QTableWidgetItem(str(text))
        item.setTextAlignment(align | Qt.AlignmentFlag.AlignVCenter)
        item.setForeground(QColor(color or C['white']))
        if bold:
            f = item.font(); f.setBold(True); item.setFont(f)
        return item

    # ─────────────────────────────────────────────
    # WORKER
    # ─────────────────────────────────────────────

    def _start_worker(self):
        self._worker = DataWorker(self.engine)
        self._worker.tick.connect(self._on_data)
        self._worker.err.connect(lambda e: self._log(f"[ERR] {e}", C['red']))
        self._worker.start()

    # ─────────────────────────────────────────────
    # DATA UPDATES
    # ─────────────────────────────────────────────

    def _on_data(self, data):
        p  = data.get("portfolio", {})
        st = data.get("status", {})

        self._upd_kpis(p, data.get("history", []))
        self._upd_markets(data.get("prices", {}), data.get("signals", {}))
        self._upd_positions(data.get("positions", []), data.get("prices", {}))
        self._upd_history(data.get("history", []))
        self._upd_signals(data.get("signals", {}))
        self._upd_pill(st)
        self._upd_statusbar(p, st)

    def _upd_kpis(self, p, history):
        eq   = p.get("equity", 0)
        pnl  = p.get("daily_pnl", 0)
        ppct = p.get("daily_pnl_pct", 0)
        sign = "+" if pnl >= 0 else ""
        pc   = C['green'] if pnl >= 0 else C['red']
        wins = len([t for t in history if t.get("profit",0) > 0])
        wr   = wins / max(len(history), 1) * 100

        self._kpi_eq.update(f"${eq:,.2f}")
        self._kpi_pnl.update(f"{sign}${abs(pnl):,.2f}", f"{sign}{ppct:.2f}%", pc)
        self._kpi_pos.update(str(p.get("open_positions", 0)))
        self._kpi_tr.update(str(p.get("daily_trades", len(history))))
        self._kpi_sig.update(str(p.get("signals_gen", 0)))
        self._kpi_wr.update(f"{wr:.0f}%", color=C['green'] if wr >= 50 else C['red'])

    def _upd_markets(self, prices, signals):
        for sym, row in self._rows.items():
            price = prices.get(sym)
            if price:
                prev = self._prev_prices.get(sym, price)
                chg  = ((price - prev) / prev * 100) if prev else 0
                row.set_price(price, chg)
                self._prev_prices[sym] = price
            sig = signals.get(sym)
            if sig:
                row.set_signal(sig["action"], sig["confidence"])

    def _upd_positions(self, positions, prices):
        self._pos_tbl.setRowCount(len(positions))
        for i, p in enumerate(positions):
            upnl  = p.get("unrealized_pnl", 0)
            side  = p.get("side","").upper()
            pc    = C['green'] if upnl >= 0 else C['red']
            sc    = C['buy'] if side == "BUY" else C['sell']
            cur   = prices.get(p.get("symbol",""), p.get("entry_price", 0))
            L = Qt.AlignmentFlag.AlignLeft

            self._pos_tbl.setItem(i, 0, self._cell(p.get("symbol",""), C['cyan'], bold=True))
            self._pos_tbl.setItem(i, 1, self._cell(side, sc, bold=True))
            self._pos_tbl.setItem(i, 2, self._cell(str(p.get("volume",""))))
            self._pos_tbl.setItem(i, 3, self._cell(f"${p.get('entry_price',0):.4f}"))
            self._pos_tbl.setItem(i, 4, self._cell(f"${cur:.4f}"))
            self._pos_tbl.setItem(i, 5, self._cell(f"${upnl:+,.2f}", pc, bold=True))
            self._pos_tbl.setItem(i, 6, self._cell(f"${p.get('stop_loss',0):.4f}", C['red']))
            self._pos_tbl.setItem(i, 7, self._cell(f"${p.get('take_profit',0):.4f}", C['green']))

    def _upd_history(self, history):
        self._hist_tbl.setRowCount(len(history))
        L = Qt.AlignmentFlag.AlignLeft
        for i, t in enumerate(reversed(history)):
            profit = t.get("profit", 0)
            side   = t.get("side","").upper()
            pc = C['green'] if profit >= 0 else C['red']
            sc = C['buy'] if side=="BUY" else C['sell']
            self._hist_tbl.setItem(i, 0, self._cell(t.get("symbol",""), C['cyan']))
            self._hist_tbl.setItem(i, 1, self._cell(side, sc))
            self._hist_tbl.setItem(i, 2, self._cell(str(t.get("volume",""))))
            self._hist_tbl.setItem(i, 3, self._cell(f"${profit:+,.2f}", pc, bold=True))
            self._hist_tbl.setItem(i, 4, self._cell(str(t.get("closed_at",""))[:16], C['dim'], align=L))

    def _upd_signals(self, signals):
        items = list(signals.items())
        self._sig_tbl.setRowCount(len(items))
        for i, (sym, sig) in enumerate(items):
            act    = sig.get("action","HOLD")
            conf   = sig.get("confidence", 0)
            rr     = sig.get("rr", 0)
            regime = sig.get("regime","—")
            ac = {"BUY":C['buy'],"SELL":C['sell'],"HOLD":C['hold']}.get(act, C['dim'])
            rc = {"trending":C['green'],"volatile":C['red'],"ranging":C['amber']}.get(regime, C['dim'])
            L  = Qt.AlignmentFlag.AlignLeft

            self._sig_tbl.setItem(i, 0, self._cell(sym, C['cyan'], bold=True))
            self._sig_tbl.setItem(i, 1, self._cell(act, ac, bold=True))
            self._sig_tbl.setItem(i, 2, self._cell(f"{conf:.0%}", C['blue']))
            self._sig_tbl.setItem(i, 3, self._cell(f"{rr:.1f}x", C['teal']))
            self._sig_tbl.setItem(i, 4, self._cell(regime.upper(), rc, align=L))

    def _upd_pill(self, st):
        halted    = st.get("halted", False)
        connected = st.get("connected", False)
        mode      = st.get("mode","paper").upper()

        if halted:
            txt = "  ⛔ TRADING HALTED  "
            col = C['red']
        elif connected:
            txt = "  ● MT5 CONNECTED  "
            col = C['green']
        else:
            txt = f"  ● {mode} MODE  "
            col = C['amber']

        self._pill.setText(txt)
        self._pill.setStyleSheet(f"""
            background:{col}18; border:1px solid {col}60; border-radius:10px;
            color:{col}; font-size:9px; font-weight:800; letter-spacing:1px; padding:3px 10px;
        """)

    def _upd_statusbar(self, p, st):
        eq   = p.get("equity", 0)
        pnl  = p.get("daily_pnl", 0)
        sign = "+" if pnl >= 0 else ""
        ts   = datetime.now().strftime("%H:%M:%S")
        self._st_left.setText(
            f"Cycle #{st.get('cycle',0)}  ·  "
            f"Signals: {st.get('signals_gen',0)}  ·  "
            f"Executed: {st.get('trades_exec',0)}  ·  "
            f"Equity: ${eq:,.2f}  ·  P&L: {sign}${abs(pnl):.2f}  ·  {ts}"
        )
        self._log(
            f"Equity <b style='color:{C['cyan']}'>${eq:,.2f}</b>  "
            f"P&L <b style='color:{C['green'] if pnl>=0 else C['red']}'>{sign}${abs(pnl):.2f}</b>",
            inline=True
        )

    # ─────────────────────────────────────────────
    # LOG
    # ─────────────────────────────────────────────

    def _log(self, msg, color=None, inline=False):
        ts = datetime.now().strftime("%H:%M:%S")
        if inline:
            line = (f"<span style='color:{C['dimmer']}'>[{ts}]</span> "
                    f"<span style='color:{C['dim']}'>{msg}</span>")
        else:
            line = (f"<span style='color:{C['dimmer']}'>[{ts}]</span> "
                    f"<span style='color:{color or C['dim']}'>{msg}</span>")
        self._log_lines.insert(0, line)
        self._log_lines = self._log_lines[:200]
        self._log_box.setHtml("<br>".join(self._log_lines[:80]))

    # ─────────────────────────────────────────────
    # CONTROLS
    # ─────────────────────────────────────────────

    def _tick_clock(self):
        self._clock_lbl.setText(datetime.now().strftime("%H:%M:%S"))

    def _toggle_pause(self):
        if self.engine:
            if self.engine.paused:
                self.engine.resume()
                self._pause_btn.setText("⏸  PAUSE")
            else:
                self.engine.pause()
                self._pause_btn.setText("▶  RESUME")

    def _halt(self):
        if self.engine:
            self.engine.risk._halt_trading("Manual halt — dashboard")
        self._log("Emergency halt triggered", C['red'])

    def _on_mode(self, text):
        mode = "live" if "LIVE" in text else "paper"
        if self.engine:
            self.engine.set_mode(mode)
        self._log(f"Mode switched to {mode.upper()}", C['amber'])

    def closeEvent(self, event):
        if self._worker:
            self._worker.stop()
            self._worker.wait(2000)
        if self.engine:
            self.engine.stop()
        event.accept()


# ─────────────────────────────────────────────
# LAUNCH
# ─────────────────────────────────────────────

def launch_dashboard(engine=None):
    app = QApplication.instance() or QApplication(sys.argv)
    app.setApplicationName("APEX Trading Terminal")
    win = ApexTerminal(engine=engine)
    win.show()
    sys.exit(app.exec())


if __name__ == "__main__":
    launch_dashboard()
