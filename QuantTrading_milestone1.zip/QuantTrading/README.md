# QuantTrading - milestone 1: historical data foundation

Version 0.1.0. Research only. There is no strategy, backtest, broker connection,
order-submission function, or live-trading switch in this project.

The first increment is deliberately small:

    request daily bars -> preserve provider output -> normalize -> validate
        -> save an auditable snapshot -> plot adjusted-close movements

## Verification status

The offline test suite passed 56 tests on Python 3.13.5. Tests use explicitly
synthetic prices and mock the provider. They cover normalization, validation,
provider-call options, bounded retries, rate-limit handling, CSV persistence,
checksums, chart creation, and all-or-nothing run status.

A real Yahoo download has NOT been verified in the authoring environment.
Dependency installation failed because the environment could not resolve the
package host; a direct connectivity check also failed. No invented observations
are supplied as real market history. See `docs/offline-test-results.txt` and
`docs/verification.json`. The first real download must run on your computer.

## 1. Open the project in VS Code

Extract the archive. Open the `QuantTrading` folder itself in VS Code: it contains
`pyproject.toml`, `src/`, and `tests/`. Install Microsoft's Python extension in
VS Code and use **Python: Select Interpreter** to choose this project's `.venv`.

Use Python 3.13 for the closest match to the tested environment, preferably the
current maintenance release. This project's declared minimum is Python 3.12;
other interpreter versions were not tested here. You also need Git for version
control and an internet connection for package installation and data retrieval.

### Windows PowerShell

Run these commands in the VS Code terminal, in the project root:

```powershell
py -3.13 -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
python -m pip install -e ".[dev]"
python -m pytest -q
```

If PowerShell blocks the activation script, activation is optional. Run the
virtual environment's Python directly rather than relaxing system-wide policy:

```powershell
.\.venv\Scripts\python.exe -m pip install --upgrade pip
.\.venv\Scripts\python.exe -m pip install -e ".[dev]"
.\.venv\Scripts\python.exe -m pytest -q
```

Use that same interpreter path in place of `python` for subsequent commands.

### macOS / Linux

```bash
python3.13 -m venv .venv
source .venv/bin/activate
python -m pip install --upgrade pip
python -m pip install -e ".[dev]"
python -m pytest -q
```

On a Linux distribution that does not include `venv`, install the virtual-
environment package matching your Python version through that distribution's
package manager. Do not use `sudo pip` or install project dependencies globally.

`pip install -e` installs this local project in editable mode: edits in `src/`
are immediately used. `.[dev]` includes the pytest test dependency. Dependency
ranges are compatibility bounds, NOT a fully locked environment. After a
successful installation and first real download, record exact resolved versions:

```bash
python -m pip freeze --exclude-editable > requirements-lock.txt
```

Commit this lock snapshot with the code. Re-run tests before accepting dependency
updates. On a second installation, install that file with
`python -m pip install -r requirements-lock.txt`, then install the local project
with `python -m pip install --no-deps -e .`. Excluding editable packages avoids
recording a machine-specific source path. Regenerate the snapshot when changing
platform or Python version if necessary.

## 2. Run the first real download

First exercise one symbol over a short, fully historical interval:

```bash
python -m quanttrading --symbols SPY --start 2024-01-01 --end 2024-02-01
```

Then run the four-instrument development dataset:

```bash
python -m quanttrading --symbols SPY QQQ AAPL MSFT --start 2020-01-01 --end 2026-01-01
```

Running `python -m quanttrading` alone uses that same four-symbol, 2020-through-
2025 configuration. `--end` is **exclusive**. The default end does not include
1 January 2026. It does include eligible trading sessions through 31 December
2025. The initial window is for engineering checks, not a final research sample.

Today is deliberately excluded even after the close. A later increment can
introduce an explicit completed-session/publication-delay rule. Do not substitute
today's partially formed daily candle into historical research.

The CLI accepts only SPY, QQQ, AAPL and MSFT. Adding another instrument requires
an explicit configuration entry, including its calendar, currency and type.
The choice is a development sample, not a recommended investment portfolio or a
survivorship-bias-free stock universe.

## 3. Inspect the output

Each invocation creates a new directory rather than overwriting a previous run:

```text
data/runs/<UTC-timestamp>_<run-id>/
    manifest.json
    run.log
    price_comparison.png             # only if every requested symbol passes
    SPY/
        provider_output.csv          # yfinance's returned table, NOT raw exchange data
        metadata.json
        quality.json
        validated.csv                # only if this symbol passes structural checks
    QQQ/ ...
    AAPL/ ...
    MSFT/ ...
```

For a successful short SPY request, expected console messages include:

```text
INFO Retrieving SPY [2024-01-01, 2024-02-01)
INFO SPY: <row count> rows; structural checks passed.
Run saved to: <absolute run path>
Structural checks passed. Review warnings and independently compare prices before research.
Chart: <absolute chart path>
```

These are output templates, not a claimed live-run transcript. The real row count
must agree with the exchange-calendar check, not a hardcoded weekday count.

Open `manifest.json` first. `status` must be `structural_pass` or
`structural_pass_review_required`; investigate every warning in the latter case.
A `failed` or unfinished `in_progress` run is NOT an accepted dataset, even when
some individual symbols have a `validated.csv` file. Failed downloads also leave
`failure.json` where possible. Fatal failures return exit code 1; invalid initial
arguments return exit code 2. Nothing in this project can submit an order.

Open `price_comparison.png` in VS Code. The chart is:

    index[t] = 100 * adjusted_close[t] / adjusted_close[first_session]

All series use the same first session. The chart shows relative vendor-adjusted
price paths. It does not show strategy performance, executable fills, a portfolio,
a tradable edge, trading costs, or GBP-converted account returns.

## 4. What each file does

| File | Purpose |
| --- | --- |
| `src/quanttrading/config.py` | Small instrument registry, default dates, date-range checks. |
| `src/quanttrading/market_data.py` | Only Yahoo-dependent code; bounded download retries and a provider-to-project schema conversion. |
| `src/quanttrading/validation.py` | Checks metadata, dates, completeness, OHLC relationships, values and anomaly warnings. |
| `src/quanttrading/pipeline.py` | Coordinates retrieval, saves per-run snapshots and audit information, and blocks incomplete comparison charts. |
| `src/quanttrading/plotting.py` | Draws one diagnostic adjusted-close chart without filling missing observations. |
| `src/quanttrading/__main__.py` | Parses terminal arguments and prints results/errors. |
| `tests/` | Synthetic, deterministic unit and integration tests; no network required by the tests themselves. |
| `pyproject.toml` | One source of truth for package metadata, direct dependencies and pytest configuration. |

Read the files in this order: `config.py`, `market_data.py`, `validation.py`,
`pipeline.py`, then `plotting.py` and `__main__.py`. Make one change at a time and
run the tests after each change. No SciPy or backtesting library is needed until
there is an actual statistical or simulation task for it.

## 5. Data semantics and acceptance criteria

The normalized key is `(symbol, date)`. `date` is an exchange-local session label,
not an information-availability timestamp and not a UTC trade timestamp.

Required columns are:

```text
symbol,date,open,high,low,close,adj_close,volume,dividends,stock_splits
```

`capital_gains` is also preserved when returned by the provider. Its absence is
not silently replaced with a claim of zero distributions. All provider columns
remain in `provider_output.csv` and are named in `metadata.json`.

OHLC prices retain Yahoo's supplied basis. `auto_adjust=False` prevents yfinance
from automatically replacing OHLC with dividend-adjusted values; it does NOT
recover original pre-split as-traded history. Keep the separate `adj_close`
column. Do not use the raw-labelled snapshot or `close` as certified historical
execution prices. Do not add dividends to a return series that already embeds
dividend adjustments. A future backtest must define a consistent corporate-
action, share-count, cash and execution-price model first.

A structural pass requires the required columns, non-null finite values,
positive prices, sensible OHLC ordering, non-negative whole-share volume,
non-negative action values, unique sorted session keys, expected USD/type/
timezone metadata, and exact calendar coverage for the requested period.
Missing sessions are not forward-filled or dropped. This strict completeness
rule is intentionally limited to the four established instruments; it is not
an IPO, delisting, suspension or historical-universe eligibility model.

Zero-volume sessions and absolute daily adjusted-close changes above 25% produce
review warnings, not deletions or automatic repair. The 25% threshold is an
engineering attention flag, not a statistical trading threshold.

Calendar schedules come from `exchange_calendars`. ARCX and XNAS currently
resolve to its XNYS calendar for the daily sessions used here; both the requested
and resolved calendars are recorded. This is adequate for our prototype's daily
session checks, not a claim that every exchange's intraday rules are identical.
The calendar and the vendor can still be wrong, so preserve their versions.

Passing the checks establishes structural consistency only. It does not
independently establish price accuracy. Before accepting real data for strategy
work, compare a handful of dates per symbol, including dividend/split boundaries,
with a second provider of known adjustment and session semantics. Align currency,
feed, timezone and adjustment basis first. Do not compare IEX-only volume with
consolidated volume as though they were the same measurement. Record differences
and their explanation; unexplained discrepancies block research approval.

## 6. Troubleshooting

| Symptom | Next step |
| --- | --- |
| `No module named quanttrading` | Open the project root, select `.venv`, run `python -m pip install -e ".[dev]"`. |
| `No module named yfinance` | Install dependencies using the same interpreter used to run the command. |
| DNS, TLS, proxy or connection error | Check local connectivity and permitted proxy configuration. Do not disable TLS certificate verification. |
| Rate limit / HTTP 429 | Stop requests and retry later. The code does not rapidly retry known Yahoo rate-limit errors. |
| Empty response | Check connectivity, provider availability and date range. No data is not evidence of no trading. |
| Missing fields or changed metadata | Inspect `provider_output.csv`, `metadata.json` and installed versions; investigate a provider/schema change rather than fabricating fields. |
| Missing sessions or invalid OHLC | Inspect `quality.json`. Compare with an independent source; do not fill gaps to force a pass. |
| No chart | Inspect `manifest.json` and failures. Charts are deliberately withheld on a partial/failed run. |
| Different values on a rerun | Compare checksums and snapshots. Vendor adjustments or corrections can change history. |

## 7. Start version control

After inspecting the files and confirming no credentials or local datasets are
included:

```bash
git init
git add .
git commit -m "Add research-only daily market data pipeline"
```

Use a private GitHub repository initially. `.gitignore` excludes environments,
market-data runs, caches and `.env` files. Never commit brokerage credentials.
No cloud account, API key, IBKR login or live-trading approval is needed here.

## Next gate

Complete one genuine local download, inspect its chart and quality reports,
and document independent spot checks. Only then add basic return calculations
and a momentum-only research baseline. Fundamentals, a backtest engine, risk
controls and IBKR paper execution are later, separately tested increments.

See `docs/architecture-and-sources.md` for design choices, provider comparison,
research limitations and primary documentation.
