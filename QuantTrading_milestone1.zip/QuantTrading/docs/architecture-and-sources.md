# Architecture and source decisions

Prepared 14 November 2026. External service terms, endpoint access and library
behaviour must be rechecked when changing the pipeline or moving to deployment.

## Assessment of the proposed architecture

The requested separation of data, strategies, backtesting, execution, risk and
portfolio accounting is a sound destination. It is unnecessarily broad for the
first increment. Keep one Python package and build only the data subsystem now.
Do not create empty modules that imply unimplemented safety or execution features.

Version 1.0 should aim for an end-of-day, long-only research system with a small,
transparent rule set, a trustworthy backtest and an eventual paper-trading path.
This delivered version 0.1.0 is only its first data-foundation milestone.

Separate source code (`src/quanttrading/`) from generated market-data snapshots
(`data/runs/`). Use `pyproject.toml` instead of maintaining duplicate dependency
lists. Use standard-library logging; when a monitoring package is added, prefer
`logging_config.py` to an easily confused top-level `logging.py`.

Suggested later package boundaries, NOT implemented here:

    data -> features -> strategy targets -> portfolio/risk -> execution
                         historical simulator <-> portfolio accounting

Data providers should return an explicit contract; strategy code must not call
Yahoo or IBKR directly. Fundamentals later need separate observation-period,
publication/acceptance, availability and ingestion timestamps, including the
policy for restatements. Daily price dates are not substitutes for those fields.

For future FX or futures support, add explicit instrument identifiers, currencies,
contract multipliers, expiries, calendars and roll rules when those assets are
actually introduced. Do not pretend that adding a futures ticker to an equity
CSV solves futures accounting or creates a tradable continuous contract.

## Scope and research cautions

The engineering universe is SPY, QQQ, AAPL and MSFT. SPY supplies an S&P 500 ETF
reference and QQQ a Nasdaq-100 ETF reference; AAPL and MSFT exercise the equity
path. This is not a diversified recommendation or an unbiased historical stock
universe. Selecting today's familiar survivors cannot support a broad stock-
selection claim. Historical membership, delisted instruments and identifier
changes need a separate solution before such claims are tested.

Company revenue and earnings growth cannot be applied mechanically to an ETF.
An ETF needs a defined constituent aggregation or an appropriate sector/macro
signal. Point-in-time fundamental availability is essential; a current company
snapshot cannot simply be copied into past backtest dates.

Later strategy comparisons should separate buy-and-hold, momentum-only,
fundamentals-only and combined signals, with comparable costs, exposure rules
and information timing. Greater historical returns alone will not establish
incremental predictive value or an exploitable edge. No performance claim is
made by this starter.

A daily signal computed from a session's completed close must not be filled at
that same close under an assumption that it was already known. We will define
signal timestamps and execution timing when the simulator is built. This starter
contains neither simulated trades nor return/performance statistics.

## Data-provider comparison

**Yahoo Finance via yfinance: initial engineering adapter.** No API key is needed
for the public-data workflow shown in the library's quick start. It is an
unofficial research tool, not a contractual production data service. The
project's documentation flags personal-use restrictions on Yahoo data. Do not
interpret free access or an open-source code licence as commercial data rights.

**Alpaca: useful alternative/independent-check candidate.** Its official FAQ
states that historical SIP queries without a paid subscription require `end` to
be at least 15 minutes old. Free live IEX data and consolidated SIP data are not
the same feed. Use explicit `feed=sip` for relevant historical comparisons and
verify account eligibility, credentials, endpoint entitlements and adjustments.
This does not require moving the eventual execution broker away from IBKR.

**Alpha Vantage: limited free exploration.** Its support page states a standard
free allowance of 25 requests per day; its daily-adjusted endpoint is marked
premium. Do not plan a full adjusted-daily pipeline on the assumption that every
endpoint is free.

**IBKR: later broker-aligned source.** Historical API requests have permissions,
subscription and pacing considerations. IBKR documents gaps such as securities
that are no longer trading and warns that its history is adjusted/filtered. It
is not a replacement for a complete survivorship-bias-free research database.
Keeping broker integration out of this milestone avoids requiring a funded or
configured brokerage session just to learn the data pipeline.

All initial instruments are quoted in USD in this pipeline. Inclusion in a
research universe does not verify account-level tradability or eligibility.
Those checks belong before broker testing.

## IB Gateway versus TWS

For later local paper tests, a visible TWS session is helpful for inspecting
orders and positions. IB Gateway is the likely lower-resource deployment host;
IBKR describes it as a lightweight alternative with full API functionality.
Neither choice removes authentication, session maintenance, restart recovery,
position reconciliation, idempotent order handling, or risk controls. Do not
assume unattended, permanently logged-in cloud operation. No broker integration,
credentials, cloud deployment, or real-money execution is included here.

## Price and availability contract

Use `Ticker.history` with all material options explicit: daily interval,
`auto_adjust=False`, `back_adjust=False`, `actions=True`, `repair=False`,
`keepna=True`, and an exclusive end date. The provider response is preserved
before our own normalization. It is not the original HTTP payload or certified
unadjusted exchange tape. The library itself can transform upstream data.

Yahoo defines adjusted close as adjusted for applicable splits and dividends.
We preserve adjusted close separately from the OHLC series and never infer that
an adjusted price was an executable historical fill. Download-time observations
can also be revised after the historical date. Timestamped snapshots and hashes
make our own dataset reproducible; they do not create a vendor point-in-time
archive of what was published in the past.

## Primary documentation

These references support the external-product statements above. Project choices
and future requirements are design recommendations, not claims from the sources.

- yfinance documentation and disclaimer: https://ranaroussi.github.io/yfinance/
- Price-history parameters: https://ranaroussi.github.io/yfinance/reference/yfinance.price_history.html
- yfinance source for history handling: https://github.com/ranaroussi/yfinance/blob/main/yfinance/scrapers/history.py
- Yahoo adjusted-close definition: https://help.yahoo.com/kb/SLN28256.html
- Alpaca historical SIP/IEX permissions and feed differences: https://docs.alpaca.markets/us/docs/market-data-faq
- Alpha Vantage free allowance: https://www.alphavantage.co/support/api-key/
- Alpha Vantage daily-adjusted endpoint: https://www.alphavantage.co/documentation/#dailyadj
- IBKR market-data limits: https://www.interactivebrokers.com/docs/tws-api/doc/md/market-data-limitations
- IBKR historical-data access: https://www.interactivebrokers.com/support/faq/content/obtain-historical-data-via-api-28236420
- IB Gateway: https://www.interactivebrokers.com/support/faq/content/ib-gateway-41571362
- Python virtual environments: https://docs.python.org/3.13/library/venv.html
- exchange_calendars: https://github.com/gerrymanoim/exchange_calendars
- SPY issuer: https://www.ssga.com/us/en/individual/etfs/state-street-spdr-sp-500-etf-trust-spy
- QQQ issuer: https://www.invesco.com/us/en/financial-products/etfs/invesco-qqq-trust-series-1.html
