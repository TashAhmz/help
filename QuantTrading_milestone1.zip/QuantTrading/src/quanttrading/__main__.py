"""Command-line entry point: python -m quanttrading."""

import argparse
import logging
from pathlib import Path

from .config import DEFAULT_END, DEFAULT_START, INSTRUMENTS
from .pipeline import run_pipeline


def main() -> int:
    parser = argparse.ArgumentParser(description="Research-only daily market-data pipeline. No trading.")
    parser.add_argument("--symbols", nargs="+", choices=list(INSTRUMENTS), default=list(INSTRUMENTS))
    parser.add_argument("--start", default=DEFAULT_START, help="Inclusive YYYY-MM-DD")
    parser.add_argument("--end", default=DEFAULT_END, help="Exclusive YYYY-MM-DD; today is not downloaded")
    parser.add_argument("--output", type=Path, default=Path("data/runs"))
    args = parser.parse_args()
    logging.basicConfig(level=logging.INFO, format="%(levelname)s %(message)s")
    try:
        run, passed = run_pipeline([INSTRUMENTS[symbol] for symbol in args.symbols],
                                   args.start, args.end, args.output)
    except (ValueError, OSError) as exc:
        parser.exit(2, f"Cannot start pipeline: {exc}\n")
    print(f"Run saved to: {run.resolve()}")
    if passed:
        print("Structural checks passed. Review warnings and independently compare prices before research.")
        print(f"Chart: {(run / 'price_comparison.png').resolve()}")
        return 0
    print("RUN FAILED. Inspect manifest.json, run.log and per-symbol reports. Do not use a partial run.")
    return 1


if __name__ == "__main__":
    raise SystemExit(main())
