"""Snapshot, validate, publish, and report. Failed runs never get a success marker."""

from collections.abc import Callable, Sequence
from dataclasses import asdict
from datetime import datetime, timezone
from hashlib import sha256
from importlib.metadata import PackageNotFoundError, version
import json
import logging
from pathlib import Path
import platform
from typing import Any
from uuid import uuid4

import pandas as pd

from .config import Instrument, check_dates
from .market_data import fetch_history, normalize_bars
from .plotting import plot_prices
from .validation import expected_sessions, validate_bars

LOG = logging.getLogger(__name__)
Loader = Callable[[Instrument, str, str], tuple[pd.DataFrame, dict[str, Any]]]


def write_json(path: Path, value: dict[str, Any]) -> None:
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(json.dumps(value, indent=2, default=str, allow_nan=False) + "\n",
                         encoding="utf-8")
    temporary.replace(path)


def write_csv(path: Path, frame: pd.DataFrame, *, provider: bool = False) -> str:
    temporary = path.with_suffix(path.suffix + ".tmp")
    frame.to_csv(temporary, index=provider,
                 **({} if provider else {"date_format": "%Y-%m-%d"}))
    temporary.replace(path)
    return sha256(path.read_bytes()).hexdigest()


def environment_versions() -> dict[str, str]:
    versions = {"python": platform.python_version()}
    for package in ("quanttrading", "yfinance", "pandas", "numpy", "matplotlib", "exchange-calendars"):
        try:
            versions[package] = version(package)
        except PackageNotFoundError:
            versions[package] = "not installed as a distribution"
    return versions


def run_pipeline(
    instruments: Sequence[Instrument], start: str, end: str, output: Path,
    *, loader: Loader = fetch_history, source_label: str = "Yahoo Finance via yfinance",
) -> tuple[Path, bool]:
    """A run is usable only when every requested instrument passes structural checks.

    source_label exists for unmistakably labelled synthetic integration tests.
    There is deliberately no automatic fallback to a different data provider.
    """
    check_dates(start, end)
    symbols = [instrument.symbol for instrument in instruments]
    if not symbols or len(set(symbols)) != len(symbols):
        raise ValueError("Provide a nonempty set of unique instruments.")
    for instrument in instruments:
        expected_sessions(instrument, start, end)
    now = datetime.now(timezone.utc)
    run = output / (now.strftime("%Y%m%dT%H%M%S%fZ") + "_" + uuid4().hex[:8])
    run.mkdir(parents=True, exist_ok=False)
    manifest: dict[str, Any] = {
        "schema_version": 1, "status": "in_progress", "source": source_label,
        "started_at_utc": now.isoformat(), "start_inclusive": start, "end_exclusive": end,
        "interval": "1d", "instruments": [asdict(item) for item in instruments],
        "environment": environment_versions(), "results": {},
        "request_policy": {"auto_adjust": False, "back_adjust": False,
                           "actions": True, "repair": False, "keepna": True},
        "price_basis": "Provider OHLC, separate adjusted close; not guaranteed as-traded prices.",
        "independent_price_accuracy_verified": False,
    }
    write_json(run / "manifest.json", manifest)
    handler = logging.FileHandler(run / "run.log", encoding="utf-8")
    handler.setFormatter(logging.Formatter("%(asctime)s %(levelname)s %(name)s %(message)s"))
    root = logging.getLogger()
    root.addHandler(handler)
    clean: dict[str, pd.DataFrame] = {}
    try:
        for instrument in instruments:
            folder = run / instrument.symbol
            folder.mkdir()
            try:
                LOG.info("Retrieving %s [%s, %s)", instrument.symbol, start, end)
                raw, metadata = loader(instrument, start, end)
                raw_hash = write_csv(folder / "provider_output.csv", raw, provider=True)
                write_json(folder / "metadata.json", {
                    "retrieved_at_utc": datetime.now(timezone.utc).isoformat(),
                    "provider_metadata": metadata, "provider_columns": list(raw.columns),
                    "provider_index_was_sorted": bool(raw.index.is_monotonic_increasing),
                    "provider_output_sha256": raw_hash,
                })
                bars = normalize_bars(raw, instrument)
                quality = validate_bars(bars, instrument, start, end, metadata)
                write_json(folder / "quality.json", quality)
                result = {"structural_pass": quality["structural_pass"],
                          "rows": len(bars), "provider_output_sha256": raw_hash,
                          "warnings": quality["warnings"], "errors": quality["errors"]}
                if quality["structural_pass"]:
                    result["validated_sha256"] = write_csv(folder / "validated.csv", bars)
                    clean[instrument.symbol] = bars
                    LOG.info("%s: %d rows; structural checks passed.", instrument.symbol, len(bars))
                else:
                    LOG.error("%s failed: %s", instrument.symbol, "; ".join(quality["errors"]))
                for warning in quality["warnings"]:
                    LOG.warning("%s: %s", instrument.symbol, warning)
                manifest["results"][instrument.symbol] = result
            except Exception as exc:
                LOG.exception("%s failed", instrument.symbol)
                result = {"structural_pass": False, "error_type": type(exc).__name__, "error": str(exc)}
                write_json(folder / "failure.json", result)
                manifest["results"][instrument.symbol] = result
            write_json(run / "manifest.json", manifest)
        all_passed = len(clean) == len(instruments)
        if all_passed:
            try:
                plot_prices(clean, run / "price_comparison.png")
            except Exception as exc:
                LOG.exception("Chart generation failed")
                manifest["plot_error"] = str(exc)
                all_passed = False
        has_warnings = any(result.get("warnings") for result in manifest["results"].values())
        manifest["status"] = ("structural_pass_review_required" if has_warnings else "structural_pass") if all_passed else "failed"
        manifest["completed_at_utc"] = datetime.now(timezone.utc).isoformat()
        write_json(run / "manifest.json", manifest)
        return run, all_passed
    finally:
        root.removeHandler(handler)
        handler.close()
