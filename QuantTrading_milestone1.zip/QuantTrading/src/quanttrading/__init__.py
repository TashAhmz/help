"""Small, research-only building blocks. No order execution is implemented."""

__version__ = "0.1.0"
