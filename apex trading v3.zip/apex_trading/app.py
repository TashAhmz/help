"""
APEX v3 Flask Server
Serves dashboard and exposes REST API for the trading engine
"""

from flask import Flask, jsonify, render_template, request
import numpy as np
import threading
import time
import json
from datetime import datetime
from dataclasses import asdict

from algo.engine import StrategyAggregator, INSTRUMENTS
from algo.connector import OANDAConnector
from algo.trade_manager import TradeManager
from utils.emailer import generate_email_html, send_daily_report

app = Flask(__name__)

# ── Global State ───────────────────────────────────────────────────────────────
connector   = OANDAConnector()
aggregator  = StrategyAggregator()
manager     = TradeManager(account_balance=100_000)

current_signals   = {}
current_prices    = {}
price_history     = {inst: [] for inst in INSTRUMENTS}
algo_running      = False
last_update       = None

EMAIL_RECIPIENTS  = ["your@email.com"]  # update via /api/settings
SMTP_CONFIG       = {}                  # update via /api/settings


# ── Background Algo Loop ───────────────────────────────────────────────────────

def algo_loop():
    global current_signals, current_prices, last_update, algo_running

    while algo_running:
        try:
            prices_now = {}

            for inst in INSTRUMENTS:
                # Get latest candles for analysis
                candle_data = connector.get_candles(inst, count=100)
                candles     = candle_data.get("candles", [])

                if len(candles) < 30:
                    continue

                closes = np.array([float(c["mid"]["c"]) for c in candles])
                highs  = np.array([float(c["mid"]["h"]) for c in candles])
                lows   = np.array([float(c["mid"]["l"]) for c in candles])

                # Current price
                price_tick = connector.get_price(inst)
                mid_price  = price_tick["mid"]
                prices_now[inst] = mid_price

                # Store price history for chart (last 60 points)
                price_history[inst].append({
                    "time":  price_tick["time"],
                    "price": mid_price
                })
                if len(price_history[inst]) > 60:
                    price_history[inst].pop(0)

                # Generate signal
                signal = aggregator.get_signal(inst, closes, highs, lows, mid_price)
                current_signals[inst] = asdict(signal)

                # Execute if conditions met
                if signal.direction != "HOLD" and signal.confidence >= 0.30:
                    fill = signal.entry_price
                    manager.open_trade(signal, fill)

            # Update P&L
            manager.update_prices(prices_now)
            current_prices = prices_now
            last_update = datetime.utcnow().isoformat()

        except Exception as e:
            print(f"[APEX] Loop error: {e}")

        time.sleep(15)  # 15-second cycle


# ── API Routes ─────────────────────────────────────────────────────────────────

@app.route("/")
def index():
    return render_template("dashboard.html")

@app.route("/api/status")
def api_status():
    return jsonify({
        "running":      algo_running,
        "last_update":  last_update,
        "mode":         "LIVE" if connector.live else "SIMULATION",
        "instruments":  list(INSTRUMENTS.keys()),
    })

@app.route("/api/account")
def api_account():
    oanda_acc = connector.get_account()
    stats     = manager.get_portfolio_stats()
    return jsonify({**stats, "oanda": oanda_acc})

@app.route("/api/signals")
def api_signals():
    return jsonify(current_signals)

@app.route("/api/prices")
def api_prices():
    return jsonify(current_prices)

@app.route("/api/price-history")
def api_price_history():
    return jsonify(price_history)

@app.route("/api/trades/open")
def api_open_trades():
    return jsonify(manager.get_open_trades_list())

@app.route("/api/trades/closed")
def api_closed_trades():
    n = int(request.args.get("n", 50))
    return jsonify(manager.get_recent_closed(n))

@app.route("/api/trades/close/<trade_id>", methods=["POST"])
def api_close_trade(trade_id):
    price = current_prices.get(
        manager.open_trades.get(trade_id, {}).get("instrument", ""), 0
    ) if hasattr(manager.open_trades.get(trade_id, {}), "get") else 0

    # Get instrument from trade
    trade = manager.open_trades.get(trade_id)
    if trade:
        price = current_prices.get(trade.instrument, trade.current_price)
        manager.manual_close(trade_id, price)
        return jsonify({"success": True, "message": f"Trade {trade_id} closed"})
    return jsonify({"success": False, "message": "Trade not found"}), 404

@app.route("/api/log")
def api_log():
    return jsonify(manager.get_log(50))

@app.route("/api/algo/start", methods=["POST"])
def api_start():
    global algo_running
    if not algo_running:
        algo_running = True
        t = threading.Thread(target=algo_loop, daemon=True)
        t.start()
        return jsonify({"success": True, "message": "Algo started"})
    return jsonify({"success": False, "message": "Already running"})

@app.route("/api/algo/stop", methods=["POST"])
def api_stop():
    global algo_running
    algo_running = False
    return jsonify({"success": True, "message": "Algo stopped"})

@app.route("/api/settings", methods=["POST"])
def api_settings():
    global EMAIL_RECIPIENTS, SMTP_CONFIG
    data = request.json or {}
    if "recipients" in data:
        EMAIL_RECIPIENTS = data["recipients"]
    if "smtp" in data:
        SMTP_CONFIG = data["smtp"]
    if "api_key" in data:
        connector.api_key    = data["api_key"]
        connector.account_id = data.get("account_id", connector.account_id)
        connector.live       = bool(connector.api_key)
    return jsonify({"success": True})

@app.route("/api/email/preview")
def api_email_preview():
    stats        = manager.get_portfolio_stats()
    open_trades  = manager.get_open_trades_list()
    closed       = manager.get_recent_closed(10)
    signals_list = list(current_signals.values())
    html         = generate_email_html(stats, open_trades, closed, signals_list)
    return html, 200, {"Content-Type": "text/html"}

@app.route("/api/email/send", methods=["POST"])
def api_email_send():
    if not SMTP_CONFIG:
        return jsonify({"success": False, "message": "SMTP not configured"}), 400
    stats   = manager.get_portfolio_stats()
    signals = list(current_signals.values())
    ok = send_daily_report(
        EMAIL_RECIPIENTS, SMTP_CONFIG,
        stats, manager.get_open_trades_list(),
        manager.get_recent_closed(20), signals
    )
    return jsonify({"success": ok})


if __name__ == "__main__":
    print("""
    ╔═══════════════════════════════════════════╗
    ║          APEX Trading System v3           ║
    ║   WTI · Brent · NatGas · Gold · Silver   ║
    ╚═══════════════════════════════════════════╝
    Dashboard: http://localhost:5000
    """)
    app.run(debug=True, port=5000, use_reloader=False)
