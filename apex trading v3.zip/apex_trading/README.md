# APEX Trading System v3
### Automated Commodity Trading — WTI · Brent · Natural Gas · Gold · Silver

---

## Quick Start

```bash
cd apex_trading
pip install -r requirements.txt
python app.py
```

Then open **http://localhost:5000** in your browser.

---

## Architecture

```
apex_trading/
├── app.py                  ← Flask server + REST API
├── algo/
│   ├── engine.py           ← Strategy logic (4 strategies)
│   ├── connector.py        ← OANDA API + simulation fallback
│   └── trade_manager.py    ← Position sizing, risk, portfolio
├── utils/
│   └── emailer.py          ← Daily P&L email reports
├── templates/
│   └── dashboard.html      ← Web dashboard
└── requirements.txt
```

---

## Strategies

| Strategy | Weight | Description |
|---|---|---|
| **Trend Following** | 35% | EMA 20/50 crossover + MACD confirmation |
| **Mean Reversion** | 25% | Bollinger Bands + RSI extremes |
| **Volatility Breakout** | 25% | Donchian channels + ATR expansion + Stochastic |
| **Fundamental Overlay** | 15% | Seasonal bias + macro factors |

Signals are combined via **weighted voting**. A trade is only opened if combined confidence ≥ 30%.

---

## Risk Management

- **1% max risk per trade** (Kelly-inspired sizing)
- **ATR-based stop losses** (2× ATR below/above entry)
- **ATR-based take profits** (3× ATR — 1.5 R:R ratio)
- **Max 5 concurrent positions**
- **One position per instrument** at any time

---

## OANDA Setup (Demo Account)

1. Create a free demo account at [oanda.com](https://www.oanda.com)
2. Generate a practice API key in your account settings
3. Open Settings in the dashboard and enter:
   - API Key
   - Account ID (format: 001-XXX-XXXXXXXX-XXX)

Without an API key, the system runs in **simulation mode** using realistic GBM price generation.

---

## Email Reports

Configure SMTP in the Settings modal:
- **Gmail**: Use an App Password (not your main password)
- Host: `smtp.gmail.com`, Port: `465`

Reports include: daily P&L, all trades, current signals, commodity news digest.

---

## API Reference

| Endpoint | Method | Description |
|---|---|---|
| `/api/status` | GET | Algo status + mode |
| `/api/account` | GET | Balance, P&L, stats |
| `/api/signals` | GET | Current signals for all instruments |
| `/api/prices` | GET | Live prices |
| `/api/price-history` | GET | Price history for charts |
| `/api/trades/open` | GET | Open positions |
| `/api/trades/closed` | GET | Closed trade history |
| `/api/trades/close/<id>` | POST | Manually close a trade |
| `/api/algo/start` | POST | Start the algo loop |
| `/api/algo/stop` | POST | Stop the algo loop |
| `/api/settings` | POST | Update API key, email config |
| `/api/email/preview` | GET | Preview today's email report |
| `/api/email/send` | POST | Send report now |

---

## Next Steps (Firebase Integration)

To add Firebase real-time sync:
```bash
pip install firebase-admin
```

Then in `app.py`, after each trade event, push to Firestore:
```python
import firebase_admin
from firebase_admin import firestore

db = firestore.client()
db.collection('trades').add(asdict(trade))
```

---

*Built on APEX v2 · Extended for WTI, Brent, NatGas, Gold, Silver*
