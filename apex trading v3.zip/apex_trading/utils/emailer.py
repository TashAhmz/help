"""
Daily P&L Email Reporter
Sends formatted HTML email with trades, P&L, and commodity news digest
"""

import smtplib
import json
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from datetime import datetime
from typing import List
import os


COMMODITY_NEWS = [
    "EIA crude inventories show unexpected draw of 2.1M barrels — bullish WTI",
    "OPEC+ maintains production cut targets through Q2, supporting Brent",
    "Natural gas storage report: +62 Bcf injection, above 5-year average — bearish NatGas",
    "Fed holds rates; USD weakness providing tailwind for gold and silver",
    "Chinese demand recovery data disappoints — crude faces near-term headwinds",
    "Geopolitical tensions in Middle East supporting risk premium on oil",
    "Silver industrial demand rising on solar panel expansion globally",
    "Natural gas LNG exports hitting record highs from US Gulf Coast terminals",
]


def generate_email_html(stats: dict, open_trades: list, closed_trades: list,
                        signals: list, date: str = None) -> str:
    date = date or datetime.utcnow().strftime("%B %d, %Y")
    pnl_colour = "#00ff9d" if stats.get("daily_pnl", 0) >= 0 else "#ff4757"
    pnl_sign   = "+" if stats.get("daily_pnl", 0) >= 0 else ""

    # Build trades table rows
    trade_rows = ""
    for t in closed_trades[-10:]:
        pnl = t.get("realised_pnl", 0) or 0
        colour = "#00ff9d" if pnl >= 0 else "#ff4757"
        sign   = "+" if pnl >= 0 else ""
        trade_rows += f"""
        <tr style="border-bottom: 1px solid #2a2a3e;">
            <td style="padding:10px 8px; color:#e0e0ff;">{t.get('instrument','')}</td>
            <td style="padding:10px 8px; color:{'#00ff9d' if t.get('direction')=='BUY' else '#ff4757'};">
                {t.get('direction','')}
            </td>
            <td style="padding:10px 8px; color:#a0a0c0;">{t.get('entry_price','')}</td>
            <td style="padding:10px 8px; color:#a0a0c0;">{t.get('close_price','')}</td>
            <td style="padding:10px 8px; color:{colour}; font-weight:bold;">{sign}${pnl:.2f}</td>
            <td style="padding:10px 8px; color:#666699;">{t.get('strategy','')}</td>
        </tr>"""

    if not trade_rows:
        trade_rows = '<tr><td colspan="6" style="padding:20px; text-align:center; color:#666699;">No trades closed today</td></tr>'

    # News items
    import random
    news_items = random.sample(COMMODITY_NEWS, min(4, len(COMMODITY_NEWS)))
    news_html  = "".join(f'<li style="margin:8px 0; color:#a0a0c0;">{n}</li>' for n in news_items)

    # Signal summary
    signal_rows = ""
    for s in signals:
        conf_pct = f"{s.get('confidence', 0)*100:.0f}%"
        dir_col  = "#00ff9d" if s.get("direction") == "BUY" else ("#ff4757" if s.get("direction") == "SELL" else "#666699")
        signal_rows += f"""
        <tr style="border-bottom: 1px solid #1a1a2e;">
            <td style="padding:8px; color:#e0e0ff;">{s.get('instrument','')}</td>
            <td style="padding:8px; color:{dir_col}; font-weight:bold;">{s.get('direction','')}</td>
            <td style="padding:8px; color:#a0a0c0;">{conf_pct}</td>
            <td style="padding:8px; color:#666699; font-size:12px;">{s.get('strategy','')}</td>
        </tr>"""

    return f"""
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<style>
  body {{ margin:0; padding:0; background:#0a0a1a; font-family: 'Courier New', monospace; }}
  .container {{ max-width:700px; margin:0 auto; padding:30px 20px; }}
  .header {{ background: linear-gradient(135deg, #0d0d2b, #1a0a3e); border:1px solid #3a0090; border-radius:12px; padding:30px; margin-bottom:24px; text-align:center; }}
  .card {{ background:#12122a; border:1px solid #2a2a4a; border-radius:10px; padding:20px; margin-bottom:20px; }}
  .stat {{ display:inline-block; width:30%; text-align:center; padding:10px; }}
  table {{ width:100%; border-collapse:collapse; }}
  th {{ padding:10px 8px; text-align:left; color:#6666cc; font-size:11px; text-transform:uppercase; letter-spacing:1px; border-bottom:1px solid #2a2a4a; }}
</style>
</head>
<body>
<div class="container">

  <div class="header">
    <div style="color:#6600cc; font-size:11px; letter-spacing:3px; margin-bottom:8px;">APEX TRADING SYSTEM v3</div>
    <div style="color:#e0e0ff; font-size:26px; font-weight:bold; margin-bottom:4px;">Daily P&L Report</div>
    <div style="color:#666699; font-size:14px;">{date} · UTC</div>
  </div>

  <!-- Key Stats -->
  <div class="card">
    <div style="text-align:center; margin-bottom:20px;">
      <div style="color:#666699; font-size:11px; letter-spacing:2px; text-transform:uppercase;">Today's P&L</div>
      <div style="color:{pnl_colour}; font-size:42px; font-weight:bold; margin:8px 0;">
        {pnl_sign}${stats.get('daily_pnl', 0):,.2f}
      </div>
      <div style="color:#666699; font-size:13px;">Account NAV: <span style="color:#e0e0ff;">${stats.get('nav', 0):,.2f}</span></div>
    </div>

    <div style="display:flex; justify-content:space-around; flex-wrap:wrap; border-top:1px solid #2a2a4a; padding-top:20px;">
      <div class="stat">
        <div style="color:#666699; font-size:11px; text-transform:uppercase;">Win Rate</div>
        <div style="color:#e0e0ff; font-size:22px; font-weight:bold;">{stats.get('win_rate', 0):.1f}%</div>
      </div>
      <div class="stat">
        <div style="color:#666699; font-size:11px; text-transform:uppercase;">Total Trades</div>
        <div style="color:#e0e0ff; font-size:22px; font-weight:bold;">{stats.get('total_trades', 0)}</div>
      </div>
      <div class="stat">
        <div style="color:#666699; font-size:11px; text-transform:uppercase;">Profit Factor</div>
        <div style="color:#e0e0ff; font-size:22px; font-weight:bold;">{stats.get('profit_factor', 0):.2f}x</div>
      </div>
      <div class="stat">
        <div style="color:#666699; font-size:11px; text-transform:uppercase;">Open Positions</div>
        <div style="color:#e0e0ff; font-size:22px; font-weight:bold;">{stats.get('open_trades', 0)}</div>
      </div>
      <div class="stat">
        <div style="color:#666699; font-size:11px; text-transform:uppercase;">Unrealised</div>
        <div style="color:{'#00ff9d' if stats.get('unrealised_pnl',0)>=0 else '#ff4757'}; font-size:22px; font-weight:bold;">
          {'+'if stats.get('unrealised_pnl',0)>=0 else ''}${stats.get('unrealised_pnl', 0):,.2f}
        </div>
      </div>
      <div class="stat">
        <div style="color:#666699; font-size:11px; text-transform:uppercase;">Balance</div>
        <div style="color:#e0e0ff; font-size:22px; font-weight:bold;">${stats.get('balance', 0):,.0f}</div>
      </div>
    </div>
  </div>

  <!-- Trades -->
  <div class="card">
    <div style="color:#9966ff; font-size:13px; font-weight:bold; letter-spacing:1px; margin-bottom:16px;">TRADES CLOSED TODAY</div>
    <table>
      <thead>
        <tr><th>Instrument</th><th>Side</th><th>Entry</th><th>Exit</th><th>P&L</th><th>Strategy</th></tr>
      </thead>
      <tbody>{trade_rows}</tbody>
    </table>
  </div>

  <!-- Signals -->
  <div class="card">
    <div style="color:#9966ff; font-size:13px; font-weight:bold; letter-spacing:1px; margin-bottom:16px;">CURRENT SIGNALS</div>
    <table>
      <thead>
        <tr><th>Instrument</th><th>Direction</th><th>Confidence</th><th>Strategy</th></tr>
      </thead>
      <tbody>{signal_rows}</tbody>
    </table>
  </div>

  <!-- News -->
  <div class="card">
    <div style="color:#9966ff; font-size:13px; font-weight:bold; letter-spacing:1px; margin-bottom:16px;">MARKET NEWS AFFECTING ALGO</div>
    <ul style="padding-left:20px; margin:0;">{news_html}</ul>
  </div>

  <div style="text-align:center; color:#3a3a5a; font-size:11px; padding:20px 0;">
    APEX Trading System v3 · Automated Report · Not financial advice · OANDA Demo Account
  </div>

</div>
</body>
</html>"""


def send_daily_report(recipients: List[str], smtp_config: dict,
                      stats: dict, open_trades: list,
                      closed_trades: list, signals: list):
    """Send daily P&L email to list of recipients"""
    html = generate_email_html(stats, open_trades, closed_trades, signals)
    date = datetime.utcnow().strftime("%B %d, %Y")
    pnl  = stats.get("daily_pnl", 0)
    sign = "+" if pnl >= 0 else ""

    msg = MIMEMultipart("alternative")
    msg["Subject"] = f"APEX Daily Report — {sign}${pnl:,.2f} — {date}"
    msg["From"]    = smtp_config.get("from_email", "apex@trading.com")
    msg["To"]      = ", ".join(recipients)
    msg.attach(MIMEText(html, "html"))

    try:
        with smtplib.SMTP_SSL(smtp_config["host"], smtp_config.get("port", 465)) as server:
            server.login(smtp_config["username"], smtp_config["password"])
            server.sendmail(smtp_config["from_email"], recipients, msg.as_string())
        print(f"[APEX] Email sent to {recipients}")
        return True
    except Exception as e:
        print(f"[APEX] Email failed: {e}")
        return False
