"""
OANDA API Connector
Handles live data fetching and order placement for APEX v3.
Falls back to realistic simulation when no API key is provided (demo mode).
"""

import numpy as np
import json
import time
import math
import random
from datetime import datetime, timedelta
from typing import Optional
import os

try:
    import requests
    HAS_REQUESTS = True
except ImportError:
    HAS_REQUESTS = False


OANDA_BASE_URL = "https://api-fxpractice.oanda.com"  # demo/practice endpoint

INSTRUMENT_MAP = {
    "WTI":    "BCO_USD",
    "BRENT":  "BCO_USD",
    "NATGAS": "NATGAS_USD",
    "GOLD":   "XAU_USD",
    "SILVER": "XAG_USD",
}

# Realistic base prices (March 2025 approximate)
BASE_PRICES = {
    "WTI":    78.50,
    "BRENT":  82.30,
    "NATGAS":  1.95,
    "GOLD":  2180.0,
    "SILVER":  24.50,
}

# Volatility profiles (daily % moves)
VOLATILITY = {
    "WTI":    0.018,
    "BRENT":  0.016,
    "NATGAS": 0.035,
    "GOLD":   0.008,
    "SILVER": 0.020,
}


class PriceSimulator:
    """
    Geometric Brownian Motion price simulator with mean reversion,
    realistic spreads, and correlated commodity moves.
    Used when OANDA API key is not available.
    """

    def __init__(self):
        self.prices = {inst: BASE_PRICES[inst] for inst in BASE_PRICES}
        self.tick_count = 0
        self.trend = {inst: random.choice([-1, 0, 0, 1]) for inst in BASE_PRICES}

    def _gbm_step(self, price: float, vol: float, dt: float = 1/252) -> float:
        drift = 0.0
        shock = np.random.normal(0, vol * math.sqrt(dt))
        return price * math.exp(drift + shock)

    def get_candles(self, instrument: str, count: int = 100) -> dict:
        """Generate realistic OHLC candle data"""
        base = BASE_PRICES[instrument]
        vol  = VOLATILITY[instrument]
        prices = [base]

        # Generate price path
        for _ in range(count - 1):
            prices.append(self._gbm_step(prices[-1], vol * 15))  # 15-min candles

        candles = []
        now = datetime.utcnow()
        for i, close in enumerate(prices):
            ts = now - timedelta(minutes=15 * (count - i))
            spread = close * 0.0002
            high = close + abs(np.random.normal(0, close * vol * 0.3))
            low  = close - abs(np.random.normal(0, close * vol * 0.3))
            open_ = prices[i - 1] if i > 0 else close
            candles.append({
                "time": ts.isoformat(),
                "mid": {
                    "o": str(round(open_, 5)),
                    "h": str(round(max(open_, close, high), 5)),
                    "l": str(round(min(open_, close, low), 5)),
                    "c": str(round(close, 5)),
                }
            })
        return {"candles": candles, "instrument": instrument, "granularity": "M15"}

    def get_price(self, instrument: str) -> dict:
        """Get current bid/ask with realistic spread"""
        price = self.prices[instrument]
        # Tick price
        vol = VOLATILITY[instrument]
        self.prices[instrument] = self._gbm_step(price, vol, 1/96)  # 15-min step

        spread = price * 0.0003
        bid = self.prices[instrument] - spread / 2
        ask = self.prices[instrument] + spread / 2
        return {
            "instrument": instrument,
            "bid": round(bid, 5),
            "ask": round(ask, 5),
            "mid": round((bid + ask) / 2, 5),
            "time": datetime.utcnow().isoformat(),
            "status": "tradeable"
        }

    def get_account(self) -> dict:
        return {
            "id": "DEMO-001",
            "balance": "100000.00",
            "currency": "USD",
            "unrealizedPL": "0.00",
            "nav": "100000.00",
            "marginUsed": "0.00",
            "marginAvailable": "100000.00",
            "openTradeCount": 0,
            "alias": "APEX Demo Account",
        }


class OANDAConnector:
    """
    Live OANDA API connector with simulation fallback.
    Set OANDA_API_KEY environment variable to use live demo account.
    """

    def __init__(self, api_key: Optional[str] = None, account_id: Optional[str] = None):
        self.api_key     = api_key or os.environ.get("OANDA_API_KEY", "")
        self.account_id  = account_id or os.environ.get("OANDA_ACCOUNT_ID", "")
        self.live        = bool(self.api_key and HAS_REQUESTS)
        self.simulator   = PriceSimulator()

        if self.live:
            self.headers = {
                "Authorization": f"Bearer {self.api_key}",
                "Content-Type": "application/json",
                "Accept-Datetime-Format": "RFC3339",
            }
        else:
            print("[APEX] No API key found — running in simulation mode")

    def _get(self, endpoint: str) -> dict:
        if not self.live:
            return {}
        url = f"{OANDA_BASE_URL}{endpoint}"
        resp = requests.get(url, headers=self.headers, timeout=10)
        resp.raise_for_status()
        return resp.json()

    def _post(self, endpoint: str, data: dict) -> dict:
        if not self.live:
            return {}
        url = f"{OANDA_BASE_URL}{endpoint}"
        resp = requests.post(url, headers=self.headers, json=data, timeout=10)
        resp.raise_for_status()
        return resp.json()

    def get_account(self) -> dict:
        if not self.live:
            return self.simulator.get_account()
        data = self._get(f"/v3/accounts/{self.account_id}/summary")
        return data.get("account", {})

    def get_candles(self, instrument: str, count: int = 100, granularity: str = "M15") -> dict:
        if not self.live:
            return self.simulator.get_candles(instrument, count)
        oanda_inst = INSTRUMENT_MAP.get(instrument, instrument)
        return self._get(
            f"/v3/instruments/{oanda_inst}/candles"
            f"?count={count}&granularity={granularity}&price=M"
        )

    def get_price(self, instrument: str) -> dict:
        if not self.live:
            return self.simulator.get_price(instrument)
        oanda_inst = INSTRUMENT_MAP.get(instrument, instrument)
        data = self._get(f"/v3/accounts/{self.account_id}/pricing?instruments={oanda_inst}")
        prices = data.get("prices", [{}])[0]
        bid = float(prices.get("bids", [{"price": 0}])[0]["price"])
        ask = float(prices.get("asks", [{"price": 0}])[0]["price"])
        return {"instrument": instrument, "bid": bid, "ask": ask,
                "mid": (bid + ask) / 2, "time": datetime.utcnow().isoformat(), "status": "tradeable"}

    def place_order(self, instrument: str, units: int, direction: str,
                    stop_loss: float, take_profit: float) -> dict:
        """Place a market order (positive units = buy, negative = sell)"""
        signed_units = units if direction == "BUY" else -units
        oanda_inst   = INSTRUMENT_MAP.get(instrument, instrument)

        order_body = {
            "order": {
                "type": "MARKET",
                "instrument": oanda_inst,
                "units": str(signed_units),
                "stopLossOnFill":   {"price": str(round(stop_loss, 5))},
                "takeProfitOnFill": {"price": str(round(take_profit, 5))},
                "timeInForce": "FOK",
            }
        }

        if not self.live:
            # Simulate order fill
            price = self.simulator.get_price(instrument)
            return {
                "orderFillTransaction": {
                    "id": f"SIM-{int(time.time())}",
                    "instrument": oanda_inst,
                    "units": str(signed_units),
                    "price": str(price["mid"]),
                    "time": datetime.utcnow().isoformat(),
                    "pl": "0.00",
                }
            }

        return self._post(f"/v3/accounts/{self.account_id}/orders", order_body)

    def get_open_trades(self) -> list:
        if not self.live:
            return []
        data = self._get(f"/v3/accounts/{self.account_id}/openTrades")
        return data.get("trades", [])

    def close_trade(self, trade_id: str) -> dict:
        if not self.live:
            return {"orderFillTransaction": {"pl": str(round(random.gauss(50, 200), 2))}}
        return self._post(f"/v3/accounts/{self.account_id}/trades/{trade_id}/close", {})
