"""
APEX Trading Engine v3
Multi-strategy commodity trading algo for WTI, Brent, Natural Gas, Gold, Silver
Connects to OANDA demo API
"""

import numpy as np
import pandas as pd
from datetime import datetime, timedelta
from dataclasses import dataclass, asdict
from typing import Optional
import json
import math

# ── Instrument Config ──────────────────────────────────────────────────────────
INSTRUMENTS = {
    "WTI":     {"oanda": "BCO_USD",   "display": "WTI Crude",    "units": 100,  "pip": 0.01},
    "BRENT":   {"oanda": "BCO_USD",   "display": "Brent Crude",  "units": 100,  "pip": 0.01},
    "NATGAS":  {"oanda": "NATGAS_USD","display": "Natural Gas",  "units": 1000, "pip": 0.001},
    "GOLD":    {"oanda": "XAU_USD",   "display": "Gold",         "units": 10,   "pip": 0.01},
    "SILVER":  {"oanda": "XAG_USD",   "display": "Silver",       "units": 100,  "pip": 0.001},
}

@dataclass
class Signal:
    instrument: str
    direction: str          # "BUY" | "SELL" | "HOLD"
    strategy: str
    confidence: float       # 0–1
    entry_price: float
    stop_loss: float
    take_profit: float
    reasoning: str
    timestamp: str

@dataclass
class Trade:
    id: str
    instrument: str
    direction: str
    units: int
    entry_price: float
    current_price: float
    stop_loss: float
    take_profit: float
    open_time: str
    strategy: str
    unrealised_pnl: float
    status: str             # "OPEN" | "CLOSED"
    close_price: Optional[float] = None
    close_time: Optional[str] = None
    realised_pnl: Optional[float] = None


# ── Technical Indicators ───────────────────────────────────────────────────────

def ema(prices: np.ndarray, period: int) -> np.ndarray:
    k = 2 / (period + 1)
    result = np.zeros_like(prices)
    result[0] = prices[0]
    for i in range(1, len(prices)):
        result[i] = prices[i] * k + result[i - 1] * (1 - k)
    return result


def rsi(prices: np.ndarray, period: int = 14) -> np.ndarray:
    delta = np.diff(prices)
    gain = np.where(delta > 0, delta, 0)
    loss = np.where(delta < 0, -delta, 0)
    avg_gain = pd.Series(gain).ewm(com=period - 1, adjust=False).mean().values
    avg_loss = pd.Series(loss).ewm(com=period - 1, adjust=False).mean().values
    rs = np.where(avg_loss == 0, 100, avg_gain / avg_loss)
    rsi_vals = 100 - (100 / (1 + rs))
    return np.concatenate([[50], rsi_vals])  # pad first value


def macd(prices: np.ndarray, fast=12, slow=26, signal=9):
    ema_fast = ema(prices, fast)
    ema_slow = ema(prices, slow)
    macd_line = ema_fast - ema_slow
    signal_line = ema(macd_line, signal)
    histogram = macd_line - signal_line
    return macd_line, signal_line, histogram


def bollinger_bands(prices: np.ndarray, period=20, std_dev=2):
    middle = pd.Series(prices).rolling(period).mean().values
    std = pd.Series(prices).rolling(period).std().values
    upper = middle + std_dev * std
    lower = middle - std_dev * std
    return upper, middle, lower


def atr(high: np.ndarray, low: np.ndarray, close: np.ndarray, period=14) -> np.ndarray:
    tr = np.maximum(
        high - low,
        np.maximum(
            np.abs(high - np.concatenate([[close[0]], close[:-1]])),
            np.abs(low - np.concatenate([[close[0]], close[:-1]]))
        )
    )
    return pd.Series(tr).ewm(com=period - 1, adjust=False).mean().values


def stochastic(high, low, close, k_period=14, d_period=3):
    lowest_low = pd.Series(low).rolling(k_period).min().values
    highest_high = pd.Series(high).rolling(k_period).max().values
    denom = highest_high - lowest_low
    denom = np.where(denom == 0, 1, denom)
    k = 100 * (close - lowest_low) / denom
    d = pd.Series(k).rolling(d_period).mean().values
    return k, d


# ── Strategies ─────────────────────────────────────────────────────────────────

class TrendFollowingStrategy:
    """EMA crossover + MACD confirmation"""
    name = "Trend Following (EMA/MACD)"

    def analyse(self, prices: np.ndarray, highs, lows) -> dict:
        if len(prices) < 50:
            return {"direction": "HOLD", "confidence": 0, "reasoning": "Insufficient data"}

        ema20 = ema(prices, 20)
        ema50 = ema(prices, 50)
        macd_line, signal_line, hist = macd(prices)
        current_rsi = rsi(prices)[-1]

        bullish_cross = ema20[-1] > ema50[-1] and ema20[-2] <= ema50[-2]
        bearish_cross = ema20[-1] < ema50[-1] and ema20[-2] >= ema50[-2]
        macd_bull = macd_line[-1] > signal_line[-1] and hist[-1] > hist[-2]
        macd_bear = macd_line[-1] < signal_line[-1] and hist[-1] < hist[-2]

        confidence = 0
        direction = "HOLD"
        reasoning = []

        if ema20[-1] > ema50[-1]:
            confidence += 0.3
            reasoning.append("EMA20 above EMA50 (bullish trend)")
        else:
            confidence += 0.3
            reasoning.append("EMA20 below EMA50 (bearish trend)")
            direction = "SELL"

        if bullish_cross:
            confidence += 0.2
            reasoning.append("Fresh bullish EMA crossover")
            direction = "BUY"
        elif bearish_cross:
            confidence += 0.2
            reasoning.append("Fresh bearish EMA crossover")
            direction = "SELL"

        if macd_bull and direction != "SELL":
            confidence += 0.25
            direction = "BUY"
            reasoning.append("MACD bullish momentum")
        elif macd_bear and direction != "BUY":
            confidence += 0.25
            direction = "SELL"
            reasoning.append("MACD bearish momentum")

        if 40 < current_rsi < 60:
            reasoning.append(f"RSI neutral at {current_rsi:.1f}")
        elif current_rsi > 70:
            confidence *= 0.7
            reasoning.append(f"RSI overbought ({current_rsi:.1f}) — reduced confidence")
        elif current_rsi < 30:
            confidence *= 0.7
            reasoning.append(f"RSI oversold ({current_rsi:.1f}) — reduced confidence")

        return {
            "direction": direction,
            "confidence": min(confidence, 0.95),
            "reasoning": "; ".join(reasoning)
        }


class MeanReversionStrategy:
    """Bollinger Band mean reversion + RSI extremes"""
    name = "Mean Reversion (BB/RSI)"

    def analyse(self, prices: np.ndarray, highs, lows) -> dict:
        if len(prices) < 25:
            return {"direction": "HOLD", "confidence": 0, "reasoning": "Insufficient data"}

        upper, middle, lower = bollinger_bands(prices)
        current_rsi = rsi(prices)[-1]
        price = prices[-1]

        direction = "HOLD"
        confidence = 0
        reasoning = []

        bb_width = (upper[-1] - lower[-1]) / middle[-1]
        if bb_width < 0.02:
            reasoning.append("Bands too narrow — low volatility, skipping")
            return {"direction": "HOLD", "confidence": 0, "reasoning": "; ".join(reasoning)}

        if price <= lower[-1]:
            confidence += 0.4
            direction = "BUY"
            reasoning.append(f"Price at lower Bollinger Band ({price:.2f} ≤ {lower[-1]:.2f})")
        elif price >= upper[-1]:
            confidence += 0.4
            direction = "SELL"
            reasoning.append(f"Price at upper Bollinger Band ({price:.2f} ≥ {upper[-1]:.2f})")

        if current_rsi < 30 and direction == "BUY":
            confidence += 0.35
            reasoning.append(f"RSI oversold at {current_rsi:.1f} — confirms buy")
        elif current_rsi > 70 and direction == "SELL":
            confidence += 0.35
            reasoning.append(f"RSI overbought at {current_rsi:.1f} — confirms sell")
        elif current_rsi < 30:
            direction = "BUY"
            confidence += 0.2
            reasoning.append(f"RSI oversold at {current_rsi:.1f}")
        elif current_rsi > 70:
            direction = "SELL"
            confidence += 0.2
            reasoning.append(f"RSI overbought at {current_rsi:.1f}")

        return {
            "direction": direction,
            "confidence": min(confidence, 0.95),
            "reasoning": "; ".join(reasoning)
        }


class BreakoutStrategy:
    """Volatility breakout using ATR + Stochastic"""
    name = "Volatility Breakout (ATR)"

    def analyse(self, prices: np.ndarray, highs, lows) -> dict:
        if len(prices) < 30:
            return {"direction": "HOLD", "confidence": 0, "reasoning": "Insufficient data"}

        closes = prices
        atr_vals = atr(highs, lows, closes)
        current_atr = atr_vals[-1]
        stoch_k, stoch_d = stochastic(highs, lows, closes)

        # Donchian channel (20-period high/low)
        period_high = np.max(highs[-20:])
        period_low = np.min(lows[-20:])
        price = closes[-1]

        direction = "HOLD"
        confidence = 0
        reasoning = []

        # Breakout detection
        if price >= period_high * 0.999:
            direction = "BUY"
            confidence += 0.4
            reasoning.append(f"Price breaking 20-period high ({period_high:.2f})")
        elif price <= period_low * 1.001:
            direction = "SELL"
            confidence += 0.4
            reasoning.append(f"Price breaking 20-period low ({period_low:.2f})")

        # ATR expansion confirms breakout
        avg_atr = np.mean(atr_vals[-10:])
        if current_atr > avg_atr * 1.2:
            confidence += 0.2
            reasoning.append(f"ATR expanding ({current_atr:.4f} > avg {avg_atr:.4f}) — momentum confirmed")

        # Stochastic confirmation
        if stoch_k[-1] > 80 and direction == "BUY":
            confidence += 0.2
            reasoning.append("Stochastic %K strong (>80) confirms upside momentum")
        elif stoch_k[-1] < 20 and direction == "SELL":
            confidence += 0.2
            reasoning.append("Stochastic %K weak (<20) confirms downside momentum")

        return {
            "direction": direction,
            "confidence": min(confidence, 0.9),
            "reasoning": "; ".join(reasoning)
        }


class FundamentalOverlayStrategy:
    """
    Fundamental signal overlay based on commodity-specific factors.
    In production this would pull EIA inventory data, COT reports, etc.
    For demo: simulates fundamental bias from news sentiment + seasonal factors.
    """
    name = "Fundamental Overlay"

    SEASONAL_BIAS = {
        # month: {instrument: bias}
        1:  {"NATGAS": 0.6, "WTI": 0.1, "BRENT": 0.1, "GOLD": 0.3, "SILVER": 0.1},
        2:  {"NATGAS": 0.5, "WTI": 0.2, "BRENT": 0.2, "GOLD": 0.3, "SILVER": 0.1},
        6:  {"WTI": 0.5, "BRENT": 0.5, "NATGAS": -0.1, "GOLD": 0.0, "SILVER": 0.0},
        7:  {"WTI": 0.4, "BRENT": 0.4, "NATGAS": -0.1, "GOLD": 0.1, "SILVER": 0.0},
        11: {"NATGAS": 0.4, "GOLD": 0.4, "WTI": 0.0, "BRENT": 0.0, "SILVER": 0.2},
        12: {"NATGAS": 0.5, "GOLD": 0.3, "WTI": 0.1, "BRENT": 0.1, "SILVER": 0.2},
    }

    def analyse(self, instrument: str, prices: np.ndarray) -> dict:
        month = datetime.now().month
        bias = self.SEASONAL_BIAS.get(month, {}).get(instrument, 0.0)

        reasoning = []
        direction = "HOLD"
        confidence = abs(bias) * 0.5

        if bias > 0.2:
            direction = "BUY"
            reasoning.append(f"Seasonal fundamental bias bullish for {instrument} in month {month}")
        elif bias < -0.2:
            direction = "SELL"
            reasoning.append(f"Seasonal fundamental bias bearish for {instrument} in month {month}")
        else:
            reasoning.append(f"Neutral fundamental backdrop for {instrument}")

        # Dollar strength proxy (inverse for commodities)
        # In production: pull DXY from OANDA
        dxy_proxy = 0.0  # placeholder
        if dxy_proxy > 0:
            if instrument in ["GOLD", "SILVER", "WTI", "BRENT"]:
                confidence *= 0.8
                reasoning.append("USD strength headwind for commodities")

        return {
            "direction": direction,
            "confidence": confidence,
            "reasoning": "; ".join(reasoning) if reasoning else "No strong fundamental signal"
        }


# ── Strategy Combiner ──────────────────────────────────────────────────────────

class StrategyAggregator:
    """Combines multiple strategies with weighted voting"""

    def __init__(self):
        self.trend = TrendFollowingStrategy()
        self.reversion = MeanReversionStrategy()
        self.breakout = BreakoutStrategy()
        self.fundamental = FundamentalOverlayStrategy()

    def get_signal(self, instrument: str, prices: np.ndarray,
                   highs: np.ndarray, lows: np.ndarray, current_price: float) -> Signal:

        results = {
            "Trend Following": self.trend.analyse(prices, highs, lows),
            "Mean Reversion":  self.reversion.analyse(prices, highs, lows),
            "Breakout":        self.breakout.analyse(prices, highs, lows),
            "Fundamental":     self.fundamental.analyse(instrument, prices),
        }

        # Weighted vote
        weights = {"Trend Following": 0.35, "Mean Reversion": 0.25,
                   "Breakout": 0.25, "Fundamental": 0.15}

        buy_score = 0
        sell_score = 0
        best_strategy = "Trend Following"
        best_conf = 0

        for name, result in results.items():
            w = weights[name]
            if result["direction"] == "BUY":
                buy_score += result["confidence"] * w
            elif result["direction"] == "SELL":
                sell_score += result["confidence"] * w

            if result["confidence"] > best_conf:
                best_conf = result["confidence"]
                best_strategy = name

        final_direction = "HOLD"
        final_confidence = 0

        if buy_score > sell_score and buy_score > 0.2:
            final_direction = "BUY"
            final_confidence = buy_score
        elif sell_score > buy_score and sell_score > 0.2:
            final_direction = "SELL"
            final_confidence = sell_score

        # Position sizing via ATR-based stops
        inst_config = INSTRUMENTS[instrument]
        atr_vals = atr(highs, lows, prices)
        current_atr = atr_vals[-1]

        if final_direction == "BUY":
            stop_loss   = current_price - 2.0 * current_atr
            take_profit = current_price + 3.0 * current_atr
        elif final_direction == "SELL":
            stop_loss   = current_price + 2.0 * current_atr
            take_profit = current_price - 3.0 * current_atr
        else:
            stop_loss   = current_price * 0.98
            take_profit = current_price * 1.02

        all_reasoning = " | ".join(
            f"[{name}] {r['reasoning']}"
            for name, r in results.items()
            if r["direction"] != "HOLD"
        ) or "No strong directional signal across strategies"

        return Signal(
            instrument   = instrument,
            direction    = final_direction,
            strategy     = best_strategy,
            confidence   = round(final_confidence, 3),
            entry_price  = current_price,
            stop_loss    = round(stop_loss, 4),
            take_profit  = round(take_profit, 4),
            reasoning    = all_reasoning,
            timestamp    = datetime.utcnow().isoformat()
        )
