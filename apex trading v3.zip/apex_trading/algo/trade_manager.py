"""
Trade Manager — Position sizing, risk management, portfolio state
"""

import uuid
import json
import math
from datetime import datetime
from typing import Dict, List, Optional
from dataclasses import dataclass, asdict

from algo.engine import Signal, Trade, INSTRUMENTS


MAX_RISK_PER_TRADE  = 0.01   # 1% of account per trade
MAX_OPEN_POSITIONS  = 5
MIN_CONFIDENCE      = 0.30   # minimum signal confidence to trade


class TradeManager:
    def __init__(self, account_balance: float = 100_000):
        self.balance         = account_balance
        self.open_trades: Dict[str, Trade] = {}
        self.closed_trades:  List[Trade]   = []
        self.daily_pnl       = 0.0
        self.total_pnl       = 0.0
        self.trade_log:      List[dict]    = []

    # ── Position Sizing ────────────────────────────────────────────────────────

    def calculate_units(self, instrument: str, entry: float,
                        stop_loss: float, balance: float) -> int:
        """Kelly-inspired position sizing capped at max risk"""
        risk_amount = balance * MAX_RISK_PER_TRADE
        price_risk  = abs(entry - stop_loss)
        if price_risk == 0:
            return 0
        raw_units = risk_amount / price_risk
        # Apply instrument minimum/maximum
        inst_min = INSTRUMENTS[instrument]["units"]
        return max(inst_min, int(math.floor(raw_units / inst_min) * inst_min))

    # ── Trade Execution ────────────────────────────────────────────────────────

    def should_trade(self, signal: Signal) -> tuple[bool, str]:
        if signal.direction == "HOLD":
            return False, "Signal is HOLD"
        if signal.confidence < MIN_CONFIDENCE:
            return False, f"Confidence {signal.confidence:.1%} below threshold {MIN_CONFIDENCE:.1%}"
        if len(self.open_trades) >= MAX_OPEN_POSITIONS:
            return False, f"Max open positions ({MAX_OPEN_POSITIONS}) reached"
        # Don't double up on same instrument
        for t in self.open_trades.values():
            if t.instrument == signal.instrument:
                return False, f"Already have open position in {signal.instrument}"
        return True, "OK"

    def open_trade(self, signal: Signal, fill_price: float) -> Optional[Trade]:
        ok, reason = self.should_trade(signal)
        if not ok:
            self._log(f"SKIP {signal.instrument} {signal.direction}: {reason}")
            return None

        units = self.calculate_units(
            signal.instrument, fill_price, signal.stop_loss, self.balance
        )
        if units == 0:
            return None

        trade = Trade(
            id            = str(uuid.uuid4())[:8].upper(),
            instrument    = signal.instrument,
            direction     = signal.direction,
            units         = units,
            entry_price   = fill_price,
            current_price = fill_price,
            stop_loss     = signal.stop_loss,
            take_profit   = signal.take_profit,
            open_time     = datetime.utcnow().isoformat(),
            strategy      = signal.strategy,
            unrealised_pnl = 0.0,
            status        = "OPEN",
        )
        self.open_trades[trade.id] = trade
        self._log(f"OPEN {trade.direction} {trade.instrument} @ {fill_price:.4f} | "
                  f"Units: {units} | SL: {signal.stop_loss:.4f} | TP: {signal.take_profit:.4f} | "
                  f"Strategy: {signal.strategy} | Confidence: {signal.confidence:.1%}")
        return trade

    def update_prices(self, prices: Dict[str, float]):
        """Update unrealised P&L for all open trades"""
        for trade in self.open_trades.values():
            price = prices.get(trade.instrument)
            if price is None:
                continue
            trade.current_price = price
            if trade.direction == "BUY":
                trade.unrealised_pnl = (price - trade.entry_price) * trade.units
            else:
                trade.unrealised_pnl = (trade.entry_price - price) * trade.units

            # Check stop/take profit
            if trade.direction == "BUY":
                if price <= trade.stop_loss:
                    self._close_trade(trade.id, price, "STOP_LOSS")
                elif price >= trade.take_profit:
                    self._close_trade(trade.id, price, "TAKE_PROFIT")
            else:
                if price >= trade.stop_loss:
                    self._close_trade(trade.id, price, "STOP_LOSS")
                elif price <= trade.take_profit:
                    self._close_trade(trade.id, price, "TAKE_PROFIT")

    def _close_trade(self, trade_id: str, close_price: float, reason: str):
        trade = self.open_trades.pop(trade_id, None)
        if trade is None:
            return
        if trade.direction == "BUY":
            pnl = (close_price - trade.entry_price) * trade.units
        else:
            pnl = (trade.entry_price - close_price) * trade.units

        trade.status       = "CLOSED"
        trade.close_price  = close_price
        trade.close_time   = datetime.utcnow().isoformat()
        trade.realised_pnl = round(pnl, 2)
        trade.unrealised_pnl = 0.0

        self.balance    += pnl
        self.daily_pnl  += pnl
        self.total_pnl  += pnl
        self.closed_trades.append(trade)

        self._log(f"CLOSE {trade.direction} {trade.instrument} @ {close_price:.4f} | "
                  f"Reason: {reason} | P&L: ${pnl:+.2f}")

    def manual_close(self, trade_id: str, close_price: float):
        self._close_trade(trade_id, close_price, "MANUAL")

    def reset_daily_pnl(self):
        self.daily_pnl = 0.0

    # ── Portfolio Stats ────────────────────────────────────────────────────────

    def get_portfolio_stats(self) -> dict:
        open_pnl = sum(t.unrealised_pnl for t in self.open_trades.values())
        wins  = [t for t in self.closed_trades if (t.realised_pnl or 0) > 0]
        losses= [t for t in self.closed_trades if (t.realised_pnl or 0) <= 0]
        win_rate = len(wins) / len(self.closed_trades) if self.closed_trades else 0

        avg_win  = sum(t.realised_pnl for t in wins)  / len(wins)  if wins  else 0
        avg_loss = sum(t.realised_pnl for t in losses) / len(losses) if losses else 0
        profit_factor = abs(avg_win / avg_loss) if avg_loss != 0 else 0

        return {
            "balance":        round(self.balance, 2),
            "total_pnl":      round(self.total_pnl, 2),
            "daily_pnl":      round(self.daily_pnl, 2),
            "unrealised_pnl": round(open_pnl, 2),
            "nav":            round(self.balance + open_pnl, 2),
            "open_trades":    len(self.open_trades),
            "closed_trades":  len(self.closed_trades),
            "win_rate":       round(win_rate * 100, 1),
            "profit_factor":  round(profit_factor, 2),
            "total_trades":   len(self.closed_trades),
        }

    def get_open_trades_list(self) -> list:
        return [asdict(t) for t in self.open_trades.values()]

    def get_recent_closed(self, n: int = 20) -> list:
        return [asdict(t) for t in self.closed_trades[-n:]]

    def _log(self, message: str):
        entry = {"time": datetime.utcnow().isoformat(), "message": message}
        self.trade_log.append(entry)
        print(f"[APEX] {entry['time']} | {message}")

    def get_log(self, n: int = 50) -> list:
        return self.trade_log[-n:]
