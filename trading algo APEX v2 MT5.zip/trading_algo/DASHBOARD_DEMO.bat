@echo off
title APEX Dashboard - Demo Mode
color 0B
echo.
echo  ^^  Starting APEX Dashboard (Demo Mode)...
echo  (No API connection needed)
echo.
python main.py --dashboard
pause
