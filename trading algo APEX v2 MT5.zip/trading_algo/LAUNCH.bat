@echo off
title APEX Trading System
color 0B

echo.
echo  ^^  Starting APEX Trading System...
echo.

REM Launch full system (engine + dashboard)
python main.py

if %errorlevel% neq 0 (
    echo.
    echo  [ERROR] Failed to start. Run INSTALL.bat first.
    pause
)
