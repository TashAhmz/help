"""
APEX TRADING SYSTEM - MT5 Configuration
=========================================
Fill in your Vantage MT5 credentials here.

WHERE TO FIND THESE:
  1. Open MetaTrader 5
  2. File → Open Account (or your account details top-left)
  3. Server name is shown in the login screen
  4. Login is your account number (numeric)
"""

# ─────────────────────────────────────────────
# YOUR VANTAGE MT5 LOGIN DETAILS
# ─────────────────────────────────────────────
MT5_LOGIN    = 0              # ← Your numeric account number e.g. 12345678
MT5_PASSWORD = "YOUR_MT5_PASSWORD"   # ← Your MT5 password
MT5_SERVER   = "VantageInternational-Live"  # ← Server name from MT5 login screen
                                            #    Common Vantage servers:
                                            #    "VantageInternational-Live"
                                            #    "VantageInternational-Demo"
                                            #    "Vantage-Live"
                                            #    (check your MT5 login screen)

# ─────────────────────────────────────────────
# MT5 TERMINAL PATH (usually auto-detected)
# ─────────────────────────────────────────────
# Leave as None to auto-detect. Only set this if auto-detection fails.
# Example: r"C:\Program Files\Vantage MT5\terminal64.exe"
MT5_PATH = None

# ─────────────────────────────────────────────
# CONNECTION MODE
# ─────────────────────────────────────────────
# "mt5"  → Use MT5 connector (recommended for Vantage)
# "rest" → Use Vantage REST API (requires separate API key)
# "auto" → Try MT5 first, fall back to REST API
CONNECTION_MODE = "mt5"

# ─────────────────────────────────────────────
# VANTAGE MT5 SYMBOL NAMES
# ─────────────────────────────────────────────
# Different brokers use different symbol names.
# Open MT5 → View → Symbols to find exact names on your account.
# Update these if they don't match.
SYMBOL_OVERRIDES = {
    # "USOIL": "WTI",     # Uncomment if your broker uses "WTI" instead of "USOIL"
    # "UKOIL": "BRENT",   # Uncomment if your broker uses "BRENT" instead of "UKOIL"
    # "XAUUSD": "GOLD",   # Uncomment if your broker uses "GOLD"
}
