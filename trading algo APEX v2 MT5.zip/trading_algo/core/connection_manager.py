"""
APEX TRADING SYSTEM - Connection Manager
==========================================
Automatically selects the best connection method:
  1. MT5 (preferred — works with Vantage immediately)
  2. Vantage REST API (if you get API access)
  3. Paper trading mode (no connection needed)

Usage in trading_engine.py:
    from core.connection_manager import get_api_connector
    self.api = get_api_connector(mode=self.mode)
"""

import logging
from config.mt5_config import CONNECTION_MODE

logger = logging.getLogger(__name__)


def get_api_connector(mode: str = "paper"):
    """
    Returns the best available API connector.
    Priority: MT5 > REST API > Paper-only fallback
    """
    if CONNECTION_MODE == "mt5":
        return _try_mt5(mode)

    elif CONNECTION_MODE == "rest":
        return _try_rest(mode)

    elif CONNECTION_MODE == "auto":
        # Try MT5 first
        connector = _try_mt5(mode)
        if connector and connector.connected:
            return connector

        # Fall back to REST
        logger.warning("MT5 unavailable — trying REST API...")
        connector = _try_rest(mode)
        if connector:
            return connector

        # Final fallback
        logger.warning("REST API unavailable — running in paper-only mode")
        return _paper_fallback(mode)

    else:
        logger.warning(f"Unknown CONNECTION_MODE: {CONNECTION_MODE} — using paper mode")
        return _paper_fallback(mode)


def _try_mt5(mode: str):
    """Attempt to connect via MT5."""
    try:
        from core.mt5_connector import MT5Connector
        connector = MT5Connector(mode=mode)
        if connector.connected or mode == "paper":
            logger.info(f"✅ Using MT5 connector | Mode: {mode.upper()}")
            return connector
        else:
            logger.warning("MT5 connector created but not connected")
            return connector  # Return anyway — will use paper simulation
    except Exception as e:
        logger.error(f"MT5 connector failed: {e}")
        return None


def _try_rest(mode: str):
    """Attempt to connect via Vantage REST API."""
    try:
        from config.config import VANTAGE_API_KEY
        if VANTAGE_API_KEY == "YOUR_VANTAGE_API_KEY":
            logger.warning("Vantage REST API key not configured")
            return None

        from core.vantage_api import VantageAPI
        connector = VantageAPI(mode=mode)
        logger.info(f"✅ Using Vantage REST API | Mode: {mode.upper()}")
        return connector
    except Exception as e:
        logger.error(f"REST API connector failed: {e}")
        return None


def _paper_fallback(mode: str):
    """Paper trading fallback — no real broker connection."""
    from core.mt5_connector import MT5Connector
    connector = MT5Connector(mode="paper")
    connector.connected = False
    logger.info("⚠️  Running in PAPER mode only (no broker connection)")
    return connector


def print_connection_status(connector):
    """Print a nice summary of the connection."""
    connector_type = type(connector).__name__

    if hasattr(connector, 'connected') and connector.connected:
        info = connector.get_account_info()
        if info:
            print(f"""
╔══════════════════════════════════════════════╗
║  ✅ BROKER CONNECTED                         ║
╠══════════════════════════════════════════════╣
║  Connector : {connector_type:<30} ║
║  Account   : {str(info.get('login', 'N/A')):<30} ║
║  Balance   : ${info.get('balance', 0):>28,.2f} ║
║  Equity    : ${info.get('equity', 0):>28,.2f} ║
║  Server    : {str(info.get('server', 'N/A')):<30} ║
╚══════════════════════════════════════════════╝
""")
    else:
        print(f"""
╔══════════════════════════════════════════════╗
║  📝 PAPER TRADING MODE                       ║
╠══════════════════════════════════════════════╣
║  No broker connection — simulated trades     ║
║  Configure MT5 in config/mt5_config.py       ║
╚══════════════════════════════════════════════╝
""")
