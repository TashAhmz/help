"""
APEX TRADING SYSTEM - MT4/MT5 Connector
=========================================
Connects to Vantage Markets via MetaTrader 5 Python library.
This is the PRIMARY connection method for retail brokers.

HOW IT WORKS:
  - MetaTrader5 Python library communicates directly with your
    MT4/MT5 terminal installed on your PC
  - No REST API key needed — uses your MT4/MT5 login credentials
  - Full support for: prices, orders, positions, history

SETUP:
  1. Download MetaTrader 5 from Vantage:
     → Login to vantagemarkets.com → Download MT5
  2. Install MT5 and log in with your Vantage account
  3. Keep MT5 running in the background
  4. pip install MetaTrader5
  5. Set MT5_LOGIN, MT5_PASSWORD, MT5_SERVER in config.py
  6. Run APEX — it will auto-connect to MT5
"""

import time
import logging
import numpy as np
import pandas as pd
from datetime import datetime, timedelta
from typing import Optional, Dict, List
from dataclasses import dataclass

logger = logging.getLogger(__name__)

# MT5 symbol mapping — Vantage uses these exact symbol names
# Verify in MT5 under View → Symbols
VANTAGE_MT5_SYMBOLS = {
    "XAUUSD": "XAUUSD",      # Gold
    "XAGUSD": "XAGUSD",      # Silver
    "USOIL":  "USOIL",       # WTI Crude (may be "WTI" or "OIL" on some brokers)
    "UKOIL":  "UKOIL",       # Brent Crude (may be "BRENT" or "UKOil")
    "NGAS":   "NGAS",        # Natural Gas
    "HEAT":   "HEAT",        # Heating Oil
    "RBOB":   "RBOB",        # RBOB Gasoline
    "CARBON": "CARBON",      # Carbon Credits (if available)
}

# MT5 timeframe constants
MT5_TIMEFRAMES = {
    "1m":  1,
    "5m":  5,
    "15m": 15,
    "30m": 30,
    "1h":  16385,
    "4h":  16388,
    "1d":  16408,
    "1w":  32769,
}


class MT5Connector:
    """
    Full MetaTrader 5 connector.
    Drop-in replacement for VantageAPI — same method signatures.
    """

    def __init__(self, mode: str = "paper"):
        self.mode = mode
        self.connected = False
        self.mt5 = None
        self.account_info_cache = None
        self._connect()

    def _connect(self):
        """Initialize connection to MT5 terminal."""
        try:
            import MetaTrader5 as mt5
            self.mt5 = mt5
        except ImportError:
            logger.error(
                "MetaTrader5 library not installed!\n"
                "Run: pip install MetaTrader5\n"
                "NOTE: Only works on Windows with MT5 installed."
            )
            return

        from config.mt5_config import MT5_LOGIN, MT5_PASSWORD, MT5_SERVER, MT5_PATH

        # Initialize MT5
        if MT5_PATH:
            initialized = self.mt5.initialize(
                path=MT5_PATH,
                login=MT5_LOGIN,
                password=MT5_PASSWORD,
                server=MT5_SERVER
            )
        else:
            initialized = self.mt5.initialize(
                login=MT5_LOGIN,
                password=MT5_PASSWORD,
                server=MT5_SERVER
            )

        if not initialized:
            error = self.mt5.last_error()
            logger.error(
                f"MT5 initialization failed: {error}\n"
                "Make sure:\n"
                "  1. MT5 terminal is installed and running\n"
                "  2. Correct login/password/server in config/mt5_config.py\n"
                "  3. AutoTrading is enabled in MT5 (green button in toolbar)"
            )
            return

        # Verify connection
        account = self.mt5.account_info()
        if account is None:
            logger.error("MT5 connected but cannot get account info")
            return

        self.connected = True
        logger.info(
            f"✅ MT5 Connected | Account: {account.login} | "
            f"Server: {account.server} | "
            f"Balance: ${account.balance:,.2f} | "
            f"Leverage: 1:{account.leverage}"
        )

        # Enable symbols
        self._enable_symbols()

    def _enable_symbols(self):
        """Make sure all our symbols are visible in MT5."""
        if not self.connected:
            return
        for apex_sym, mt5_sym in VANTAGE_MT5_SYMBOLS.items():
            if not self.mt5.symbol_select(mt5_sym, True):
                logger.warning(f"Could not enable symbol: {mt5_sym} "
                               f"(may not be available on your account)")

    def _get_mt5_symbol(self, apex_symbol: str) -> str:
        """Map APEX symbol name to MT5 symbol name."""
        return VANTAGE_MT5_SYMBOLS.get(apex_symbol, apex_symbol)

    # ─────────────────────────────────────────────
    # ACCOUNT
    # ─────────────────────────────────────────────

    def get_account_info(self) -> Optional[Dict]:
        """Get account balance, equity, margin."""
        if not self.connected:
            return self._paper_account()
        try:
            acc = self.mt5.account_info()
            if acc:
                info = {
                    "login": acc.login,
                    "balance": float(acc.balance),
                    "equity": float(acc.equity),
                    "margin": float(acc.margin),
                    "free_margin": float(acc.margin_free),
                    "margin_level": float(acc.margin_level),
                    "profit": float(acc.profit),
                    "currency": acc.currency,
                    "leverage": acc.leverage,
                    "server": acc.server
                }
                self.account_info_cache = info
                return info
        except Exception as e:
            logger.error(f"MT5 account info error: {e}")
        return self.account_info_cache

    def get_account_balance(self) -> float:
        info = self.get_account_info()
        return float(info.get("balance", 0)) if info else 0.0

    def get_equity(self) -> float:
        info = self.get_account_info()
        return float(info.get("equity", 0)) if info else 0.0

    # ─────────────────────────────────────────────
    # MARKET DATA
    # ─────────────────────────────────────────────

    def get_price(self, symbol: str) -> Optional[Dict]:
        """Get current bid/ask for a symbol."""
        if not self.connected:
            return None
        try:
            mt5_sym = self._get_mt5_symbol(symbol)
            tick = self.mt5.symbol_info_tick(mt5_sym)
            if tick:
                return {
                    "symbol": symbol,
                    "bid": float(tick.bid),
                    "ask": float(tick.ask),
                    "price": float((tick.bid + tick.ask) / 2),
                    "spread": float(tick.ask - tick.bid),
                    "time": tick.time
                }
        except Exception as e:
            logger.error(f"MT5 price error for {symbol}: {e}")
        return None

    def get_prices_bulk(self, symbols: List[str]) -> Optional[Dict]:
        """Get prices for multiple symbols."""
        result = {}
        for symbol in symbols:
            price = self.get_price(symbol)
            if price:
                result[symbol] = price
        return result

    def get_ohlcv(self, symbol: str, timeframe: str = "1h",
                  limit: int = 500) -> Optional[List[Dict]]:
        """Get OHLCV candlestick data from MT5."""
        if not self.connected:
            return None
        try:
            mt5_sym = self._get_mt5_symbol(symbol)
            tf = MT5_TIMEFRAMES.get(timeframe, 16385)  # Default 1h

            # Get rates from MT5
            rates = self.mt5.copy_rates_from_pos(mt5_sym, tf, 0, limit)
            if rates is None or len(rates) == 0:
                logger.warning(f"No MT5 data for {symbol} {timeframe}")
                return None

            candles = []
            for r in rates:
                candles.append({
                    "timestamp": int(r["time"]),
                    "open":  float(r["open"]),
                    "high":  float(r["high"]),
                    "low":   float(r["low"]),
                    "close": float(r["close"]),
                    "volume": float(r["tick_volume"])
                })
            return candles

        except Exception as e:
            logger.error(f"MT5 OHLCV error for {symbol}: {e}")
            return None

    def get_orderbook(self, symbol: str, depth: int = 20) -> Optional[Dict]:
        """Get market depth (order book) from MT5."""
        if not self.connected:
            return None
        try:
            mt5_sym = self._get_mt5_symbol(symbol)
            if self.mt5.market_book_add(mt5_sym):
                book = self.mt5.market_book_get(mt5_sym)
                if book:
                    return {
                        "bids": [{"price": b.price, "volume": b.volume}
                                 for b in book if b.type == 1],
                        "asks": [{"price": b.price, "volume": b.volume}
                                 for b in book if b.type == 2]
                    }
        except Exception as e:
            logger.error(f"MT5 orderbook error: {e}")
        return None

    # ─────────────────────────────────────────────
    # TRADING
    # ─────────────────────────────────────────────

    def place_order(self, symbol: str, side: str, order_type: str,
                    volume: float, price: float = None,
                    stop_loss: float = None, take_profit: float = None,
                    comment: str = "APEX") -> Optional[Dict]:
        """
        Place a trade via MT5.
        """
        if self.mode == "paper":
            return self._simulate_order(symbol, side, order_type, volume,
                                        price, stop_loss, take_profit)

        if not self.connected:
            logger.error("MT5 not connected — cannot place order")
            return None

        try:
            mt5_sym = self._get_mt5_symbol(symbol)
            sym_info = self.mt5.symbol_info(mt5_sym)
            if sym_info is None:
                logger.error(f"Symbol {mt5_sym} not found in MT5")
                return None

            # Get current price
            tick = self.mt5.symbol_info_tick(mt5_sym)
            if tick is None:
                logger.error(f"Cannot get tick for {mt5_sym}")
                return None

            # Determine order type and price
            if side.lower() == "buy":
                mt5_order_type = self.mt5.ORDER_TYPE_BUY
                execution_price = tick.ask
            else:
                mt5_order_type = self.mt5.ORDER_TYPE_SELL
                execution_price = tick.bid

            if order_type == "limit" and price:
                mt5_order_type = (self.mt5.ORDER_TYPE_BUY_LIMIT
                                  if side == "buy"
                                  else self.mt5.ORDER_TYPE_SELL_LIMIT)
                execution_price = price

            # Build request
            request = {
                "action":      self.mt5.TRADE_ACTION_DEAL,
                "symbol":      mt5_sym,
                "volume":      float(volume),
                "type":        mt5_order_type,
                "price":       execution_price,
                "deviation":   20,        # Max slippage in points
                "magic":       20240101,  # APEX magic number
                "comment":     comment,
                "type_time":   self.mt5.ORDER_TIME_GTC,
                "type_filling": self.mt5.ORDER_FILLING_IOC,
            }

            if stop_loss:
                request["sl"] = float(stop_loss)
            if take_profit:
                request["tp"] = float(take_profit)

            # Send order
            result = self.mt5.order_send(request)

            if result is None:
                logger.error(f"MT5 order_send returned None for {symbol}")
                return None

            if result.retcode == self.mt5.TRADE_RETCODE_DONE:
                logger.info(
                    f"✅ MT5 Order filled: {side.upper()} {volume} {symbol} "
                    f"@ {result.price:.5f} | Ticket: {result.order}"
                )
                return {
                    "id": str(result.order),
                    "ticket": result.order,
                    "symbol": symbol,
                    "side": side,
                    "volume": volume,
                    "price": result.price,
                    "stopLoss": stop_loss,
                    "takeProfit": take_profit,
                    "status": "filled",
                    "timestamp": datetime.now().isoformat()
                }
            else:
                error_desc = self._get_error_description(result.retcode)
                logger.error(
                    f"MT5 Order failed: {symbol} | "
                    f"Code: {result.retcode} | {error_desc} | "
                    f"Comment: {result.comment}"
                )
                return None

        except Exception as e:
            logger.error(f"MT5 place_order exception: {e}", exc_info=True)
            return None

    def close_position(self, position_id: str, volume: float = None) -> Optional[Dict]:
        """Close a position by ticket number."""
        if self.mode == "paper":
            return {"status": "closed", "id": position_id}

        if not self.connected:
            return None

        try:
            ticket = int(position_id)
            position = None

            # Find the position
            positions = self.mt5.positions_get()
            if positions:
                for p in positions:
                    if p.ticket == ticket:
                        position = p
                        break

            if not position:
                logger.warning(f"Position {ticket} not found")
                return None

            mt5_sym = position.symbol
            close_volume = volume or position.volume
            tick = self.mt5.symbol_info_tick(mt5_sym)

            # Opposite direction to close
            if position.type == 0:  # Long
                close_type = self.mt5.ORDER_TYPE_SELL
                close_price = tick.bid
            else:  # Short
                close_type = self.mt5.ORDER_TYPE_BUY
                close_price = tick.ask

            request = {
                "action":      self.mt5.TRADE_ACTION_DEAL,
                "symbol":      mt5_sym,
                "volume":      float(close_volume),
                "type":        close_type,
                "position":    ticket,
                "price":       close_price,
                "deviation":   20,
                "magic":       20240101,
                "comment":     "APEX_CLOSE",
                "type_time":   self.mt5.ORDER_TIME_GTC,
                "type_filling": self.mt5.ORDER_FILLING_IOC,
            }

            result = self.mt5.order_send(request)
            if result and result.retcode == self.mt5.TRADE_RETCODE_DONE:
                logger.info(f"Position {ticket} closed @ {result.price}")
                return {"status": "closed", "id": position_id, "price": result.price}
            else:
                logger.error(f"Close failed: {result.retcode if result else 'None'}")
                return None

        except Exception as e:
            logger.error(f"MT5 close_position error: {e}")
            return None

    def modify_order(self, order_id: str, stop_loss: float = None,
                     take_profit: float = None) -> Optional[Dict]:
        """Modify SL/TP of an open position."""
        if self.mode == "paper":
            return {"status": "modified", "id": order_id}

        if not self.connected:
            return None

        try:
            ticket = int(order_id)
            positions = self.mt5.positions_get()
            position = None
            if positions:
                for p in positions:
                    if p.ticket == ticket:
                        position = p
                        break

            if not position:
                return None

            request = {
                "action":   self.mt5.TRADE_ACTION_SLTP,
                "symbol":   position.symbol,
                "position": ticket,
                "sl":       float(stop_loss) if stop_loss else position.sl,
                "tp":       float(take_profit) if take_profit else position.tp,
            }

            result = self.mt5.order_send(request)
            if result and result.retcode == self.mt5.TRADE_RETCODE_DONE:
                return {"status": "modified", "id": order_id}
            return None

        except Exception as e:
            logger.error(f"MT5 modify_order error: {e}")
            return None

    def cancel_order(self, order_id: str) -> Optional[Dict]:
        """Cancel a pending order."""
        if self.mode == "paper":
            return {"status": "cancelled", "id": order_id}

        if not self.connected:
            return None

        try:
            request = {
                "action": self.mt5.TRADE_ACTION_REMOVE,
                "order":  int(order_id),
            }
            result = self.mt5.order_send(request)
            if result and result.retcode == self.mt5.TRADE_RETCODE_DONE:
                return {"status": "cancelled", "id": order_id}
            return None
        except Exception as e:
            logger.error(f"MT5 cancel_order error: {e}")
            return None

    # ─────────────────────────────────────────────
    # POSITIONS & HISTORY
    # ─────────────────────────────────────────────

    def get_open_positions(self) -> List[Dict]:
        """Get all open positions from MT5."""
        if not self.connected:
            return []
        try:
            positions = self.mt5.positions_get()
            if not positions:
                return []

            result = []
            for p in positions:
                # Only return positions opened by APEX (magic number check)
                result.append({
                    "id":           str(p.ticket),
                    "ticket":       p.ticket,
                    "symbol":       p.symbol,
                    "side":         "buy" if p.type == 0 else "sell",
                    "volume":       float(p.volume),
                    "entry_price":  float(p.price_open),
                    "current_price": float(p.price_current),
                    "stop_loss":    float(p.sl),
                    "take_profit":  float(p.tp),
                    "profit":       float(p.profit),
                    "unrealized_pnl": float(p.profit),
                    "swap":         float(p.swap),
                    "comment":      p.comment,
                    "magic":        p.magic,
                    "open_time":    datetime.fromtimestamp(p.time).isoformat()
                })
            return result

        except Exception as e:
            logger.error(f"MT5 get_open_positions error: {e}")
            return []

    def get_pending_orders(self) -> List[Dict]:
        """Get all pending orders."""
        if not self.connected:
            return []
        try:
            orders = self.mt5.orders_get()
            if not orders:
                return []
            return [{"id": str(o.ticket), "symbol": o.symbol,
                     "type": o.type, "volume": o.volume_current,
                     "price": o.price_open, "sl": o.sl, "tp": o.tp}
                    for o in orders]
        except Exception as e:
            logger.error(f"MT5 pending orders error: {e}")
            return []

    def get_trade_history(self, from_date: datetime = None,
                          to_date: datetime = None) -> List[Dict]:
        """Get closed trade history from MT5."""
        if not self.connected:
            return []
        try:
            if not from_date:
                from_date = datetime.now() - timedelta(days=30)
            if not to_date:
                to_date = datetime.now()

            deals = self.mt5.history_deals_get(from_date, to_date)
            if not deals:
                return []

            trades = []
            for d in deals:
                if d.entry == 1:  # Entry 1 = close deal
                    trades.append({
                        "id":          str(d.ticket),
                        "symbol":      d.symbol,
                        "side":        "buy" if d.type == 0 else "sell",
                        "volume":      float(d.volume),
                        "entry_price": float(d.price),
                        "profit":      float(d.profit),
                        "commission":  float(d.commission),
                        "swap":        float(d.swap),
                        "closed_at":   datetime.fromtimestamp(d.time).isoformat(),
                        "comment":     d.comment
                    })
            return trades

        except Exception as e:
            logger.error(f"MT5 trade history error: {e}")
            return []

    def get_daily_pnl(self) -> float:
        """Get today's realized P&L."""
        today = datetime.now().replace(hour=0, minute=0, second=0, microsecond=0)
        trades = self.get_trade_history(from_date=today)
        return sum(float(t.get("profit", 0)) for t in trades)

    # ─────────────────────────────────────────────
    # PAPER TRADING SIMULATION
    # ─────────────────────────────────────────────

    def _simulate_order(self, symbol, side, order_type, volume,
                        price, stop_loss, take_profit) -> Dict:
        """Paper trade simulation."""
        import uuid
        order_id = str(uuid.uuid4())[:8].upper()
        logger.info(f"[PAPER/MT5] {side.upper()} {volume} {symbol} | "
                    f"SL={stop_loss} TP={take_profit}")
        return {
            "id": order_id,
            "symbol": symbol,
            "side": side,
            "volume": volume,
            "type": order_type,
            "price": price or 0,
            "stopLoss": stop_loss,
            "takeProfit": take_profit,
            "status": "filled",
            "timestamp": datetime.now().isoformat(),
            "paper": True
        }

    def _paper_account(self) -> Dict:
        return {
            "balance": 10000.0,
            "equity": 10000.0,
            "margin": 0.0,
            "free_margin": 10000.0,
            "profit": 0.0
        }

    # ─────────────────────────────────────────────
    # HELPERS
    # ─────────────────────────────────────────────

    def _get_error_description(self, retcode: int) -> str:
        """Human-readable MT5 error codes."""
        errors = {
            10004: "Requote",
            10006: "Request rejected",
            10007: "Request cancelled by trader",
            10008: "Order placed",
            10009: "Request completed",
            10010: "Only part of the request completed",
            10011: "Request processing error",
            10012: "Request timeout",
            10013: "Invalid request",
            10014: "Invalid volume",
            10015: "Invalid price",
            10016: "Invalid stops",
            10017: "Trade disabled",
            10018: "Market closed",
            10019: "Insufficient funds",
            10020: "Prices changed",
            10021: "No quotes to process request",
            10022: "Invalid order expiration date",
            10023: "Order state changed",
            10024: "Too many requests",
            10025: "No changes in request",
            10026: "Autotrading disabled by server",
            10027: "Autotrading disabled by client terminal",
            10028: "Request locked for processing",
            10029: "Order or position frozen",
            10030: "Invalid order filling type",
        }
        return errors.get(retcode, f"Unknown error code: {retcode}")

    def get_symbol_info(self, symbol: str) -> Optional[Dict]:
        """Get symbol specifications (pip size, lot size, etc)."""
        if not self.connected:
            return None
        try:
            mt5_sym = self._get_mt5_symbol(symbol)
            info = self.mt5.symbol_info(mt5_sym)
            if info:
                return {
                    "symbol": symbol,
                    "digits": info.digits,
                    "point": info.point,
                    "trade_contract_size": info.trade_contract_size,
                    "volume_min": info.volume_min,
                    "volume_max": info.volume_max,
                    "volume_step": info.volume_step,
                    "spread": info.spread,
                    "trade_mode": info.trade_mode
                }
        except Exception as e:
            logger.error(f"Symbol info error: {e}")
        return None

    def is_market_open(self, symbol: str) -> bool:
        """Check if a symbol is currently tradeable."""
        if not self.connected:
            return True  # Assume open in paper mode
        try:
            mt5_sym = self._get_mt5_symbol(symbol)
            info = self.mt5.symbol_info(mt5_sym)
            return info is not None and info.trade_mode != 0
        except Exception:
            return True

    def disconnect(self):
        """Cleanly disconnect from MT5."""
        if self.connected and self.mt5:
            self.mt5.shutdown()
            self.connected = False
            logger.info("MT5 disconnected")
