@echo off
title APEX Trading System - Setup
color 0B

echo.
echo  ============================================
echo   ^^  APEX TRADING SYSTEM - INSTALLER
echo  ============================================
echo.

REM Check Python is installed
python --version >nul 2>&1
if %errorlevel% neq 0 (
    echo  [ERROR] Python not found!
    echo.
    echo  Please install Python 3.11+ from:
    echo  https://www.python.org/downloads/
    echo.
    echo  IMPORTANT: Tick "Add Python to PATH" during install!
    echo.
    pause
    exit /b 1
)

echo  [OK] Python found
python --version

echo.
echo  Installing dependencies...
echo  (This may take 2-3 minutes)
echo.

pip install -r requirements.txt

if %errorlevel% neq 0 (
    echo.
    echo  [WARNING] Some packages failed. Trying individually...
    pip install requests pandas numpy scikit-learn xgboost
    pip install PyQt6
    pip install MetaTrader5
    pip install firebase-admin
    pip install schedule textblob
)

echo.
echo  ============================================
echo   SETUP COMPLETE!
echo  ============================================
echo.
echo  Next steps:
echo.
echo  1. Download MT5 from Vantage Markets website
echo  2. Install MT5 and log in with your account
echo  3. Open config\mt5_config.py and fill in:
echo       MT5_LOGIN    = your account number
echo       MT5_PASSWORD = your password
echo       MT5_SERVER   = server name from MT5
echo.
echo  4. Run the dashboard:
echo       python main.py --dashboard
echo.
echo  5. When ready for live trading:
echo       python main.py
echo.
pause
